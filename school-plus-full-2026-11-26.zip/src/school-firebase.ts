// IIC×NSTA Smart School Ecosystem — Supabase-First + Firebase Hybrid CRUD Helpers
import { runTransaction } from "firebase/firestore";
import { ref, set, get, onValue, update, remove, runTransaction as rtdbRunTransaction } from "firebase/database";
import { db, rtdb, ensureFirebaseAuthSession } from "./firebase";
import {
  sbCol as col,
  sbDoc as d,
  sbBridgeGetDoc as getDoc,
  sbBridgeGetDocs as getDocs,
  sbBridgeSetDoc as setDoc,
  sbBridgeUpdateDoc as updateDoc,
  sbBridgeDeleteDoc as deleteDoc,
  sbQuery as query,
  sbWhere as where,
  sbOrderBy as orderBy,
  sbLimit as limit,
  sbBridgeOnSnapshot as onSnapshot,
  sbBridgeWriteBatch as writeBatch,
} from "./services/supabaseSchoolBridge";
import { isSupabaseSchemaReady, sbRtdbGet, sbRtdbSet } from "./services/supabaseDbAdapter";

const withTimeout = <T>(promise: Promise<T>, ms = 3000, fallbackVal?: T): Promise<T> => {
  return Promise.race([
    promise,
    new Promise<T>((resolve, reject) =>
      setTimeout(() => {
        if (fallbackVal !== undefined) resolve(fallbackVal);
        else reject(new Error(`Operation timed out after ${ms}ms`));
      }, ms)
    )
  ]);
};

const sanitizeForFirestore = (obj: any): any => {
  if (obj === null || obj === undefined) return null;
  if (typeof obj !== "object") return obj;
  if (Array.isArray(obj)) return obj.map(sanitizeForFirestore);
  const out: any = {};
  for (const [k, v] of Object.entries(obj)) {
    if (v !== undefined) out[k] = sanitizeForFirestore(v);
  }
  return out;
};
import type {
  School, SchoolSession, SchoolClass, SchoolSubject, SchoolLesson,
  SchoolTeacher, SchoolStudent, AttendanceRecord, ExamEntry, MonthlyFee,
  SchoolHomework, SchoolMCQResult, SchoolUserProfile, DailyClassLecture,
  NstaMessage, NstaThreadType, NstaFeeSlipData, NstaWelcomeData, NstaBirthdayData,
  NstaSchoolStatus, NstaStatusViewer,
  SchoolAccountant, AccountantPermissions, SchoolExpenseVoucher,
  StudentAcknowledgedLeave, StudentAbsenteeCallLog,
  SchoolEvent, SchoolEventType,
  AdminAttendanceRecord, StaffDailyAttendanceRecord, StaffDailyAttendanceEntry,
  FeeCallFollowUpRecord, SimCallLogRecord, UpiPaymentProofRecord
} from "./school-types";
import { sortSchoolClasses } from "./school-types";
import {
  getDemoSchoolDataset,
  isDemoDataEnabled,
  setDemoDataEnabled,
  addDemoSession,
  updateDemoSession,
  deleteDemoSession,
  setActiveDemoSession,
  subscribeDemoSessions
} from "./components/school/demoDataStore";
export { isDemoDataEnabled, setDemoDataEnabled };
import { cleanLogoUrl, isAppLogo, getSavedSchoolLogo } from "./utils/schoolLogoUtils";
import {
  getSchoolCacheSync,
  setSchoolCacheSync,
  removeSchoolCacheSync,
  getSchoolCacheEntriesByPrefix,
  setSchoolLogoSync,
  whenSchoolIdbReady,
  markSchoolCacheFresh,
  isSchoolCacheFresh,
  getSchoolCacheVersion,
  invalidateSchoolCacheFreshness,
  getPersistedSchoolSyncVersions,
  setPersistedSchoolSyncVersions,
} from "./utils/schoolIndexedDb";
import { uploadImageToImgBB } from "./services/imgbbService";

export const isDemoSessionId = (sessionId?: string | null): boolean => {
  if (!sessionId) return false;
  const s = String(sessionId).toLowerCase();
  return s === "demo_session_2026_27" || s.startsWith("demo_") || s.includes("demo");
};

export const isDemoSchoolId = (sid?: string | null): boolean => {
  if (!sid) return true;
  const s = String(sid).toLowerCase();
  return s === "demo_school" || s.startsWith("demo_") || s.includes("demo");
};

// Strict rule: Demo data is ONLY allowed when in an explicit Demo Session. Real sessions have ZERO dummy data!
export const shouldUseDemoForSchool = (schoolId?: string, sessionId?: string): boolean => {
  if (sessionId) {
    return isDemoSessionId(sessionId);
  }
  if (typeof localStorage !== "undefined" && schoolId) {
    try {
      const savedSess = localStorage.getItem(`nst_active_session_${schoolId}`);
      if (savedSess) {
        return isDemoSessionId(savedSess);
      }
    } catch {}
  }
  if (!isDemoDataEnabled()) {
    return false;
  }
  if (isDemoSchoolId(schoolId)) {
    return true;
  }
  return false;
};

// Automatically converts heavy Base64 data:image strings into lightweight Cloud CDN URLs (~80 bytes)
// so no Firestore document ever approaches the 1 MB limit!
const ensureCloudImageUrl = async (val?: string | null, filenamePrefix = "school_asset"): Promise<string> => {
  if (!val || typeof val !== "string") return "";
  const trimmed = val.trim();
  if (!trimmed.startsWith("data:image/")) return trimmed;
  try {
    return await uploadImageToImgBB(trimmed, `${filenamePrefix}_${Date.now()}.png`);
  } catch (err) {
    console.warn("[school-firebase] Cloud image upload fallback:", err);
    return trimmed;
  }
};

const NESTED_SCHOOL_RTDB_KEYS = new Set([
  "students",
  "classes",
  "sessions",
  "subjects",
  "lessons",
  "teachers",
  "attendance",
  "exams",
  "fees",
  "homework",
  "notices",
  "holidays",
  "community_posts",
  "mcq_results",
  "certificates",
  "admit_cards",
  "staff",
  "leaves",
  "admissions",
  "inquiries",
  "gallery",
  "events",
  "referral_payouts",
  "referral_settings",
]);

const stripNestedSchoolCollections = (raw: any): School => {
  if (!raw || typeof raw !== "object") return raw;
  const clean: any = {};
  for (const [k, v] of Object.entries(raw)) {
    if (!NESTED_SCHOOL_RTDB_KEYS.has(k)) {
      clean[k] = v;
    }
  }
  return clean as School;
};

// Helper to reliably identify demo-seeded records across school entities
export const isDemoRecord = (item: any): boolean => {
  if (!item) return false;
  const id = String(item.id || "").toLowerCase();
  const sessionId = String(item.sessionId || "").toLowerCase();
  const classId = String(item.classId || "").toLowerCase();
  const rollNo = String(item.rollNo || "");
  const admissionNo = String(item.admissionNo || "").toUpperCase();
  const employeeId = String(item.employeeId || "").toUpperCase();
  const email = String(item.email || "").toLowerCase();

  // 1. Explicit demo ID prefixes
  if (
    id.startsWith("demo_") ||
    id.startsWith("std-0") ||
    id.startsWith("tea_demo_") ||
    id.startsWith("staff_demo_") ||
    id.startsWith("staff_principal_") ||
    id.startsWith("emp_tea_") ||
    id.startsWith("not_") ||
    id.startsWith("hol_")
  ) {
    return true;
  }

  // 2. Demo session / class reference
  if (sessionId.startsWith("demo_")) return true;
  if (classId.startsWith("demo_class_") || classId.startsWith("demo_")) return true;

  // 3. Demo admission numbers (DPS-ADM-141201 etc. or ADM-26-NUR...)
  if (admissionNo.startsWith("DPS-ADM-") || admissionNo.startsWith("ADM-26-")) return true;

  // 4. Demo roll numbers with section patterns like "Class10-A-01", "Class6-B-05", "Nursery-A-01"
  if (/^[A-Za-z0-9]+-[AB]-\d{2}$/.test(rollNo) || rollNo.includes("-A-") || rollNo.includes("-B-")) {
    return true;
  }

  // 5. Demo employee ID prefixes
  if (
    employeeId.startsWith("EMP-NUR") ||
    employeeId.startsWith("EMP-KG") ||
    employeeId.startsWith("EMP-C") ||
    employeeId.startsWith("EMP-1") ||
    employeeId.startsWith("EMP-2") ||
    employeeId.startsWith("EMP-3") ||
    employeeId.startsWith("EMP-4") ||
    employeeId.startsWith("EMP-5") ||
    employeeId.startsWith("EMP-6") ||
    employeeId.startsWith("EMP-7") ||
    employeeId.startsWith("EMP-8") ||
    employeeId.startsWith("EMP-9") ||
    employeeId.startsWith("EMP-10") ||
    employeeId.startsWith("TEA-RKVERMA")
  ) {
    return true;
  }

  // 6. Demo emails
  if (
    email.includes("@demoschool.edu.in") ||
    email.includes("@student.dps.edu.in") ||
    email.includes("@school.in") ||
    email.includes("rkverma.math@dps.edu.in") ||
    email.includes("priya.s@dps.edu.in") ||
    email.includes("rajesh.k@dps.edu.in")
  ) {
    return true;
  }

  return false;
};

// Supabase-First collection & doc builders imported at top as `col` and `d`

// ── SMART SYNC VERSION STAMP & IN-FLIGHT DEDUP ENGINE ─────────────────────────
// Eliminates permanent full-collection listeners & repeat reads across tabs/reloads.
// 15 panels mounting simultaneously share ONE 1-read `meta/sync_versions` check!
const inflightCloudFetches = new Map<string, Promise<any>>();
export const dedupInflight = <T>(key: string, fn: () => Promise<T>): Promise<T> => {
  const existing = inflightCloudFetches.get(key);
  if (existing) return existing as Promise<T>;
  const p = fn().finally(() => {
    inflightCloudFetches.delete(key);
  });
  inflightCloudFetches.set(key, p);
  return p;
};

const schoolSyncVerMem = new Map<string, { ts: number; data: Record<string, number> }>();
const pendingSyncVerBatch = new Map<string, { data: Record<string, number>; timer: ReturnType<typeof setTimeout> }>();

const fetchSchoolSyncVersions = async (schoolId: string): Promise<Record<string, number>> => {
  if (!db || !schoolId || isDemoSchoolId(schoolId)) return {};
  const cached = schoolSyncVerMem.get(schoolId);
  if (cached && Date.now() - cached.ts < 5 * 60 * 1000) {
    return cached.data;
  }
  await whenSchoolIdbReady();
  const persisted = getPersistedSchoolSyncVersions(schoolId, 5 * 60 * 1000);
  if (persisted) {
    schoolSyncVerMem.set(schoolId, { ts: Date.now(), data: persisted });
    return persisted;
  }
  return dedupInflight(`meta_sync_${schoolId}`, async () => {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/meta/sync_versions`)), 2000);
      const data = snap.exists() ? (snap.data() as Record<string, number>) : {};
      schoolSyncVerMem.set(schoolId, { ts: Date.now(), data });
      setPersistedSchoolSyncVersions(schoolId, data);
      return data;
    } catch {
      return cached?.data || {};
    }
  });
};

export const touchSchoolSyncVersion = (schoolId: string, domain: string): void => {
  if (!schoolId || !domain || isDemoSchoolId(schoolId)) return;
  const ver = Date.now();
  const prev = schoolSyncVerMem.get(schoolId)?.data || getPersistedSchoolSyncVersions(schoolId, 24 * 60 * 60 * 1000) || {};
  const merged = { ...prev, [domain]: ver };
  schoolSyncVerMem.set(schoolId, { ts: ver, data: merged });
  setPersistedSchoolSyncVersions(schoolId, merged);

  if (db) {
    const existing = pendingSyncVerBatch.get(schoolId);
    const nextPatch = { ...(existing?.data || {}), [domain]: ver };
    if (existing?.timer) clearTimeout(existing.timer);
    const timer = setTimeout(() => {
      const entry = pendingSyncVerBatch.get(schoolId);
      pendingSyncVerBatch.delete(schoolId);
      if (entry && db) {
        setDoc(d(`schools/${schoolId}/meta/sync_versions`), entry.data, { merge: true }).catch(() => {});
      }
    }, 1500);
    pendingSyncVerBatch.set(schoolId, { data: nextPatch, timer });
  }
};

export const shouldFetchDomainFromCloud = async (
  schoolId: string,
  domain: string,
  cacheKey: string,
  hasLocalData: () => boolean,
  ttlMs = 10 * 60 * 1000
): Promise<{ fetch: boolean; remoteVer: number }> => {
  await whenSchoolIdbReady();
  const localPresent = hasLocalData();
  if (localPresent && isSchoolCacheFresh(cacheKey, ttlMs)) {
    return { fetch: false, remoteVer: getSchoolCacheVersion(cacheKey) };
  }
  if (!db || isDemoSchoolId(schoolId)) {
    return { fetch: !localPresent, remoteVer: 0 };
  }
  const versions = await fetchSchoolSyncVersions(schoolId);
  const remoteVer = Number(versions?.[domain] || 0);
  const localVer = getSchoolCacheVersion(cacheKey);
  if (localPresent && remoteVer > 0 && remoteVer <= localVer) {
    markSchoolCacheFresh(cacheKey, remoteVer);
    return { fetch: false, remoteVer };
  }
  return { fetch: true, remoteVer };
};

// ── SCHOOLS LOCAL CACHE ───────────────────────────────────────────────────────
const LOCAL_SCHOOLS_KEY = "nst_schools_local_cache";
const DELETED_SCHOOLS_KEY = "nst_deleted_schools_list";

export const getDeletedSchoolIds = (): Set<string> => {
  try {
    const raw = localStorage.getItem(DELETED_SCHOOLS_KEY);
    if (raw) {
      const arr = JSON.parse(raw);
      if (Array.isArray(arr)) return new Set(arr);
    }
  } catch {}
  return new Set<string>();
};

export const markSchoolAsDeleted = (schoolId: string) => {
  if (!schoolId) return;
  try {
    const set = getDeletedSchoolIds();
    set.add(schoolId);
    localStorage.setItem(DELETED_SCHOOLS_KEY, JSON.stringify(Array.from(set)));
  } catch {}
};

export const clearSchoolFromDeletedList = (schoolId: string) => {
  if (!schoolId) return;
  try {
    const set = getDeletedSchoolIds();
    set.delete(schoolId);
    localStorage.setItem(DELETED_SCHOOLS_KEY, JSON.stringify(Array.from(set)));
  } catch {}
};

export const DEFAULT_SCHOOL_ID = "MySyHGP5AguNdisdPKRu";

export const DEFAULT_LIFE_MAKER_SCHOOL: School = {
  id: DEFAULT_SCHOOL_ID,
  name: "LIFE MAKER PUBLIC SCHOOL",
  code: "LMPS",
  address: "DHARAKA MARKET AFFOUR NAGRA SARAN",
  phone: "9525400122,9835763641",
  mobile: "9525400122,9835763641",
  email: "n@gmail.com",
  affiliation: "Ummid Educational & Welfare Trust",
  adminEmail: "n@gmail.com",
  logoUrl: "",
  principalName: "SHAHID KHAN SIR",
  principalPhone: "9525400122",
  directorName: "Ehsan hussain",
  directorPhone: "9525400122",
  managerName: "VIKASH  KUMAR",
  managerPhone: "9835763641",
  accountantName: "Nadim anwar",
  accountantSignatureUrl: "",
  examControllerName: "Exam Controller",
  examControllerSignatureUrl: "",
  managerSignatureUrl: "",
  tagline: "Bright Future... Together",
  bannerColor: "#1e3a8a",
  isDefaultPublicWebsite: true,
  upiId: "BHARATPE2U0D0C7V8R57881@unitype",
  erpAppUrl: "https://www.mediafire.com/file/izwctjhm11r4pcd/DOC-20261109-WA0000.apk/file",
  customFields: [
    { id: "cf_estd", label: "Estd. Year", value: "2027" },
    { id: "cf_trust", label: "Trust / Society", value: "Ummid Educational & Welfare Trust" },
  ],
  websiteConfig: {
    admissionSessionLabel: "2027-28",
    admissionsOpen: true,
    heroHeadline: "LIFE MAKER PUBLIC SCHOOL",
    heroSubheadline:
      "Bright Future... Together — Dharaka Market Affour, Nagra, Saran. Quality Education from Nursery to Class X.",
    heroBannerUrl: "",
    aboutSchool:
      "LIFE MAKER PUBLIC SCHOOL (Affour, Nagra, Saran) managed under Ummid Educational & Welfare Trust provides disciplined, quality & technology-enabled schooling from Nursery to Class X.",
    principalMessage:
      "Education at Life Maker Public School nurtures discipline, devotion, dedication, and academic excellence for every child.",
    websiteAccountantName: "REENA  MA'AM",
    whatsappNumber: "9525400122,9835763641",
    whatsappGroupUrl: "https://wa.me/qr/YPWEWGEIQ6DHB1",
    facebookUrl: "https://www.facebook.com/share/1CJQaSqUYB/",
    instagramUrl: "https://www.instagram.com/lmpsaffour?obrf=Z3hxbXE2dnZ3c3g3",
    youtubeUrl: "https://youtube.com/@lmps_affour?si=s7uW_2wSYdZO2tIx",
    officeHours: "Mon – Sat · 8:00 AM – 2:30 PM",
    topTickerEnabled: true,
    topTickerSpeed: "slow",
    admissionOffer: {
      enabled: false,
      discountPercent: 0,
    },
    entranceDiscountConfig: {
      enabled: true,
      slabs: [],
    },
  },
  subscription: {
    reading: true,
    writing: true,
    pdf: true,
    mcq: true,
    isElite: true,
    customCurriculumEnabled: true,
    monthlyAmount: 4500,
    status: "active",
    tier: "full",
    expiresAt: "2027-04-24T23:59:59.000Z",
    paidUntil: "2027-04-24T23:59:59.000Z",
    assignedAt: "2026-04-24T00:00:00.000Z",
  },
  active: true,
  createdAt: "2026-04-01T00:00:00.000Z",
  createdBy: "admin_uid",
};

export const DEFAULT_DPS_SCHOOL: School = DEFAULT_LIFE_MAKER_SCHOOL;

const normalizeDefaultSchoolBrand = (sc: School): School => {
  if (!sc || typeof sc !== "object") return sc;
  const nameLower = String(sc.name || "").trim().toLowerCase();
  const codeUpper = String(sc.code || "").trim().toUpperCase();
  const isLegacyDummy =
    nameLower === "nstz" ||
    nameLower === "nstz smart academy" ||
    codeUpper === "NSTZ" ||
    sc.id === "dps_gurgaon_sector45" ||
    (nameLower === "delhi public school" && (codeUpper === "DPS45" || codeUpper === "DPS_DEL"));

  const isTargetDefaultSchool =
    sc.id === DEFAULT_SCHOOL_ID ||
    nameLower.includes("life maker") ||
    codeUpper === "LMPS";

  if (!isLegacyDummy && !isTargetDefaultSchool) return sc;

  if (isLegacyDummy) {
    return {
      ...DEFAULT_LIFE_MAKER_SCHOOL,
      ...sc,
      id: sc.id === "dps_gurgaon_sector45" ? DEFAULT_SCHOOL_ID : sc.id,
      name: DEFAULT_LIFE_MAKER_SCHOOL.name,
      code: "LMPS",
      address: DEFAULT_LIFE_MAKER_SCHOOL.address,
      phone: DEFAULT_LIFE_MAKER_SCHOOL.phone,
      mobile: DEFAULT_LIFE_MAKER_SCHOOL.mobile,
      email: DEFAULT_LIFE_MAKER_SCHOOL.email,
      adminEmail: DEFAULT_LIFE_MAKER_SCHOOL.adminEmail,
      affiliation: DEFAULT_LIFE_MAKER_SCHOOL.affiliation,
      directorName: DEFAULT_LIFE_MAKER_SCHOOL.directorName,
      directorPhone: DEFAULT_LIFE_MAKER_SCHOOL.directorPhone,
      principalName: DEFAULT_LIFE_MAKER_SCHOOL.principalName,
      managerName: DEFAULT_LIFE_MAKER_SCHOOL.managerName,
      managerPhone: DEFAULT_LIFE_MAKER_SCHOOL.managerPhone,
      accountantName: DEFAULT_LIFE_MAKER_SCHOOL.accountantName,
      tagline: DEFAULT_LIFE_MAKER_SCHOOL.tagline,
      logoUrl: DEFAULT_LIFE_MAKER_SCHOOL.logoUrl,
    };
  }

  // Real Life Maker record from RTDB/local: backfill ONLY blank/missing fields without overwriting user CMS edits
  const stripDeadDefaultTgUrl = (val?: string): string => {
    const clean = String(val || "").trim();
    if (!clean) return "";
    if (/api\.telegram\.org\/file\/bot\d+:[^/]+\/documents\/file_(69|70|71|72|73)\.png$/i.test(clean)) {
      return "";
    }
    return clean;
  };
  const defCfg = DEFAULT_LIFE_MAKER_SCHOOL.websiteConfig || {};
  const existingCfg = (sc as any).websiteConfig || {};
  const mergedCfg: Record<string, any> = { ...defCfg };
  for (const [k, v] of Object.entries(existingCfg)) {
    if (v !== undefined && v !== null && String(v).trim() !== "") {
      mergedCfg[k] = k === "heroBannerUrl" ? stripDeadDefaultTgUrl(String(v)) : v;
    }
  }

  return {
    ...DEFAULT_LIFE_MAKER_SCHOOL,
    ...sc,
    name: sc.name && sc.name.trim() ? sc.name : DEFAULT_LIFE_MAKER_SCHOOL.name,
    code: !sc.code || codeUpper === "NSTZ" || codeUpper === "DPS_DEL" ? "LMPS" : sc.code,
    address:
      !sc.address || sc.address.includes("Institutional Academic Campus")
        ? DEFAULT_LIFE_MAKER_SCHOOL.address
        : sc.address,
    phone: !sc.phone || sc.phone === "0124-4125800" ? DEFAULT_LIFE_MAKER_SCHOOL.phone : sc.phone,
    mobile: !sc.mobile || sc.mobile === "0124-4125800" ? DEFAULT_LIFE_MAKER_SCHOOL.mobile : sc.mobile,
    email: !sc.email || String(sc.email).toLowerCase().includes("nstz.") ? DEFAULT_LIFE_MAKER_SCHOOL.email : sc.email,
    adminEmail:
      !sc.adminEmail || String(sc.adminEmail).toLowerCase().includes("nstz.") || sc.adminEmail === "admin@dps.edu.in"
        ? DEFAULT_LIFE_MAKER_SCHOOL.adminEmail
        : sc.adminEmail,
    affiliation:
      !sc.affiliation || sc.affiliation === "Affiliated Education Center"
        ? DEFAULT_LIFE_MAKER_SCHOOL.affiliation
        : sc.affiliation,
    directorName:
      !sc.directorName || sc.directorName === "Mrs. Shashi Sharma"
        ? DEFAULT_LIFE_MAKER_SCHOOL.directorName
        : sc.directorName,
    directorPhone:
      !sc.directorPhone || sc.directorPhone === "9811023451"
        ? DEFAULT_LIFE_MAKER_SCHOOL.directorPhone
        : sc.directorPhone,
    principalName:
      !sc.principalName || sc.principalName === "Dr. Arvind Swaminathan"
        ? DEFAULT_LIFE_MAKER_SCHOOL.principalName
        : sc.principalName,
    principalPhone:
      !sc.principalPhone || sc.principalPhone === "9811023450"
        ? DEFAULT_LIFE_MAKER_SCHOOL.principalPhone
        : sc.principalPhone,
    managerName: sc.managerName || DEFAULT_LIFE_MAKER_SCHOOL.managerName,
    managerPhone: sc.managerPhone || DEFAULT_LIFE_MAKER_SCHOOL.managerPhone,
    accountantName: sc.accountantName || DEFAULT_LIFE_MAKER_SCHOOL.accountantName,
    tagline: !sc.tagline || sc.tagline === "Knowledge & Excellence" ? DEFAULT_LIFE_MAKER_SCHOOL.tagline : sc.tagline,
    logoUrl: stripDeadDefaultTgUrl(sc.logoUrl) || DEFAULT_LIFE_MAKER_SCHOOL.logoUrl,
    accountantSignatureUrl: stripDeadDefaultTgUrl(sc.accountantSignatureUrl) || DEFAULT_LIFE_MAKER_SCHOOL.accountantSignatureUrl,
    examControllerSignatureUrl: stripDeadDefaultTgUrl(sc.examControllerSignatureUrl) || DEFAULT_LIFE_MAKER_SCHOOL.examControllerSignatureUrl,
    managerSignatureUrl: stripDeadDefaultTgUrl(sc.managerSignatureUrl) || DEFAULT_LIFE_MAKER_SCHOOL.managerSignatureUrl,
    bannerColor: sc.bannerColor || DEFAULT_LIFE_MAKER_SCHOOL.bannerColor,
    websiteConfig: mergedCfg as any,
  };
};

export const getLocalSchools = (): School[] => {
  try {
    const deletedIds = getDeletedSchoolIds();
    const parsed = getSchoolCacheSync<School[]>(LOCAL_SCHOOLS_KEY, []);
    if (Array.isArray(parsed) && parsed.length > 0) {
      const filtered = parsed
        .filter((s: any) => s && typeof s === "object" && s.id && s.id !== "dps_gurgaon_sector45" && !deletedIds.has(s.id))
        .map((s: School) => {
          let updated = normalizeDefaultSchoolBrand(stripNestedSchoolCollections(s));
          if (updated.subscription && !updated.subscription.expiresAt) {
            updated.subscription.expiresAt = "2027-04-24T23:59:59.000Z";
            updated.subscription.paidUntil = "2027-04-24T23:59:59.000Z";
          }
          const resolvedLogo = getSavedSchoolLogo(updated.logoUrl, updated.id);
          updated.logoUrl =
            resolvedLogo && !isAppLogo(resolvedLogo)
              ? resolvedLogo
              : updated.id === DEFAULT_SCHOOL_ID
              ? (DEFAULT_LIFE_MAKER_SCHOOL.logoUrl || "")
              : "";
          return updated;
        });
      if (filtered.length > 0) return filtered;
    }
    if (deletedIds.has(DEFAULT_SCHOOL_ID)) {
      return [];
    }
    const def = { ...DEFAULT_LIFE_MAKER_SCHOOL };
    const defLogo = getSavedSchoolLogo(def.logoUrl, def.id);
    if (defLogo && !isAppLogo(defLogo)) def.logoUrl = defLogo;
    return [def];
  } catch {
    const deletedIds = getDeletedSchoolIds();
    if (deletedIds.has(DEFAULT_SCHOOL_ID)) return [];
    return [DEFAULT_LIFE_MAKER_SCHOOL];
  }
};

export const setLocalSchools = (schools: School[]) => {
  try {
    const deletedIds = getDeletedSchoolIds();
    const cleaned = (Array.isArray(schools) ? schools : [])
      .filter((s: any) => s && typeof s === "object" && s.id && !deletedIds.has(s.id))
      .map(stripNestedSchoolCollections);
    setSchoolCacheSync(LOCAL_SCHOOLS_KEY, cleaned);
  } catch {}
};

// ── SCHOOLS ──────────────────────────────────────────────────────────────────

const normalizeSchoolPhotoAssets = async (target: any, schoolId: string) => {
  if (!target || typeof target !== "object") return;
  const directFields: Array<[string, string]> = [
    ["logoUrl", `logo_${schoolId}`],
    ["principalSignatureUrl", `sig_prin_${schoolId}`],
    ["directorSignatureUrl", `sig_dir_${schoolId}`],
    ["examControllerSignatureUrl", `sig_exam_${schoolId}`],
    ["managerSignatureUrl", `sig_mgr_${schoolId}`],
    ["accountantSignatureUrl", `sig_acc_${schoolId}`],
    ["principalPhotoUrl", `photo_prin_${schoolId}`],
    ["subPrincipalPhotoUrl", `photo_subprin_${schoolId}`],
    ["directorPhotoUrl", `photo_dir_${schoolId}`],
    ["managerPhotoUrl", `photo_mgr_${schoolId}`],
    ["digitalCreatorPhotoUrl", `photo_creator_${schoolId}`],
  ];
  for (const [field, prefix] of directFields) {
    if (target[field] && typeof target[field] === "string" && target[field].startsWith("data:image/")) {
      target[field] = await ensureCloudImageUrl(target[field], prefix);
    }
  }
  if (target.websiteConfig && typeof target.websiteConfig === "object") {
    const cfg = { ...target.websiteConfig };
    const cfgFields: Array<[string, string]> = [
      ["heroBannerUrl", `web_hero_${schoolId}`],
      ["subPrincipalPhotoUrl", `web_subprin_${schoolId}`],
      ["directorPhotoUrl", `web_dir_${schoolId}`],
      ["managerPhotoUrl", `web_mgr_${schoolId}`],
      ["websiteAccountantPhotoUrl", `web_acc_${schoolId}`],
      ["digitalCreatorPhotoUrl", `web_creator_${schoolId}`],
    ];
    for (const [field, prefix] of cfgFields) {
      if (cfg[field] && typeof cfg[field] === "string" && cfg[field].startsWith("data:image/")) {
        cfg[field] = await ensureCloudImageUrl(cfg[field], prefix);
      }
    }
    if (cfg.admissionOffer && Array.isArray(cfg.admissionOffer.images)) {
      const normalizedOfferImgs = [];
      for (let i = 0; i < cfg.admissionOffer.images.length; i++) {
        const im = cfg.admissionOffer.images[i];
        if (!im || typeof im !== "object") continue;
        let nextUrl = im.url;
        if (nextUrl && typeof nextUrl === "string" && nextUrl.startsWith("data:image/")) {
          nextUrl = await ensureCloudImageUrl(nextUrl, `web_offer_${schoolId}_${im.id || i}`);
        }
        normalizedOfferImgs.push({ ...im, url: nextUrl });
      }
      cfg.admissionOffer = { ...cfg.admissionOffer, images: normalizedOfferImgs };
    }
    target.websiteConfig = cfg;
  }
};

export const saveSchool = async (school: School) => {
  clearSchoolFromDeletedList(school.id);
  const cleanMeta = stripNestedSchoolCollections({ ...school });
  await normalizeSchoolPhotoAssets(cleanMeta, school.id);
  if (cleanMeta.logoUrl) {
    setSchoolLogoSync(school.id, cleanMeta.logoUrl);
  }

  const sanitized = sanitizeForFirestore(cleanMeta);

  // 1. Instantly store in IndexedDB + RAM cache so UI is responsive in 0ms
  const current = getLocalSchools();
  const next = [sanitized, ...current.filter((s: any) => s.id !== school.id)];
  setLocalSchools(next);

  // 2. Ensure a clean default Academic Session exists for brand-new schools so classes can be added right away
  if (school.id && school.id !== DEFAULT_SCHOOL_ID && school.id !== "dps_gurgaon_sector45") {
    const defaultSession: SchoolSession = sanitizeForFirestore({
      id: `sess_${school.id}_2026_27`,
      schoolId: school.id,
      name: "Academic Session 2026-27",
      startDate: "2026-04-01",
      endDate: "2027-03-31",
      active: true,
      createdAt: new Date().toISOString(),
    });
    if (rtdb) {
      update(ref(rtdb, `schools/${school.id}/sessions/${defaultSession.id}`), defaultSession).catch(() => {});
    }
    if (db) {
      setDoc(d(`schools/${school.id}/sessions/${defaultSession.id}`), defaultSession, { merge: true }).catch(() => {});
    }
  }

  // 3. CRITICAL MULTI-SCHOOL SAFETY: Use update() (NEVER set()) on RTDB `schools/${school.id}`
  // so child nodes (`students`, `classes`, `fees`, `community_posts`, etc.) are NEVER overwritten!
  if (rtdb) {
    try {
      await Promise.all([
        withTimeout(update(ref(rtdb, `schools/${school.id}`), sanitized), 2500),
        withTimeout(set(ref(rtdb, `schools_profiles/${school.id}`), sanitized), 2500),
      ]);
    } catch (e) {
      console.warn("[school-firebase] RTDB saveSchool:", e);
    }
  }

  // 4. Save to Firestore with merge: true so no existing fields are lost
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${school.id}`), sanitized, { merge: true }), 3000);
    } catch (e) {
      console.warn("[school-firebase] Firestore saveSchool timed out or offline:", e);
    }
  }
  markSchoolCacheFresh(LOCAL_SCHOOLS_KEY);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-profile-updated", { detail: { schoolId: school.id, data: sanitized } }));
  }

  return sanitized;
};

export const getSchool = async (schoolId: string): Promise<School | null> => {
  if (!schoolId) return null;
  const resolvedId = schoolId === "dps_gurgaon_sector45" ? DEFAULT_SCHOOL_ID : schoolId;
  const deletedIds = getDeletedSchoolIds();
  if (deletedIds.has(resolvedId)) return null;

  const sanitize = (sc: School | null): School | null => {
    if (!sc) return null;
    let updated = normalizeDefaultSchoolBrand(stripNestedSchoolCollections(sc));
    const sid = updated.id || resolvedId;
    // Resolve strictly THIS school's logo (never another school's logo!)
    const resolvedLogo = getSavedSchoolLogo(updated.logoUrl, sid);
    updated.logoUrl =
      resolvedLogo && !isAppLogo(resolvedLogo)
        ? resolvedLogo
        : sid === DEFAULT_SCHOOL_ID
        ? (DEFAULT_LIFE_MAKER_SCHOOL.logoUrl || "")
        : "";
    return updated;
  };

  const local = getLocalSchools().find(s => s.id === resolvedId);
  if (local) return sanitize(local);

  // 1. Primary: Supabase schools table (or auto-seed from Firestore)
  try {
    const sbSnap = await withTimeout(getDoc(d(`schools/${resolvedId}`)), 2500);
    if (sbSnap.exists() && !deletedIds.has(resolvedId)) {
      return sanitize({ ...(sbSnap.data() as School), id: resolvedId });
    }
  } catch {}

  if (rtdb) {
    try {
      const profileSnap = await withTimeout(get(ref(rtdb, `schools_profiles/${resolvedId}`)), 1800);
      const profileVal = (profileSnap as any)?.val?.();
      if (profileVal && (profileVal.id || profileVal.name) && !deletedIds.has(resolvedId)) {
        const clean = sanitize({ id: resolvedId, ...profileVal } as School);
        if (clean) void setDoc(d(`schools/${resolvedId}`), clean, { merge: true }).catch(() => {});
        return clean;
      }

      const snap = await withTimeout(get(ref(rtdb, `schools/${resolvedId}`)), 2000);
      const val = (snap as any)?.val?.();
      if (val && (val.id || val.name) && !deletedIds.has(resolvedId)) {
        const clean = sanitize({ id: resolvedId, ...val } as School);
        if (clean) void setDoc(d(`schools/${resolvedId}`), clean, { merge: true }).catch(() => {});
        return clean;
      }
    } catch {}
  }

  if (resolvedId === DEFAULT_SCHOOL_ID && !deletedIds.has(DEFAULT_SCHOOL_ID)) {
    return sanitize(DEFAULT_LIFE_MAKER_SCHOOL);
  }
  return null;
};

export const getAllSchools = async (forceRefresh = false): Promise<School[]> => {
  await whenSchoolIdbReady();
  const deletedIds = getDeletedSchoolIds();
  const isIgnoredDummy = (id: string) => id === "dps_gurgaon_sector45" || id === "demo_school";
  const local = getLocalSchools().filter(s => !deletedIds.has(s.id) && !isIgnoredDummy(s.id));

  if (!forceRefresh && local.length > 0 && isSchoolCacheFresh(LOCAL_SCHOOLS_KEY, 2 * 60 * 1000)) {
    return local;
  }

  return dedupInflight("getAllSchools", async () => {
    const mergedMap = new Map<string, School>();
    local.forEach(s => { if (s?.id && !deletedIds.has(s.id) && !isIgnoredDummy(s.id)) mergedMap.set(s.id, s); });

    let fetchedCloud = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col("schools")), 2500);
        const list = (snap as any).docs.map((docSnap: any) => stripNestedSchoolCollections({ id: docSnap.id, ...docSnap.data() }));
        if (list.length > 0) fetchedCloud = true;
        list.forEach((s: School) => {
          if (s?.id && s.name && !deletedIds.has(s.id) && !isIgnoredDummy(s.id)) {
            mergedMap.set(s.id, { ...(mergedMap.get(s.id) || {}), ...s });
          }
        });
      } catch {}
    }

    // Only read lightweight `schools_profiles` if Firestore returned nothing (never fallback to full `schools/` RTDB tree!)
    if (!fetchedCloud && rtdb) {
      try {
        const profSnap = await withTimeout(get(ref(rtdb, "schools_profiles")), 2000);
        const profVal = (profSnap as any)?.val?.();
        if (profVal && typeof profVal === "object") {
          fetchedCloud = true;
          Object.entries(profVal).forEach(([id, raw]: [string, any]) => {
            if (deletedIds.has(id) || isIgnoredDummy(id)) return;
            const clean = stripNestedSchoolCollections({ id, ...raw });
            if (clean.id && clean.name) mergedMap.set(clean.id, { ...(mergedMap.get(clean.id) || {}), ...clean });
          });
        }
      } catch {}
    }

    const finalSchools = Array.from(mergedMap.values())
      .filter(s => !deletedIds.has(s.id) && !isIgnoredDummy(s.id))
      .map(normalizeDefaultSchoolBrand);
    if (finalSchools.length === 0 && !deletedIds.has(DEFAULT_SCHOOL_ID)) {
      finalSchools.push({ ...DEFAULT_LIFE_MAKER_SCHOOL });
    }
    setLocalSchools(finalSchools);
    if (fetchedCloud || finalSchools.length > 0) {
      markSchoolCacheFresh(LOCAL_SCHOOLS_KEY);
    }
    return finalSchools;
  });
};

export const subscribeToSchool = (schoolId: string, cb: (s: School | null) => void) => {
  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    if (getDeletedSchoolIds().has(schoolId)) {
      cb(null);
      return;
    }
    const local = getLocalSchools().find(s => s.id === schoolId);
    if (local) cb(local);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    const hasLocal = getLocalSchools().some(s => s.id === schoolId);
    if (db && (!hasLocal || !isSchoolCacheFresh(LOCAL_SCHOOLS_KEY, 2 * 60 * 1000))) {
      getDoc(d(`schools/${schoolId}`))
        .then(snap => {
          if (!active || getDeletedSchoolIds().has(schoolId)) return;
          if (snap.exists()) {
            const fresh = normalizeDefaultSchoolBrand(stripNestedSchoolCollections({ ...(snap.data() as School), id: schoolId }));
            const cur = getLocalSchools();
            setLocalSchools([...cur.filter(s => s.id !== schoolId), fresh]);
            markSchoolCacheFresh(LOCAL_SCHOOLS_KEY);
            cb(fresh);
          }
        })
        .catch(() => {});
    }
  });

  const onLocalEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("school-profile-updated", onLocalEvt);
    window.addEventListener("school-deleted", deliverLocal);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("school-profile-updated", onLocalEvt);
      window.removeEventListener("school-deleted", deliverLocal);
    }
  };
};

export const subscribeToAllSchools = (
  cb: (schools: School[]) => void,
  onError?: (err: Error) => void
) => {
  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    const deletedIds = getDeletedSchoolIds();
    const list = getLocalSchools()
      .filter(s => s?.id && !deletedIds.has(s.id))
      .map(normalizeDefaultSchoolBrand);
    cb(list);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getAllSchools()
      .then(list => {
        if (active) cb(list);
      })
      .catch(err => {
        onError?.(err);
      });
  });

  const onHydratedOrUpdated = () => deliverLocal();
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", onHydratedOrUpdated);
    window.addEventListener("school-profile-updated", onHydratedOrUpdated);
    window.addEventListener("school-deleted", onHydratedOrUpdated);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", onHydratedOrUpdated);
      window.removeEventListener("school-profile-updated", onHydratedOrUpdated);
      window.removeEventListener("school-deleted", onHydratedOrUpdated);
    }
  };
};

export const updateSchool = async (schoolId: string, data: Partial<School>) => {
  const prepared: any = { ...stripNestedSchoolCollections(data) };
  await normalizeSchoolPhotoAssets(prepared, schoolId);

  const sanitized = sanitizeForFirestore(prepared);

  // Per-school isolated logo in IndexedDB (never global localStorage!)
  if (sanitized?.logoUrl !== undefined && schoolId) {
    const cleaned = cleanLogoUrl(sanitized.logoUrl);
    if (cleaned && !isAppLogo(cleaned)) {
      setSchoolLogoSync(schoolId, cleaned);
      sanitized.logoUrl = cleaned;
    } else {
      setSchoolLogoSync(schoolId, "");
      sanitized.logoUrl = "";
    }
  }

  const current = getLocalSchools();
  let matched = false;
  const next = current.map(s => {
    if (s.id === schoolId) {
      matched = true;
      return { ...s, ...sanitized };
    }
    return s;
  });
  if (!matched && schoolId) {
    next.push({ id: schoolId, name: sanitized.name || "School", ...sanitized } as School);
  }
  setLocalSchools(next);

  // Instantly notify active screens strictly for this schoolId
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-profile-updated", {
      detail: { schoolId, data: sanitized, logoUrl: sanitized?.logoUrl }
    }));
  }

  // RTDB (update only — never wipes nested children)
  if (rtdb && schoolId) {
    try {
      await Promise.all([
        withTimeout(update(ref(rtdb, `schools/${schoolId}`), sanitized), 2500),
        withTimeout(update(ref(rtdb, `schools_profiles/${schoolId}`), { id: schoolId, ...sanitized }), 2500),
      ]);
    } catch {}
  }

  // Firestore (setDoc with merge: true so it never fails if doc wasn't created yet)
  if (db && schoolId) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}`), sanitized, { merge: true }), 3000);
    } catch {}
  }
};

export const lockSchool = async (schoolId: string, locked: boolean) => {
  await updateSchool(schoolId, { locked });
};

export const deleteSchool = async (schoolId: string) => {
  if (!schoolId) return;
  markSchoolAsDeleted(schoolId);

  const current = getLocalSchools();
  const updatedList = current.filter(s => s.id !== schoolId);
  setLocalSchools(updatedList);
  setSchoolLogoSync(schoolId, "");

  try {
    localStorage.removeItem(`nst_school_teachers_${schoolId}`);
    localStorage.removeItem(`nst_school_students_${schoolId}`);
    localStorage.removeItem(`nst_school_classes_${schoolId}`);
    localStorage.removeItem(`nst_school_fees_${schoolId}`);
    localStorage.removeItem(`nst_school_curriculum_notes_${schoolId}`);
    localStorage.removeItem(`school_logo:${schoolId}`);

    const activeSch = localStorage.getItem("nst_active_school_id");
    if (activeSch === schoolId) {
      localStorage.removeItem("nst_active_school_id");
      localStorage.removeItem("nst_active_student_key");
      localStorage.removeItem("nst_school_user_profile");
      localStorage.removeItem("nst_linked_school_info");
    }

    const curUserRaw = localStorage.getItem("nst_current_user");
    if (curUserRaw) {
      const cu = JSON.parse(curUserRaw);
      if (cu && cu.schoolId === schoolId) {
        cu.schoolId = "";
        cu.schoolName = null;
        cu.schoolRole = null;
        cu.schoolCode = null;
        localStorage.setItem("nst_current_user", JSON.stringify(cu));
        localStorage.setItem("nsta_cached_user", JSON.stringify(cu));
      }
    }
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-deleted", { detail: { schoolId, remainingSchools: updatedList } }));
    window.dispatchEvent(new CustomEvent("school-profile-updated", { detail: { schoolId, deleted: true } }));
    window.dispatchEvent(new CustomEvent("nst-school-exited", { detail: { schoolId } }));
  }

  if (rtdb) {
    try {
      await Promise.all([
        withTimeout(remove(ref(rtdb, `schools/${schoolId}`)), 2000),
        withTimeout(remove(ref(rtdb, `schools_profiles/${schoolId}`)), 2000),
        withTimeout(set(ref(rtdb, `deleted_schools/${schoolId}`), true), 2000),
      ]);
    } catch {}
  }

  if (db) {
    try {
      await Promise.all([
        withTimeout(deleteDoc(d(`schools/${schoolId}`)), 2500),
        withTimeout(setDoc(d(`deleted_schools/${schoolId}`), { deletedAt: new Date().toISOString() }, { merge: true }), 2500),
      ]);
    } catch {}
  }
};

export const detachUserFromSchool = async (userId: string, email?: string) => {
  try {
    localStorage.removeItem("nst_active_school_id");
    localStorage.removeItem("nst_active_student_key");
    localStorage.removeItem("nst_school_user_profile");
    localStorage.removeItem("nst_linked_school_info");
    if (userId) {
      localStorage.removeItem(`nst_user_linked_students_${userId}`);
    }

    const curUserRaw = localStorage.getItem("nst_current_user");
    if (curUserRaw) {
      const cu = JSON.parse(curUserRaw);
      if (cu) {
        cu.schoolId = "";
        cu.schoolName = null;
        cu.schoolRole = null;
        cu.schoolCode = null;
        localStorage.setItem("nst_current_user", JSON.stringify(cu));
        localStorage.setItem("nsta_cached_user", JSON.stringify(cu));
      }
    }

    if (userId && rtdb) {
      try {
        await update(ref(rtdb, `users/${userId}`), { schoolId: "", schoolName: null, schoolRole: null, schoolCode: null });
      } catch {}
    }
    if (userId) {
      try {
        await updateDoc(d(`users/${userId}`), { schoolId: "", schoolName: null, schoolRole: null, schoolCode: null });
      } catch {}
    }

    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("nst-school-exited"));
      window.dispatchEvent(new CustomEvent("school-profile-updated", { detail: { schoolId: null } }));
    }
  } catch (e) {
    console.error("detachUserFromSchool error:", e);
  }
};

// ── SESSIONS ─────────────────────────────────────────────────────────────────
const LOCAL_SESSIONS_PREFIX = "nst_school_sessions_";

export const getLocalSessions = (schoolId: string): SchoolSession[] => {
  try {
    const list = getSchoolCacheSync<SchoolSession[]>(`${LOCAL_SESSIONS_PREFIX}${schoolId}`, []);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalSessions = (schoolId: string, sessions: SchoolSession[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_SESSIONS_PREFIX}${schoolId}`, Array.isArray(sessions) ? sessions : []);
  } catch {}
};

export const saveSession = async (session: SchoolSession) => {
  if (shouldUseDemoForSchool(session.schoolId)) {
    addDemoSession(session);
  }
  const sanitized = sanitizeForFirestore(session);
  const cacheKey = `${LOCAL_SESSIONS_PREFIX}${session.schoolId}`;
  try {
    const cur = getLocalSessions(session.schoolId);
    setLocalSessions(session.schoolId, [sanitized, ...cur.filter(s => s.id !== session.id)]);
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("sessions-updated", { detail: { schoolId: session.schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${session.schoolId}/sessions/${session.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${session.schoolId}/sessions/${session.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(session.schoolId, "sessions");
};

const isValidRealSessionRecord = (s: any, allowDemo = false): boolean => {
  if (!s || typeof s !== "object") return false;
  const id = String(s.id || "").trim();
  const name = String(s.name || "").trim();
  if (!id || !name) return false;
  if (!allowDemo && (isDemoSessionId(id) || isDemoRecord(s))) return false;
  return true;
};

const provisionedUpcomingSessions = new Set<string>();

const extractSessionYear = (s?: Partial<SchoolSession> | null): number | null => {
  const txt = `${s?.name || ""} ${s?.startDate || ""} ${s?.id || ""}`;
  const match = txt.match(/(20\d{2})/);
  return match ? Number(match[1]) : null;
};

const buildDynamicSessionBounds = (date: Date = new Date()) => {
  const yr = date.getFullYear();
  const m = date.getMonth();
  const currentStartYear = m >= 3 ? yr : yr - 1;
  const endShort = String((currentStartYear + 1) % 100).padStart(2, "0");
  const nextStartYear = currentStartYear + 1;
  const nextEndShort = String((nextStartYear + 1) % 100).padStart(2, "0");
  return {
    currentStartYear,
    currentLabel: `${currentStartYear}-${endShort}`,
    nextStartYear,
    nextLabel: `${nextStartYear}-${nextEndShort}`,
    isOctToMarWindow: m >= 9 || m < 3,
  };
};

const ensureOctoberUpcomingSession = (
  schoolId: string,
  list: SchoolSession[],
  now: Date = new Date()
): SchoolSession[] => {
  if (!schoolId || isDemoSchoolId(schoolId) || !Array.isArray(list) || list.length === 0) {
    return list;
  }
  const { currentStartYear, nextStartYear, nextLabel, isOctToMarWindow } = buildDynamicSessionBounds(now);
  if (!isOctToMarWindow) return list;

  const activeItem = list.find((s) => s.active) || list[0];
  const activeStartYr = extractSessionYear(activeItem) ?? currentStartYear;
  if (activeStartYr >= nextStartYear) {
    return list;
  }
  const targetNextStartYr = nextStartYear;
  const targetNextEndShort = String((targetNextStartYr + 1) % 100).padStart(2, "0");
  const targetNextLabel = nextLabel;

  const alreadyExists = list.some((s) => {
    const sy = extractSessionYear(s);
    return (sy !== null && sy >= targetNextStartYr) || String(s.name || "").includes(targetNextLabel);
  });
  if (alreadyExists) return list;

  const nextSessId = `sess_${schoolId}_${targetNextStartYr}_${targetNextEndShort}`;
  const autoNextSession: SchoolSession = {
    id: nextSessId,
    schoolId,
    name: `Academic Session ${targetNextLabel}`,
    startDate: `${targetNextStartYr}-04-01`,
    endDate: `${targetNextStartYr + 1}-03-31`,
    active: false, // Keep current session active while auto-opening next session for admissions
    createdAt: new Date().toISOString(),
  };

  const guardKey = `${schoolId}_${targetNextStartYr}`;
  if (!provisionedUpcomingSessions.has(guardKey)) {
    provisionedUpcomingSessions.add(guardKey);
    saveSession(autoNextSession).catch(() => {
      provisionedUpcomingSessions.delete(guardKey);
    });
  }

  return [...list, autoNextSession];
};

export const getSessions = async (schoolId: string): Promise<SchoolSession[]> => {
  const isDemoSchool = isDemoSchoolId(schoolId);
  if (isDemoSchool && shouldUseDemoForSchool(schoolId)) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.sessions && demo.sessions.length > 0) return demo.sessions;
    if (demo && demo.session) return [demo.session];
  }

  const cacheKey = `${LOCAL_SESSIONS_PREFIX}${schoolId}`;
  return dedupInflight(`getSessions_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "sessions",
      cacheKey,
      () => getLocalSessions(schoolId).filter(s => isValidRealSessionRecord(s, isDemoSchool)).length > 0,
      15 * 60 * 1000
    );

    const localFiltered = getLocalSessions(schoolId).filter(s => isValidRealSessionRecord(s, isDemoSchool));
    if (!fetch && localFiltered.length > 0) {
      return ensureOctoberUpcomingSession(schoolId, localFiltered);
    }

    let gotRemote = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/sessions`)), 2500);
        const list = (snap as any).docs.map((docSnap: any) => docSnap.data() as SchoolSession);
        const filtered = list.filter((s: any) => isValidRealSessionRecord(s, isDemoSchool));
        if (filtered.length > 0) {
          gotRemote = true;
          const res = ensureOctoberUpcomingSession(schoolId, filtered);
          setLocalSessions(schoolId, res);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return res;
        }
      } catch {}
    }

    if (!gotRemote && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/sessions`)), 2000);
        const val = (snap as any)?.val?.();
        if (val && typeof val === "object") {
          const list: SchoolSession[] = Object.values(val);
          const filtered = list.filter(s => isValidRealSessionRecord(s, isDemoSchool));
          if (filtered.length > 0) {
            const res = ensureOctoberUpcomingSession(schoolId, filtered);
            setLocalSessions(schoolId, res);
            markSchoolCacheFresh(cacheKey, remoteVer);
            return res;
          }
        }
      } catch {}
    }

    if (localFiltered.length > 0) {
      return ensureOctoberUpcomingSession(schoolId, localFiltered);
    }

    // Auto-provision current active session (and next session if Oct-Mar) for newly added schools
    const { currentStartYear, currentLabel } = buildDynamicSessionBounds();
    const currentEndShort = String((currentStartYear + 1) % 100).padStart(2, "0");
    const autoSession: SchoolSession = {
      id: `sess_${schoolId}_${currentStartYear}_${currentEndShort}`,
      schoolId,
      name: `Academic Session ${currentLabel}`,
      startDate: `${currentStartYear}-04-01`,
      endDate: `${currentStartYear + 1}-03-31`,
      active: true,
      createdAt: new Date().toISOString(),
    };
    saveSession(autoSession).catch(() => {});
    return ensureOctoberUpcomingSession(schoolId, [autoSession]);
  });
};

export const subscribeToSessions = (schoolId: string, cb: (sessions: SchoolSession[]) => void) => {
  const isDemoSchool = isDemoSchoolId(schoolId);
  let active = true;
  let demoUnsub: (() => void) | null = null;

  if (isDemoSchool && shouldUseDemoForSchool(schoolId)) {
    demoUnsub = subscribeDemoSessions(cb);
    return () => {
      active = false;
      if (typeof demoUnsub === "function") demoUnsub();
    };
  }

  const deliverLocal = () => {
    if (!active) return;
    const local = getLocalSessions(schoolId).filter(s => isValidRealSessionRecord(s, isDemoSchool));
    if (local.length > 0) {
      cb(ensureOctoberUpcomingSession(schoolId, local));
    }
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getSessions(schoolId)
      .then(list => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("sessions-updated", onEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("sessions-updated", onEvt);
    }
    if (typeof demoUnsub === "function") demoUnsub();
  };
};

export const updateSession = async (schoolId: string, sessionId: string, data: Partial<SchoolSession>) => {
  if (!sessionId || isDemoSessionId(sessionId)) {
    if (isDemoSessionId(sessionId)) {
      updateDemoSession(sessionId, data);
    }
    return;
  }
  if (shouldUseDemoForSchool(schoolId)) {
    updateDemoSession(sessionId, data);
  }
  const sanitized = sanitizeForFirestore(data);
  try {
    const cur = getLocalSessions(schoolId);
    setLocalSessions(schoolId, cur.map(s => s.id === sessionId ? { ...s, ...sanitized } : s));
    markSchoolCacheFresh(`${LOCAL_SESSIONS_PREFIX}${schoolId}`);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("sessions-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/sessions/${sessionId}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/sessions/${sessionId}`), sanitized, { merge: true }), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "sessions");
};

export const deleteSession = async (schoolId: string, sessionId: string) => {
  if (shouldUseDemoForSchool(schoolId)) {
    deleteDemoSession(sessionId);
  }
  try {
    const cur = getLocalSessions(schoolId);
    setLocalSessions(schoolId, cur.filter(s => s.id !== sessionId));
    markSchoolCacheFresh(`${LOCAL_SESSIONS_PREFIX}${schoolId}`);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("sessions-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/sessions/${sessionId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/sessions/${sessionId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "sessions");
};

// ── CLASSES ──────────────────────────────────────────────────────────────────
const LOCAL_CLASSES_PREFIX = "nst_school_classes_";

export const getLocalClasses = (schoolId: string): SchoolClass[] => {
  try {
    const list = getSchoolCacheSync<SchoolClass[]>(`${LOCAL_CLASSES_PREFIX}${schoolId}`, []);
    const arr = Array.isArray(list) ? list : [];
    const filtered = !shouldUseDemoForSchool(schoolId) ? arr.filter(c => !isDemoRecord(c)) : arr;
    return sortSchoolClasses(filtered);
  } catch {
    return [];
  }
};

export const setLocalClasses = (schoolId: string, classes: SchoolClass[]) => {
  try {
    const arr = Array.isArray(classes) ? classes : [];
    setSchoolCacheSync(`${LOCAL_CLASSES_PREFIX}${schoolId}`, sortSchoolClasses(arr));
  } catch {}
};

export const saveClass = async (cls: SchoolClass) => {
  const sanitized = sanitizeForFirestore(cls);
  const cacheKey = `${LOCAL_CLASSES_PREFIX}${cls.schoolId}`;
  // Cache in IndexedDB + RAM immediately
  try {
    const cur = getLocalClasses(cls.schoolId);
    const next = [sanitized, ...cur.filter((c: any) => c.id !== cls.id)];
    setLocalClasses(cls.schoolId, next);
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("classes-updated", { detail: { schoolId: cls.schoolId } }));
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${cls.schoolId}/classes/${cls.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${cls.schoolId}/classes/${cls.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(cls.schoolId, "classes");
};

export const getClasses = async (schoolId: string, sessionId?: string): Promise<SchoolClass[]> => {
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.classes && demo.classes.length > 0) {
      const targetSess = sessionId || demo.session?.id;
      const filtered = targetSess
        ? demo.classes.filter(c => c.sessionId === targetSess)
        : demo.classes;
      const resolved = filtered.length > 0 ? filtered : demo.classes.filter(c => c.sessionId === demo.session?.id);
      return sortSchoolClasses(resolved.length > 0 ? resolved : demo.classes);
    }
  }

  const cacheKey = `${LOCAL_CLASSES_PREFIX}${schoolId}`;
  const allClasses = await dedupInflight<SchoolClass[]>(`getClasses_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "classes",
      cacheKey,
      () => getLocalClasses(schoolId).length > 0,
      15 * 60 * 1000
    );

    const local = getLocalClasses(schoolId) as SchoolClass[];
    if (!fetch && local.length > 0) {
      return local;
    }

    let gotFs = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/classes`)), 2500);
        const allRaw = (snap as any).docs.map((docSnap: any) => docSnap.data() as SchoolClass);
        const all = allRaw.filter((c: any) => c && !isDemoRecord(c));
        gotFs = true;
        if (all.length > 0) {
          setLocalClasses(schoolId, all);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return sortSchoolClasses(all) as SchoolClass[];
        }
      } catch {}
    }

    if (!gotFs && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/classes`)), 2000);
        const val = (snap as any)?.val?.();
        if (val && typeof val === "object") {
          const allRaw: SchoolClass[] = Object.values(val);
          const all = allRaw.filter(c => c && !isDemoRecord(c));
          setLocalClasses(schoolId, all);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return sortSchoolClasses(all) as SchoolClass[];
        }
      } catch {}
    }

    if (local.length > 0) markSchoolCacheFresh(cacheKey, remoteVer);
    return local;
  });

  const filtered = sessionId ? allClasses.filter(c => c.sessionId === sessionId) : allClasses;
  return sortSchoolClasses(filtered) as SchoolClass[];
};

export const subscribeToClasses = (schoolId: string, sessionId: string, cb: (classes: SchoolClass[]) => void) => {
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    if (useDemo) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.classes && demo.classes.length > 0) {
        const targetSess = sessionId || demo.session?.id;
        const filtered = targetSess ? demo.classes.filter(c => c.sessionId === targetSess) : demo.classes;
        const resolved = filtered.length > 0 ? filtered : demo.classes.filter(c => c.sessionId === demo.session?.id);
        cb(sortSchoolClasses(resolved.length > 0 ? resolved : demo.classes));
        return;
      }
    }
    const local = getLocalClasses(schoolId);
    const realClasses = local.filter(c => !isDemoRecord(c));
    const filtered = sessionId ? realClasses.filter(c => c.sessionId === sessionId) : realClasses;
    cb(sortSchoolClasses(filtered));
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    if (!useDemo) {
      getClasses(schoolId, sessionId)
        .then(list => {
          if (active) cb(list);
        })
        .catch(() => {});
    }
  });

  const onEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("classes-updated", onEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("classes-updated", onEvt);
    }
  };
};

export const updateClass = async (schoolId: string, classId: string, data: Partial<SchoolClass>) => {
  const sanitized = sanitizeForFirestore(data);
  const cacheKey = `${LOCAL_CLASSES_PREFIX}${schoolId}`;
  try {
    const cur = getLocalClasses(schoolId);
    setLocalClasses(schoolId, cur.map(c => c.id === classId ? { ...c, ...sanitized } : c));
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("classes-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/classes/${classId}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/classes/${classId}`), sanitized, { merge: true }), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "classes");
};

export const deleteClass = async (schoolId: string, classId: string) => {
  const cacheKey = `${LOCAL_CLASSES_PREFIX}${schoolId}`;
  try {
    const cur = getLocalClasses(schoolId);
    setLocalClasses(schoolId, cur.filter(c => c.id !== classId));
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("classes-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/classes/${classId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/classes/${classId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "classes");
};

// ── SUBJECTS ─────────────────────────────────────────────────────────────────
const LOCAL_SUBJECTS_PREFIX = "nst_school_subjects_";

const getLocalSubjects = (schoolId: string): SchoolSubject[] => {
  try {
    const list = getSchoolCacheSync<SchoolSubject[]>(`${LOCAL_SUBJECTS_PREFIX}${schoolId}`, []);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

const setLocalSubjects = (schoolId: string, subjects: SchoolSubject[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_SUBJECTS_PREFIX}${schoolId}`, Array.isArray(subjects) ? subjects : []);
  } catch {}
};

export const saveSubject = async (subject: SchoolSubject) => {
  const sanitized = sanitizeForFirestore(subject);
  const cacheKey = `${LOCAL_SUBJECTS_PREFIX}${subject.schoolId}`;
  try {
    const cur = getLocalSubjects(subject.schoolId);
    setLocalSubjects(subject.schoolId, [sanitized, ...cur.filter(s => s.id !== subject.id)]);
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("subjects-updated", { detail: { schoolId: subject.schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${subject.schoolId}/subjects/${subject.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${subject.schoolId}/subjects/${subject.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(subject.schoolId, "subjects");
};

export const saveMultipleSubjects = async (subjects: SchoolSubject[]) => {
  if (!Array.isArray(subjects) || subjects.length === 0) return;
  const schoolId = subjects[0].schoolId;
  const updates: Record<string, any> = {};
  const batch = db ? writeBatch(db) : null;
  const sanitizedList: SchoolSubject[] = [];

  subjects.forEach(sub => {
    const sanitized = sanitizeForFirestore(sub);
    sanitizedList.push(sanitized);
    updates[`schools/${schoolId}/subjects/${sub.id}`] = sanitized;
    if (batch && db) {
      batch.set(d(`schools/${schoolId}/subjects/${sub.id}`), sanitized);
    }
  });

  const cacheKey = `${LOCAL_SUBJECTS_PREFIX}${schoolId}`;
  try {
    const cur = getLocalSubjects(schoolId);
    const idSet = new Set(sanitizedList.map(s => s.id));
    setLocalSubjects(schoolId, [...sanitizedList, ...cur.filter(s => !idSet.has(s.id))]);
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("subjects-updated", { detail: { schoolId } }));
  }

  if (rtdb) {
    try {
      await withTimeout(update(ref(rtdb), updates), 2500);
    } catch {}
  }
  if (batch) {
    try {
      await withTimeout(batch.commit(), 3000);
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "subjects");
};

export const getSubjects = async (schoolId: string, classId?: string): Promise<SchoolSubject[]> => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.subjects && demo.subjects.length > 0) {
      return classId ? demo.subjects.filter(s => s.classId === classId) : demo.subjects;
    }
    return [];
  }

  const cacheKey = `${LOCAL_SUBJECTS_PREFIX}${schoolId}`;
  const allSubjects = await dedupInflight(`getSubjects_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "subjects",
      cacheKey,
      () => getLocalSubjects(schoolId).length > 0,
      15 * 60 * 1000
    );

    const local = getLocalSubjects(schoolId).filter(s => !isDemoRecord(s));
    if (!fetch && local.length > 0) return local;

    let gotFs = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/subjects`)), 2500);
        const all = (snap as any).docs.map((docSnap: any) => docSnap.data() as SchoolSubject).filter((s: any) => s && !isDemoRecord(s));
        gotFs = true;
        setLocalSubjects(schoolId, all);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return all;
      } catch {}
    }

    if (!gotFs && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/subjects`)), 2000);
        const val = (snap as any)?.val?.();
        if (val && typeof val === "object") {
          const all: SchoolSubject[] = (Object.values(val) as SchoolSubject[]).filter(s => s && !isDemoRecord(s));
          setLocalSubjects(schoolId, all);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return all;
        }
      } catch {}
    }

    return local;
  });

  return classId ? allSubjects.filter(s => s.classId === classId) : allSubjects;
};

export const subscribeToSubjects = (schoolId: string, classId: string, cb: (subjects: SchoolSubject[]) => void) => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  let active = true;

  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.subjects && demo.subjects.length > 0) {
      cb(classId ? demo.subjects.filter(s => s.classId === classId) : demo.subjects);
    } else {
      cb([]);
    }
    return () => { active = false; };
  }

  const deliverLocal = () => {
    if (!active) return;
    const local = getLocalSubjects(schoolId).filter(s => !isDemoRecord(s));
    cb(classId ? local.filter(s => s.classId === classId) : local);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getSubjects(schoolId, classId)
      .then(list => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("subjects-updated", onEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("subjects-updated", onEvt);
    }
  };
};

export const deleteSubject = async (schoolId: string, subjectId: string) => {
  const cacheKey = `${LOCAL_SUBJECTS_PREFIX}${schoolId}`;
  try {
    const cur = getLocalSubjects(schoolId);
    setLocalSubjects(schoolId, cur.filter(s => s.id !== subjectId));
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("subjects-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/subjects/${subjectId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/subjects/${subjectId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "subjects");
};

// ── LESSONS ──────────────────────────────────────────────────────────────────

const LOCAL_LESSONS_PREFIX = "nst_school_lessons_";

export const saveLesson = async (lesson: SchoolLesson) => {
  const sanitized = sanitizeForFirestore(lesson);
  const cacheKey = `${LOCAL_LESSONS_PREFIX}${lesson.schoolId}`;
  try {
    const cur = getSchoolCacheSync<SchoolLesson[]>(cacheKey, []);
    setSchoolCacheSync(cacheKey, [sanitized, ...(Array.isArray(cur) ? cur : []).filter(l => l.id !== lesson.id)]);
    markSchoolCacheFresh(cacheKey);
  } catch {}

  let fsOk = false;
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${lesson.schoolId}/lessons/${lesson.id}`), sanitized), 3000);
      fsOk = true;
      touchSchoolSyncVersion(lesson.schoolId, "lessons");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${lesson.schoolId}/lessons/${lesson.id}`), sanitized), 2500); } catch {}
  }
};

export const getLessons = async (schoolId: string, subjectId?: string): Promise<SchoolLesson[]> => {
  await whenSchoolIdbReady();
  const cacheKey = `${LOCAL_LESSONS_PREFIX}${schoolId}`;
  const local = getSchoolCacheSync<SchoolLesson[]>(cacheKey, []);
  const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "lessons",
    cacheKey,
    () => Array.isArray(local) && local.length > 0,
    30 * 60 * 1000
  );

  if (!fetch) {
    const arr = Array.isArray(local) ? local : [];
    return subjectId ? arr.filter((l: any) => l.subjectId === subjectId) : arr;
  }

  const all = await dedupInflight<SchoolLesson[]>(`lessons:${schoolId}`, async () => {
    try {
      if (db) {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/lessons`)), 2500);
        const list = (snap as any).docs.map((docSnap: any) => docSnap.data() as SchoolLesson);
        setSchoolCacheSync(cacheKey, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      }
    } catch {}
    return Array.isArray(local) ? local : [];
  });
  return subjectId ? all.filter((l: any) => l.subjectId === subjectId) : all;
};

export const subscribeToLessons = (schoolId: string, subjectId: string, cb: (lessons: SchoolLesson[]) => void) =>
  onSnapshot(
    query(col(`schools/${schoolId}/lessons`), where("subjectId", "==", subjectId)),
    snap => cb(snap.docs.map(d => d.data() as SchoolLesson).sort((a, b) => a.order - b.order)),
    err => { console.warn(`[school-firebase] subscribeToLessons error:`, err?.code || err); cb([]); }
  );

export const updateLesson = async (schoolId: string, lessonId: string, data: Partial<SchoolLesson>) => {
  const sanitized = sanitizeForFirestore(data);
  const cacheKey = `${LOCAL_LESSONS_PREFIX}${schoolId}`;
  try {
    const cur = getSchoolCacheSync<SchoolLesson[]>(cacheKey, []);
    if (Array.isArray(cur) && cur.length > 0) {
      setSchoolCacheSync(cacheKey, cur.map(l => (l.id === lessonId ? { ...l, ...sanitized } : l)));
      markSchoolCacheFresh(cacheKey);
    }
  } catch {}

  let fsOk = false;
  if (db) {
    try {
      await withTimeout(updateDoc(d(`schools/${schoolId}/lessons/${lessonId}`), sanitized), 3000);
      fsOk = true;
      touchSchoolSyncVersion(schoolId, "lessons");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/lessons/${lessonId}`), sanitized), 2000); } catch {}
  }
};

export const deleteLesson = async (schoolId: string, lessonId: string) => {
  const cacheKey = `${LOCAL_LESSONS_PREFIX}${schoolId}`;
  try {
    const cur = getSchoolCacheSync<SchoolLesson[]>(cacheKey, []);
    if (Array.isArray(cur)) {
      setSchoolCacheSync(cacheKey, cur.filter(l => l.id !== lessonId));
      markSchoolCacheFresh(cacheKey);
    }
  } catch {}

  let fsOk = false;
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/lessons/${lessonId}`)), 2500);
      fsOk = true;
      touchSchoolSyncVersion(schoolId, "lessons");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/lessons/${lessonId}`)), 2000); } catch {}
  }
};

// ── TEACHERS ─────────────────────────────────────────────────────────────────
const LOCAL_TEACHERS_PREFIX = "nst_school_teachers_";
const DELETED_TEACHERS_PREFIX = "nst_deleted_teachers_";
const LOCAL_STAFF_PREFIX = "nst_school_staff_";
const DELETED_STAFF_PREFIX = "nst_deleted_staff_";

export const isActiveSchoolTeacherRecord = (t: any): boolean => {
  if (!t || typeof t !== "object" || !t.id) return false;
  if (t.active === false || t.isDeleted === true) return false;
  const st = typeof t.status === "string" ? t.status.trim().toLowerCase() : "";
  if (st === "deleted" || st === "disabled" || st === "inactive" || st === "removed") return false;
  return true;
};

export const isActiveStaffRecord = (s: any): boolean => {
  if (!s || typeof s !== "object" || !s.id) return false;
  if (s.active === false || s.isDeleted === true) return false;
  const st = typeof s.status === "string" ? s.status.trim().toLowerCase() : "";
  if (st === "deleted" || st === "disabled" || st === "inactive" || st === "removed") return false;
  return true;
};

const readIdSetFromStores = (key: string): Set<string> => {
  const out = new Set<string>();
  try {
    const cached = getSchoolCacheSync<string[]>(key, []);
    if (Array.isArray(cached)) cached.forEach((id) => id && out.add(String(id)));
  } catch {}
  try {
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) parsed.forEach((id) => id && out.add(String(id)));
      }
    }
  } catch {}
  return out;
};

const writeIdSetToStores = (key: string, setVal: Set<string>) => {
  const arr = Array.from(setVal);
  try {
    setSchoolCacheSync(key, arr);
    if (typeof localStorage !== "undefined") localStorage.removeItem(key);
  } catch {}
};

export const getDeletedTeacherIds = (schoolId: string): Set<string> => {
  if (!schoolId) return new Set<string>();
  const combined = readIdSetFromStores(`${DELETED_TEACHERS_PREFIX}${schoolId}`);
  readIdSetFromStores(`${DELETED_STAFF_PREFIX}${schoolId}`).forEach((id) => combined.add(id));
  return combined;
};

const markTeacherDeletedLocally = (schoolId: string, teacherId: string) => {
  if (!schoolId || !teacherId) return;
  const tSet = readIdSetFromStores(`${DELETED_TEACHERS_PREFIX}${schoolId}`);
  tSet.add(teacherId);
  writeIdSetToStores(`${DELETED_TEACHERS_PREFIX}${schoolId}`, tSet);

  const sSet = readIdSetFromStores(`${DELETED_STAFF_PREFIX}${schoolId}`);
  sSet.add(teacherId);
  writeIdSetToStores(`${DELETED_STAFF_PREFIX}${schoolId}`, sSet);

  // Purge immediately from IndexedDB teacher & staff caches
  try {
    const curTeachers = getSchoolCacheSync<SchoolTeacher[]>(`${LOCAL_TEACHERS_PREFIX}${schoolId}`, []);
    if (Array.isArray(curTeachers)) {
      setSchoolCacheSync(`${LOCAL_TEACHERS_PREFIX}${schoolId}`, curTeachers.filter((t: any) => t && t.id !== teacherId));
    }
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
  } catch {}

  try {
    const curStaff = getSchoolCacheSync<any[]>(`${LOCAL_STAFF_PREFIX}${schoolId}`, []);
    if (Array.isArray(curStaff)) {
      setSchoolCacheSync(`${LOCAL_STAFF_PREFIX}${schoolId}`, curStaff.filter((s: any) => s && s.id !== teacherId));
    }
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_STAFF_PREFIX}${schoolId}`);
  } catch {}
};

const clearTeacherDeletedLocally = (schoolId: string, teacherId: string) => {
  if (!schoolId || !teacherId) return;
  const tSet = readIdSetFromStores(`${DELETED_TEACHERS_PREFIX}${schoolId}`);
  if (tSet.delete(teacherId)) writeIdSetToStores(`${DELETED_TEACHERS_PREFIX}${schoolId}`, tSet);
  const sSet = readIdSetFromStores(`${DELETED_STAFF_PREFIX}${schoolId}`);
  if (sSet.delete(teacherId)) writeIdSetToStores(`${DELETED_STAFF_PREFIX}${schoolId}`, sSet);
};

export const setLocalTeachers = (schoolId: string, teachers: SchoolTeacher[]) => {
  if (!schoolId) return;
  const deletedIds = getDeletedTeacherIds(schoolId);
  const useDemo = shouldUseDemoForSchool(schoolId);
  const clean = (Array.isArray(teachers) ? teachers : []).filter(
    (t) => isActiveSchoolTeacherRecord(t) && !deletedIds.has(t.id) && (useDemo || !isDemoRecord(t))
  );
  try {
    setSchoolCacheSync(`${LOCAL_TEACHERS_PREFIX}${schoolId}`, clean);
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
  } catch {}
};

export const getLocalTeachers = (schoolId: string): SchoolTeacher[] => {
  if (!schoolId) return [];
  const deletedIds = getDeletedTeacherIds(schoolId);
  const useDemo = shouldUseDemoForSchool(schoolId);
  let pool: SchoolTeacher[] = [];
  try {
    const idbList = getSchoolCacheSync<SchoolTeacher[]>(`${LOCAL_TEACHERS_PREFIX}${schoolId}`, []);
    if (Array.isArray(idbList) && idbList.length > 0) {
      pool = idbList;
    }
  } catch {}
  if (pool.length === 0) {
    try {
      const raw = typeof localStorage !== "undefined" ? localStorage.getItem(`${LOCAL_TEACHERS_PREFIX}${schoolId}`) : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) pool = parsed;
      }
    } catch {}
  }
  return pool.filter(
    (t) => isActiveSchoolTeacherRecord(t) && !deletedIds.has(t.id) && (useDemo || !isDemoRecord(t))
  );
};

export const saveTeacher = async (teacher: SchoolTeacher) => {
  clearTeacherDeletedLocally(teacher.schoolId, teacher.id);
  const prepared: SchoolTeacher = {
    ...teacher,
    active: teacher.active ?? true,
  };
  if (prepared.signatureUrl && typeof prepared.signatureUrl === "string" && prepared.signatureUrl.startsWith("data:image/")) {
    prepared.signatureUrl = await ensureCloudImageUrl(prepared.signatureUrl, `sig_tch_${teacher.id}`);
  }
  if (prepared.photoUrl && typeof prepared.photoUrl === "string" && prepared.photoUrl.startsWith("data:image/")) {
    prepared.photoUrl = await ensureCloudImageUrl(prepared.photoUrl, `photo_tch_${teacher.id}`);
  }
  const sanitized = sanitizeForFirestore(prepared);

  // Immediately update local cache
  const current = getLocalTeachers(teacher.schoolId);
  setLocalTeachers(teacher.schoolId, [sanitized, ...current.filter((t) => t.id !== teacher.id)]);
  markSchoolCacheFresh(`${LOCAL_TEACHERS_PREFIX}${teacher.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("teacher-updated", { detail: { schoolId: teacher.schoolId, teacher: sanitized } }));
  }

  if (rtdb) {
    try {
      await Promise.allSettled([
        withTimeout(set(ref(rtdb, `schools/${teacher.schoolId}/teachers/${teacher.id}`), sanitized), 2000),
        withTimeout(remove(ref(rtdb, `schools/${teacher.schoolId}/deleted_teachers/${teacher.id}`)), 2000),
        withTimeout(remove(ref(rtdb, `schools/${teacher.schoolId}/deleted_staff/${teacher.id}`)), 2000),
      ]);
    } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${teacher.schoolId}/teachers/${teacher.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(teacher.schoolId, "teachers");
};

export const getTeachers = async (schoolId: string, forceRefresh = false): Promise<SchoolTeacher[]> => {
  if (!schoolId) return [];
  const cacheKey = `${LOCAL_TEACHERS_PREFIX}${schoolId}`;
  return dedupInflight(`getTeachers_${schoolId}_${forceRefresh ? "f" : "c"}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "teachers",
      cacheKey,
      () => getLocalTeachers(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      10 * 60 * 1000
    );

    const localList = getLocalTeachers(schoolId);
    if (!forceRefresh && !fetch) {
      return localList;
    }

    const useDemo = shouldUseDemoForSchool(schoolId);
    const deletedIds = getDeletedTeacherIds(schoolId);
    const rawMap = new Map<string, SchoolTeacher>();
    let fsOk = false;
    let rtdbOk = false;

    // Firestore-first (RTDB fallback only if Firestore fails)
    if (db) {
      try {
        const snap: any = await withTimeout(getDocs(col(`schools/${schoolId}/teachers`)), 2500);
        fsOk = true;
        (snap?.docs || []).forEach((docSnap: any) => {
          const data = docSnap.data() as SchoolTeacher;
          const tid = data?.id || docSnap.id;
          if (!tid || (!useDemo && isDemoRecord(data))) return;
          rawMap.set(tid, { ...data, id: tid, schoolId: data?.schoolId || schoolId } as SchoolTeacher);
        });
      } catch {}
    }

    if (!fsOk && rtdb) {
      try {
        const [delTSnap, delSSnap, tchSnap]: any = await Promise.all([
          withTimeout(get(ref(rtdb, `schools/${schoolId}/deleted_teachers`)), 2000).catch(() => null),
          withTimeout(get(ref(rtdb, `schools/${schoolId}/deleted_staff`)), 2000).catch(() => null),
          withTimeout(get(ref(rtdb, `schools/${schoolId}/teachers`)), 2500).catch(() => null),
        ]);
        const delTVal = delTSnap?.val?.();
        if (delTVal && typeof delTVal === "object") Object.keys(delTVal).forEach((id) => id && deletedIds.add(id));
        const delSVal = delSSnap?.val?.();
        if (delSVal && typeof delSVal === "object") Object.keys(delSVal).forEach((id) => id && deletedIds.add(id));
        const val = tchSnap?.val?.();
        if (tchSnap) rtdbOk = true;
        if (val && typeof val === "object") {
          Object.entries(val).forEach(([k, v]: [string, any]) => {
            if (!v || typeof v !== "object") return;
            const tid = v.id || k;
            if (!tid || (!useDemo && isDemoRecord(v))) return;
            rawMap.set(tid, { ...v, id: tid, schoolId: v.schoolId || schoolId } as SchoolTeacher);
          });
        }
      } catch {}
    }

    if (fsOk || rtdbOk) {
      const activeList = Array.from(rawMap.values()).filter(
        (t) => isActiveSchoolTeacherRecord(t) && !deletedIds.has(t.id) && (useDemo || !isDemoRecord(t))
      );
      setLocalTeachers(schoolId, activeList);
      markSchoolCacheFresh(cacheKey, remoteVer);
      return activeList;
    }

    if (localList.length > 0) markSchoolCacheFresh(cacheKey, remoteVer);
    return localList;
  });
};

export const subscribeToTeachers = (schoolId: string, cb: (teachers: SchoolTeacher[]) => void) => {
  if (!schoolId) {
    cb([]);
    return () => {};
  }

  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    cb(getLocalTeachers(schoolId));
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getTeachers(schoolId)
      .then((list) => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onLocalSyncEvent = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    deliverLocal();
  };

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("teacher-deleted", onLocalSyncEvent);
    window.addEventListener("teacher-role-unassigned", onLocalSyncEvent);
    window.addEventListener("staff-deleted", onLocalSyncEvent);
    window.addEventListener("teacher-updated", onLocalSyncEvent);
    window.addEventListener("teacher-restored", onLocalSyncEvent);
    window.addEventListener("nst_demo_toggle_changed", onLocalSyncEvent);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("teacher-deleted", onLocalSyncEvent);
      window.removeEventListener("teacher-role-unassigned", onLocalSyncEvent);
      window.removeEventListener("staff-deleted", onLocalSyncEvent);
      window.removeEventListener("teacher-updated", onLocalSyncEvent);
      window.removeEventListener("teacher-restored", onLocalSyncEvent);
      window.removeEventListener("nst_demo_toggle_changed", onLocalSyncEvent);
    }
  };
};

export const updateTeacher = async (schoolId: string, teacherId: string, data: Partial<SchoolTeacher>) => {
  const preparedData: any = { ...data };
  if (preparedData.signatureUrl && typeof preparedData.signatureUrl === "string" && preparedData.signatureUrl.startsWith("data:image/")) {
    preparedData.signatureUrl = await ensureCloudImageUrl(preparedData.signatureUrl, `sig_tch_${teacherId}`);
  }
  if (preparedData.photoUrl && typeof preparedData.photoUrl === "string" && preparedData.photoUrl.startsWith("data:image/")) {
    preparedData.photoUrl = await ensureCloudImageUrl(preparedData.photoUrl, `photo_tch_${teacherId}`);
  }
  const sanitized = sanitizeForFirestore(preparedData);
  const st = typeof (data as any)?.status === "string" ? (data as any).status.toLowerCase() : "";
  const isSoftDelete =
    data?.active === false ||
    (data as any)?.isDeleted === true ||
    st === "deleted" ||
    st === "disabled" ||
    st === "inactive";

  if (isSoftDelete) {
    markTeacherDeletedLocally(schoolId, teacherId);
    markSchoolCacheFresh(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("teacher-deleted", { detail: { schoolId, teacherId } }));
    }
  } else {
    const current = getLocalTeachers(schoolId);
    const updatedList = current.map((t) => (t.id === teacherId ? { ...t, ...sanitized } : t));
    setLocalTeachers(schoolId, updatedList);
    markSchoolCacheFresh(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
    const updatedItem = updatedList.find((t) => t.id === teacherId);
    if (updatedItem && typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("teacher-updated", { detail: { schoolId, teacher: updatedItem } }));
    }
  }

  if (rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/teachers/${teacherId}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/teachers/${teacherId}`), sanitized, { merge: true }), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "teachers");
  if (isSoftDelete) {
    import("./utils/faceRecognitionEngineV2")
      .then((m) => m.deleteFaceDescriptor(teacherId, schoolId))
      .catch(() => {});
  }
};

const LOCAL_RECYCLE_TEACHERS_PREFIX = "nst_school_recycle_teachers_";
const LOCAL_RECYCLE_STUDENTS_PREFIX = "nst_school_recycle_students_";

export const getLocalRecycleTeachers = (schoolId: string): Array<SchoolTeacher & { deletedAt?: string }> => {
  if (!schoolId) return [];
  try {
    const list = getSchoolCacheSync<any[]>(`${LOCAL_RECYCLE_TEACHERS_PREFIX}${schoolId}`, []);
    if (Array.isArray(list) && list.length > 0) return list;
  } catch {}
  try {
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(`${LOCAL_RECYCLE_TEACHERS_PREFIX}${schoolId}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch {}
  return [];
};

const setLocalRecycleTeachers = (schoolId: string, list: Array<SchoolTeacher & { deletedAt?: string }>) => {
  if (!schoolId) return;
  try {
    setSchoolCacheSync(`${LOCAL_RECYCLE_TEACHERS_PREFIX}${schoolId}`, list);
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_RECYCLE_TEACHERS_PREFIX}${schoolId}`);
  } catch {}
};

export const getLocalRecycleStudents = (schoolId: string): Array<SchoolStudent & { deletedAt?: string }> => {
  if (!schoolId) return [];
  try {
    const list = getSchoolCacheSync<any[]>(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`, []);
    if (Array.isArray(list) && list.length > 0) return list;
  } catch {}
  try {
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) return parsed;
      }
    }
  } catch {}
  return [];
};

const setLocalRecycleStudents = (schoolId: string, list: Array<SchoolStudent & { deletedAt?: string }>) => {
  if (!schoolId) return;
  try {
    setSchoolCacheSync(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`, list);
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
  } catch {}
};

export const deleteTeacher = async (schoolId: string, teacherId: string) => {
  if (!schoolId || !teacherId) return;
  const deletedAt = new Date().toISOString();
  const deletePatch = {
    active: false,
    isDeleted: true,
    status: "deleted",
    deletedAt,
  };

  // 0. Capture full teacher snapshot before purging so it can be restored from Recycle Bin
  let teacherSnapshot: any = null;
  try {
    teacherSnapshot = getLocalTeachers(schoolId).find((t) => t.id === teacherId) || null;
  } catch {}
  if (!teacherSnapshot && rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/teachers/${teacherId}`)), 1500);
      if (snap && snap.exists()) teacherSnapshot = snap.val();
    } catch {}
  }
  if (!teacherSnapshot && db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/teachers/${teacherId}`)), 1500);
      if (snap && snap.exists()) teacherSnapshot = snap.data();
    } catch {}
  }

  const binRecord = sanitizeForFirestore({
    ...(teacherSnapshot || { id: teacherId, schoolId, name: "Removed Teacher" }),
    id: teacherId,
    schoolId,
    deletedAt,
    deletedEntityType: "teacher",
  });

  try {
    const curBin = getLocalRecycleTeachers(schoolId);
    setLocalRecycleTeachers(schoolId, [binRecord, ...curBin.filter((item) => item.id !== teacherId)]);
  } catch {}

  // 1. Immediately purge from all local caches + persist tombstone
  markTeacherDeletedLocally(schoolId, teacherId);

  // 2. Notify all active UI panels & Recycle Bin immediately (0ms)
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("teacher-deleted", { detail: { schoolId, teacherId } }));
    window.dispatchEvent(new CustomEvent("staff-deleted", { detail: { schoolId, staffId: teacherId } }));
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "teacher", id: teacherId } }));
  }

  // 3. Remove from RTDB & write Recycle Bin snapshot + tombstones
  if (rtdb) {
    try {
      await Promise.allSettled([
        withTimeout(set(ref(rtdb, `schools/${schoolId}/recycle_bin_teachers/${teacherId}`), binRecord), 2500),
        withTimeout(remove(ref(rtdb, `schools/${schoolId}/teachers/${teacherId}`)), 2500),
        withTimeout(remove(ref(rtdb, `schools/${schoolId}/staff/${teacherId}`)), 2500),
        withTimeout(set(ref(rtdb, `schools/${schoolId}/deleted_teachers/${teacherId}`), { id: teacherId, deletedAt }), 2500),
        withTimeout(set(ref(rtdb, `schools/${schoolId}/deleted_staff/${teacherId}`), { id: teacherId, deletedAt }), 2500),
      ]);
    } catch {}
  }

  // 4. Write Recycle Bin doc & delete from active Firestore collections
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/recycle_bin_teachers/${teacherId}`), binRecord), 2500);
    } catch {}
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/teachers/${teacherId}`)), 3000);
    } catch {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/teachers/${teacherId}`), deletePatch, { merge: true }), 3000);
      } catch {}
    }
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/staff/${teacherId}`)), 3000);
    } catch {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/staff/${teacherId}`), deletePatch, { merge: true }), 3000);
      } catch {}
    }
  }

  // 5. Cleanup enrolled Face ID descriptor
  import("./utils/faceRecognitionEngineV2")
    .then((m) => m.deleteFaceDescriptor(teacherId, schoolId))
    .catch(() => {});
  markSchoolCacheFresh(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
  markSchoolCacheFresh(`${LOCAL_RECYCLE_TEACHERS_PREFIX}${schoolId}`);
  touchSchoolSyncVersion(schoolId, "teachers");
  touchSchoolSyncVersion(schoolId, "recycle_bin");
};

/**
 * Unassigns a Teacher record strictly when converting a Teacher into Accountant-Only
 * WITHOUT placing the ID in Recycle Bin or deleted_teachers/deleted_staff pools
 * and WITHOUT wiping StaffEmployee payroll/attendance or Face ID.
 */
export const unassignTeacherForAccountantRole = async (schoolId: string, teacherId: string) => {
  if (!schoolId || !teacherId) return;
  const current = getLocalTeachers(schoolId);
  setLocalTeachers(schoolId, current.filter((t) => t.id !== teacherId));
  markSchoolCacheFresh(`${LOCAL_TEACHERS_PREFIX}${schoolId}`);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("teacher-role-unassigned", { detail: { schoolId, teacherId } }));
  }
  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/teachers/${teacherId}`)), 2500); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/teachers/${teacherId}`)), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "teachers");
};

// ── STUDENTS ─────────────────────────────────────────────────────────────────
const LOCAL_STUDENTS_PREFIX = "nst_school_students_";

export const getLocalStudents = (schoolId: string): SchoolStudent[] => {
  try {
    const list = getSchoolCacheSync<SchoolStudent[]>(`${LOCAL_STUDENTS_PREFIX}${schoolId}`, []);
    const arr = Array.isArray(list) ? list : [];
    return !shouldUseDemoForSchool(schoolId) ? arr.filter(s => !isDemoRecord(s)) : arr;
  } catch {
    return [];
  }
};

export const setLocalStudents = (schoolId: string, students: SchoolStudent[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_STUDENTS_PREFIX}${schoolId}`, Array.isArray(students) ? students : []);
  } catch {}
};

export const saveStudent = async (student: SchoolStudent) => {
  const prepared = { ...student, active: student.active !== false };
  if (prepared.photoUrl && prepared.photoUrl.startsWith("data:image/")) {
    prepared.photoUrl = await ensureCloudImageUrl(prepared.photoUrl, `std_${student.schoolId}_${student.id}`);
  }
  const sanitized = sanitizeForFirestore(prepared);

  // 1. Immediately cache in IndexedDB + RAM so scans and queries resolve in 0ms
  const current = getLocalStudents(student.schoolId);
  const next = [sanitized, ...current.filter((s: any) => s.id !== student.id)];
  setLocalStudents(student.schoolId, next);
  markSchoolCacheFresh(`${LOCAL_STUDENTS_PREFIX}${student.schoolId}`);

  // Notify live listeners (SchoolAdminPanel, class rosters, FeeManager) immediately
  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(
        new CustomEvent("student-updated", {
          detail: { schoolId: student.schoolId, studentId: student.id },
        })
      );
    } catch {}
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${student.schoolId}/students/${student.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${student.schoolId}/students/${student.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(student.schoolId, "students");

  // Auto-dispatch official welcome message to NSTA Messenger School Desk when ID is created
  try {
    void dispatchOfficialSchoolWelcomeMessage(sanitized, { triggerPopup: true });
  } catch {}

  return sanitized;
};

const isActiveSchoolStudentRecord = (s: any): boolean => {
  if (!s || typeof s !== "object") return false;
  if (s.active === false || s.isDeleted === true || s.tcIssued === true) return false;
  const st = typeof s.status === "string" ? s.status.trim().toLowerCase() : "";
  if (st === "deleted" || st === "disabled" || st === "inactive") return false;
  return true;
};

export const getStudent = async (schoolId: string, studentId: string): Promise<SchoolStudent | null> => {
  // 1. Instant IndexedDB RAM cache lookup (only active students)
  const local = getLocalStudents(schoolId).find(
    (s: any) =>
      isActiveSchoolStudentRecord(s) &&
      (s.id === studentId || s.admissionNo === studentId || s.rollNo === studentId)
  );
  if (local) return local;

  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 2000);
      if (snap && snap.exists()) {
        const val = snap.val() as SchoolStudent;
        return isActiveSchoolStudentRecord(val) ? val : null;
      }
    } catch {}
  }
  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/students/${studentId}`)), 2500);
      if (snap && snap.exists()) {
        const data = snap.data() as SchoolStudent;
        return isActiveSchoolStudentRecord(data) ? data : null;
      }
    } catch {}
  }
  return null;
};

export const getStudentOrAdmissionRecord = async (
  schoolId: string,
  queryParam: { id?: string; admissionNo?: string; name?: string; phone?: string }
): Promise<Partial<SchoolStudent> & { className?: string; schoolName?: string } | null> => {
  const cleanAdm = (queryParam.admissionNo || "").trim().toLowerCase();
  const cleanName = (queryParam.name || "").trim().toLowerCase();
  const cleanId = (queryParam.id || "").trim();
  const cleanPhone = (queryParam.phone || "").replace(/\D/g, "");

  // Special match for Nadim Anwar scoped strictly to default school
  if ((schoolId === DEFAULT_SCHOOL_ID || schoolId === "dps_gurgaon_sector45") && (cleanName.includes("nadim") || cleanAdm.includes("6616"))) {
    return {
      name: "Nadim Anwar",
      rollNo: "63",
      admissionNo: "ADM-2026-6616",
      fatherName: "Mustak",
      motherName: "Sayda khatoon",
      phone: "+918292665601",
      bloodGroup: "O+",
      dateOfBirth: "2002-11-01",
      address: "Chapra",
      classId: "cls_nursery",
      className: "NURSERY",
      schoolName: "LIFE MAKER PUBLIC SCHOOL",
      monthlyFee: 350
    };
  }

  // 1. Check IndexedDB cache strictly for THIS schoolId first!
  try {
    const schoolStudentsPool = getSchoolCacheSync<any[]>(`nst_school_students_${schoolId}`, []);
    const schoolAdmissionsPool = getSchoolCacheSync<any[]>(`nst_school_admissions_${schoolId}`, []);
    const combinedPool = [
      ...(Array.isArray(schoolStudentsPool) ? schoolStudentsPool : []),
      ...(Array.isArray(schoolAdmissionsPool) ? schoolAdmissionsPool : []),
    ];

    const found = combinedPool.find((item: any) => {
      const itemAdm = (item.admissionNo || item.applicationNo || "").trim().toLowerCase();
      const itemName = (item.name || item.studentName || "").trim().toLowerCase();
      const itemId = item.id || "";
      const itemPhone = (item.phone || "").replace(/\D/g, "");

      if (cleanAdm && itemAdm && itemAdm === cleanAdm) return true;
      if (cleanId && itemId && itemId === cleanId) return true;
      if (cleanName && itemName && itemName === cleanName) return true;
      if (cleanPhone && cleanPhone.length >= 10 && itemPhone === cleanPhone) return true;
      return false;
    });

    if (found && (found.fatherName || found.className || found.classId)) {
      return {
        id: found.id,
        name: found.name || found.studentName,
        rollNo: found.rollNo || found.assignedRollNo,
        admissionNo: found.admissionNo || found.applicationNo,
        classId: found.classId,
        className: found.className,
        fatherName: found.fatherName,
        motherName: found.motherName,
        phone: found.phone,
        bloodGroup: found.bloodGroup,
        dateOfBirth: found.dateOfBirth,
        address: found.address,
        monthlyFee: Number(found.monthlyFee || found.monthlyAmount || 0),
        photoUrl: found.photoUrl || found.photoURL
      };
    }
  } catch {}

  // 2. Query Firestore admissions collection for THIS schoolId
  try {
    if (db) {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/admissions`)), 2500);
      const apps = snap.docs.map(docSnap => docSnap.data() as any);
      const found = apps.find((app: any) => {
        const aAdm = (app.applicationNo || "").trim().toLowerCase();
        const aName = (app.studentName || "").trim().toLowerCase();
        return (cleanAdm && aAdm === cleanAdm) || (cleanName && aName === cleanName);
      });
      if (found) {
        return {
          id: found.id,
          name: found.studentName,
          rollNo: found.assignedRollNo,
          admissionNo: found.applicationNo,
          classId: found.classId,
          className: found.className,
          fatherName: found.fatherName,
          motherName: found.motherName,
          phone: found.phone,
          bloodGroup: found.bloodGroup,
          dateOfBirth: found.dateOfBirth,
          address: found.address,
          monthlyFee: Number(found.monthlyFee || 0)
        };
      }
    }
  } catch {}

  // 3. Query Firestore students collection for THIS schoolId
  try {
    if (db) {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/students`)), 2500);
      const stds = snap.docs.map(docSnap => docSnap.data() as any);
      const found = stds.find((s: any) => {
        const sAdm = (s.admissionNo || "").trim().toLowerCase();
        const sName = (s.name || "").trim().toLowerCase();
        const sId = s.id || "";
        return (cleanAdm && sAdm === cleanAdm) || (cleanName && sName === cleanName) || (cleanId && sId === cleanId);
      });
      if (found) {
        return {
          id: found.id,
          name: found.name,
          rollNo: found.rollNo,
          admissionNo: found.admissionNo,
          classId: found.classId,
          className: found.className,
          fatherName: found.fatherName,
          motherName: found.motherName,
          phone: found.phone,
          bloodGroup: found.bloodGroup,
          dateOfBirth: found.dateOfBirth,
          address: found.address,
          monthlyFee: Number(found.monthlyFee || 0),
          photoUrl: found.photoUrl
        };
      }
    }
  } catch {}

  // 4. Fallback to demo students dataset ONLY if demo applies to this schoolId
  if (shouldUseDemoForSchool(schoolId)) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.students) {
      const found = demo.students.find(s => {
        const sAdm = (s.admissionNo || "").trim().toLowerCase();
        const sName = (s.name || "").trim().toLowerCase();
        const sId = (s.id || "").toLowerCase();
        const sPhone = (s.phone || "").replace(/\D/g, "");
        return (cleanAdm && sAdm === cleanAdm) ||
               (cleanName && sName === cleanName) ||
               (cleanId && sId === cleanId) ||
               (cleanPhone && sPhone && sPhone.endsWith(cleanPhone));
      });
      if (found) return found;
    }
  }

  return null;
};

export const isStudentInClass = (
  student: { classId?: string; className?: string; id?: string },
  targetClassId?: string,
  targetClassName?: string
): boolean => {
  if (!student || typeof student !== "object") return false;
  if (!targetClassId && !targetClassName) return true;

  const sClassId = (student.classId || "").toLowerCase().trim();
  const sClassName = (student.className || "").toLowerCase().trim();
  const tClassId = (targetClassId || "").toLowerCase().trim();
  const tClassName = (targetClassName || "").toLowerCase().trim();

  // 1. Exact match
  if (tClassId && sClassId === tClassId) return true;

  // 2. Prefix / Sectional match (e.g. target "demo_class_kg1", student "demo_class_kg1_sec_a" or "demo_class_kg1_sec_b")
  if (tClassId && (sClassId.startsWith(`${tClassId}_`) || sClassId.startsWith(tClassId))) return true;
  if (sClassId && (tClassId.startsWith(`${sClassId}_`) || tClassId.startsWith(sClassId))) return true;

  // 3. Normalized grade key match (e.g. "kg1", "nur", "c1" / "1", "c10" / "10")
  const extractGradeKey = (str: string) => {
    return str
      .replace(/^(demo_class_|cls_|class_|std_|demo_std_)/i, "")
      .replace(/(_sec_[ab]|_section_[ab]|_a|_b)$/i, "")
      .replace(/[^a-z0-9]/g, "")
      .toLowerCase();
  };

  const sKey = extractGradeKey(sClassId);
  const tKey = extractGradeKey(tClassId);
  if (sKey && tKey && (sKey === tKey || sKey.replace(/^c/i, "") === tKey.replace(/^c/i, ""))) {
    return true;
  }

  // 4. Match by class name if available
  if (tClassName && sClassName) {
    const cleanT = tClassName.replace(/[^a-z0-9]/g, "");
    const cleanS = sClassName.replace(/[^a-z0-9]/g, "");
    if (cleanT && cleanS && (cleanS.includes(cleanT) || cleanT.includes(cleanS))) {
      return true;
    }
  }

  // 5. Match student ID prefix (e.g. demo_std_kg1_... or demo_student_kg1_...)
  if (student.id && tKey) {
    const stdIdClean = student.id.toLowerCase();
    if (stdIdClean.includes(`_${tKey}_`) || stdIdClean.includes(`_${tKey.replace(/^c/i, "")}_`)) {
      return true;
    }
  }

  return false;
};

export const getActiveCloudStudents = async (
  schoolId: string,
  forceRefresh = false
): Promise<{ students: SchoolStudent[]; cloudVerified: boolean; rawAllRecords: SchoolStudent[] }> => {
  if (!schoolId) return { students: [], cloudVerified: false, rawAllRecords: [] };
  const cacheKey = `${LOCAL_STUDENTS_PREFIX}${schoolId}`;

  return dedupInflight(`getActiveCloudStudents_${schoolId}_${forceRefresh ? "f" : "c"}`, async () => {
    const useDemo = shouldUseDemoForSchool(schoolId);
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "students",
      cacheKey,
      () => getLocalStudents(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      5 * 60 * 1000
    );

    const localActive = getLocalStudents(schoolId).filter(
      (s) => isActiveSchoolStudentRecord(s) && (useDemo || !isDemoRecord(s))
    );

    if (!forceRefresh && !fetch) {
      return { students: localActive, cloudVerified: true, rawAllRecords: localActive };
    }

    const rawMap = new Map<string, SchoolStudent>();
    let fsOk = false;
    let rtdbOk = false;

    // Firestore-first (RTDB fallback only if Firestore fails)
    if (db) {
      try {
        const snap: any = await withTimeout(getDocs(col(`schools/${schoolId}/students`)), 3500);
        fsOk = true;
        (snap?.docs || []).forEach((docSnap: any) => {
          const data = docSnap.data() as SchoolStudent;
          const sid = data?.id || docSnap.id;
          if (!sid) return;
          if (!useDemo && isDemoRecord(data)) return;
          rawMap.set(sid, { ...data, id: sid, schoolId: data?.schoolId || schoolId });
        });
      } catch {}
    }

    if (!fsOk && rtdb) {
      try {
        const snap: any = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students`)), 3000);
        rtdbOk = true;
        const val = snap?.val?.();
        if (val && typeof val === "object") {
          Object.entries(val).forEach(([k, v]: [string, any]) => {
            if (!v || typeof v !== "object") return;
            const sid = v.id || k;
            if (!useDemo && isDemoRecord(v)) return;
            rawMap.set(sid, { ...v, id: sid, schoolId: v.schoolId || schoolId } as SchoolStudent);
          });
        }
      } catch {}
    }

    const cloudVerified = fsOk || rtdbOk;
    const rawAllRecords = Array.from(rawMap.values());
    const activeCloud = rawAllRecords.filter((s) => isActiveSchoolStudentRecord(s));

    if (cloudVerified) {
      setLocalStudents(schoolId, activeCloud);
      markSchoolCacheFresh(cacheKey, remoteVer);
      return { students: activeCloud, cloudVerified: true, rawAllRecords };
    }

    if (localActive.length > 0) markSchoolCacheFresh(cacheKey, remoteVer);
    return { students: localActive, cloudVerified: false, rawAllRecords: localActive };
  });
};

export const getStudents = async (schoolId: string, classId?: string, className?: string, sessionId?: string): Promise<SchoolStudent[]> => {
  await whenSchoolIdbReady();
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  const local = getLocalStudents(schoolId);
  const matchingLocal = local.filter((s: any) => {
    if (!isActiveSchoolStudentRecord(s)) return false;
    if (classId && !isStudentInClass(s, classId, className)) return false;
    if (sessionId && s.sessionId && s.sessionId !== sessionId) return false;
    return true;
  });

  if (!useDemo) {
    const realLocal = matchingLocal.filter(s => !isDemoRecord(s));
    if (realLocal.length > 0) return realLocal;
    const { students: cloudStudents } = await getActiveCloudStudents(schoolId);
    if (cloudStudents.length > 0) {
      return cloudStudents.filter((s: any) => {
        if (classId && !isStudentInClass(s, classId, className)) return false;
        if (sessionId && s.sessionId && s.sessionId !== sessionId) return false;
        return true;
      });
    }
    return realLocal;
  }

  if (matchingLocal.length > 0) {
    return matchingLocal;
  }

  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.students && demo.students.length > 0) {
      const targetSess = sessionId || demo.session?.id;
      const sessFiltered = demo.students.filter(s => !targetSess || s.sessionId === targetSess);
      const basePool = sessFiltered.length > 0 ? sessFiltered : demo.students.filter(s => s.sessionId === demo.session?.id);
      const filteredDemo = basePool.filter(s => {
        if (!isActiveSchoolStudentRecord(s)) return false;
        if (classId && !isStudentInClass(s, classId, className)) return false;
        return true;
      });
      return filteredDemo;
    }
    return [];
  }

  const realLocal = matchingLocal.filter(s => !isDemoRecord(s));
  if (realLocal.length > 0) {
    return realLocal;
  }

  const { students: cloudStudents } = await getActiveCloudStudents(schoolId);
  if (cloudStudents.length > 0) {
    return cloudStudents.filter((s: any) => {
      if (isDemoRecord(s)) return false;
      if (classId && !isStudentInClass(s, classId, className)) return false;
      if (sessionId && s.sessionId !== sessionId) return false;
      return true;
    });
  }

  return realLocal;
};

export const subscribeToStudents = (schoolId: string, classId: string, cb: (students: SchoolStudent[]) => void, sessionId?: string) => {
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  let active = true;

  const deliverLocal = () => {
    if (!active) return;
    if (useDemo) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.students && demo.students.length > 0) {
        const targetSess = sessionId || demo.session?.id;
        const sessFiltered = demo.students.filter(s => !targetSess || s.sessionId === targetSess);
        const basePool = sessFiltered.length > 0 ? sessFiltered : demo.students.filter(s => s.sessionId === demo.session?.id);
        const filteredDemo = basePool.filter(s => {
          if (s.active === false) return false;
          if (classId && !isStudentInClass(s, classId)) return false;
          return true;
        });
        cb(filteredDemo);
        return;
      }
    }
    const local = getLocalStudents(schoolId);
    const matchingLocal = local.filter(s => {
      if (!isActiveSchoolStudentRecord(s) || isDemoRecord(s)) return false;
      if (classId && !isStudentInClass(s, classId)) return false;
      if (sessionId && s.sessionId && s.sessionId !== sessionId) return false;
      return true;
    });
    cb(matchingLocal.sort((a, b) => (a.rollNo || "").localeCompare(b.rollNo || "", undefined, { numeric: true })));
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    if (!useDemo) {
      getActiveCloudStudents(schoolId)
        .then(() => {
          if (active) deliverLocal();
        })
        .catch(() => {});
    }
  });

  const onLocalStudentSync = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    deliverLocal();
  };

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("student-updated", onLocalStudentSync);
    window.addEventListener("student-deleted", onLocalStudentSync);
    window.addEventListener("student-restored", onLocalStudentSync);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("student-updated", onLocalStudentSync);
      window.removeEventListener("student-deleted", onLocalStudentSync);
      window.removeEventListener("student-restored", onLocalStudentSync);
    }
  };
};

export const subscribeToAllStudents = (schoolId: string, cb: (students: SchoolStudent[]) => void) => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  let active = true;

  const deliverLocal = () => {
    if (!active) return;
    const local = getLocalStudents(schoolId);
    const demo = useDemo ? getDemoSchoolDataset(true) : null;
    if (!useDemo) {
      cb(local.filter(s => isActiveSchoolStudentRecord(s) && !isDemoRecord(s)));
    } else if (demo && demo.students && demo.students.length > 0) {
      const localMap = new Map(local.map(s => [s.id, s]));
      const primaryPool = demo.students.filter(s => !demo.session?.id || s.sessionId === demo.session.id);
      const basePool = primaryPool.length > 0 ? primaryPool : demo.students;
      const merged = basePool.map(s => localMap.get(s.id) || s);
      cb(merged.filter(s => isActiveSchoolStudentRecord(s)));
    } else {
      cb(local.filter(s => isActiveSchoolStudentRecord(s)));
    }
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    if (!useDemo) {
      getActiveCloudStudents(schoolId)
        .then(() => {
          if (active) deliverLocal();
        })
        .catch(() => {});
    }
  });

  const onLocalStudentSync = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    deliverLocal();
  };

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", onLocalStudentSync);
    window.addEventListener("student-deleted", onLocalStudentSync);
    window.addEventListener("student-restored", onLocalStudentSync);
    window.addEventListener("student-updated", onLocalStudentSync);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", onLocalStudentSync);
      window.removeEventListener("student-deleted", onLocalStudentSync);
      window.removeEventListener("student-restored", onLocalStudentSync);
      window.removeEventListener("student-updated", onLocalStudentSync);
    }
  };
};

export const subscribeToStudent = (
  schoolId: string,
  studentId: string,
  cb: (student: SchoolStudent | null) => void
) => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  let active = true;

  const deliverLocal = (): SchoolStudent | null => {
    if (!active) return null;
    const local = getLocalStudents(schoolId);
    const found = local.find(s => s.id === studentId || (s.admissionNo && s.admissionNo.toLowerCase() === studentId.toLowerCase()));
    if (found) {
      if (isActiveSchoolStudentRecord(found)) {
        cb(found);
      } else {
        cb({ ...found, active: false, isDeleted: true, status: "deleted" } as any);
      }
      return found;
    } else if (useDemo) {
      const demo = getDemoSchoolDataset(true);
      const demoFound = demo?.students?.find(s => s.id === studentId || (s.admissionNo && s.admissionNo.toLowerCase() === studentId.toLowerCase()));
      if (demoFound) {
        cb(demoFound);
        return demoFound;
      }
    }
    return null;
  };

  void whenSchoolIdbReady().then(async () => {
    if (!active) return;
    const localFound = deliverLocal();
    if (useDemo) return;
    const singleCacheKey = `nst_std_single_${schoolId}_${studentId}`;
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "students",
      singleCacheKey,
      () => Boolean(localFound),
      5 * 60 * 1000
    );
    if (!fetch || !active) return;
    try {
      let cloudStudent: SchoolStudent | null = null;
      if (db) {
        try {
          const snap = await withTimeout(getDoc(d(`schools/${schoolId}/students/${studentId}`)), 2500);
          if (snap.exists()) cloudStudent = snap.data() as SchoolStudent;
        } catch {}
      }
      if (!cloudStudent && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 2000);
          if (snap.exists()) cloudStudent = snap.val() as SchoolStudent;
        } catch {}
      }
      if (cloudStudent && active) {
        const cur = getLocalStudents(schoolId);
        setLocalStudents(schoolId, [cloudStudent, ...cur.filter(s => s.id !== cloudStudent!.id)]);
        markSchoolCacheFresh(singleCacheKey, remoteVer);
        cb(cloudStudent);
      }
    } catch {}
  });

  const handleLocalUpdate = (e: any) => {
    if (e.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    if (
      e.detail?.studentId === studentId ||
      e.detail?.data?.id === studentId ||
      (e.detail?.data?.admissionNo && e.detail.data.admissionNo.toLowerCase() === studentId.toLowerCase())
    ) {
      if (e.detail?.data) {
        cb(e.detail.data as SchoolStudent);
      } else {
        deliverLocal();
      }
    }
  };
  const handleStudentDeleted = (e: any) => {
    if (e.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    if (e.detail?.studentId === studentId) {
      cb({ id: studentId, schoolId, active: false, isDeleted: true, status: "deleted" } as any);
    }
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("student-updated", handleLocalUpdate);
    window.addEventListener("student-deleted", handleStudentDeleted);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("student-updated", handleLocalUpdate);
      window.removeEventListener("student-deleted", handleStudentDeleted);
    }
  };
};

export const updateStudent = async (schoolId: string, studentId: string, data: Partial<SchoolStudent>) => {
  const prepared: any = { ...data };
  if (prepared.photoUrl && typeof prepared.photoUrl === "string" && prepared.photoUrl.startsWith("data:image/")) {
    prepared.photoUrl = await ensureCloudImageUrl(prepared.photoUrl, `std_${schoolId}_${studentId}`);
  }
  const sanitized = sanitizeForFirestore(prepared);
  let updatedRecord: SchoolStudent | null = null;
  try {
    const local = getLocalStudents(schoolId);
    if (local && local.length > 0) {
      const next = local.map((s: any) => {
        if (s.id === studentId || s.admissionNo === studentId) {
          updatedRecord = { ...s, ...sanitized };
          return updatedRecord;
        }
        return s;
      });
      setLocalStudents(schoolId, next);
      markSchoolCacheFresh(`${LOCAL_STUDENTS_PREFIX}${schoolId}`);
      markSchoolCacheFresh(`nst_std_single_${schoolId}_${studentId}`);
    }
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("student-updated", {
        detail: { schoolId, studentId, data: updatedRecord || sanitized }
      })
    );
  }

  if (rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/students/${studentId}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/students/${studentId}`), sanitized, { merge: true }), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "students");
  const st = typeof (data as any)?.status === "string" ? (data as any).status.toLowerCase() : "";
  if (
    data?.active === false ||
    data?.tcIssued === true ||
    (data as any)?.isDeleted === true ||
    st === "deleted" ||
    st === "disabled" ||
    st === "inactive"
  ) {
    import("./utils/faceRecognitionEngineV2")
      .then((m) => m.deleteFaceDescriptor(studentId, schoolId))
      .catch(() => {});
  }
};

export const deleteStudent = async (schoolId: string, studentId: string) => {
  if (!schoolId || !studentId) return;
  const deletedAt = new Date().toISOString();
  const deletePatch = {
    active: false,
    isDeleted: true,
    status: "deleted",
    deletedAt,
  };

  // 0. Capture full student snapshot for Recycle Bin before removing from active list
  let studentSnapshot: any = null;
  try {
    studentSnapshot = getLocalStudents(schoolId).find((s) => s.id === studentId) || null;
  } catch {}
  if (!studentSnapshot && rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 1500);
      if (snap && snap.exists()) studentSnapshot = snap.val();
    } catch {}
  }
  if (!studentSnapshot && db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/students/${studentId}`)), 1500);
      if (snap && snap.exists()) studentSnapshot = snap.data();
    } catch {}
  }

  const binRecord = sanitizeForFirestore({
    ...(studentSnapshot || { id: studentId, schoolId, name: "Removed Student" }),
    id: studentId,
    schoolId,
    deletedAt,
    deletedEntityType: "student",
  });

  try {
    const curBin = getLocalRecycleStudents(schoolId);
    setLocalRecycleStudents(schoolId, [binRecord, ...curBin.filter((item) => item.id !== studentId)]);
    markSchoolCacheFresh(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
  } catch {}

  try {
    const local = getLocalStudents(schoolId);
    setLocalStudents(schoolId, local.filter(s => s.id !== studentId));
    markSchoolCacheFresh(`${LOCAL_STUDENTS_PREFIX}${schoolId}`);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("student-deleted", { detail: { schoolId, studentId } }));
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "student", id: studentId } }));
  }
  if (rtdb) {
    try {
      await Promise.allSettled([
        withTimeout(set(ref(rtdb, `schools/${schoolId}/recycle_bin_students/${studentId}`), binRecord), 2500),
        withTimeout(update(ref(rtdb, `schools/${schoolId}/students/${studentId}`), deletePatch), 2000),
        withTimeout(set(ref(rtdb, `schools/${schoolId}/deleted_students/${studentId}`), { id: studentId, deletedAt }), 2000),
      ]);
    } catch {}
  }
  if (db) {
    try {
      await Promise.allSettled([
        withTimeout(setDoc(d(`schools/${schoolId}/recycle_bin_students/${studentId}`), binRecord), 2500),
        withTimeout(setDoc(d(`schools/${schoolId}/students/${studentId}`), deletePatch, { merge: true }), 2500),
      ]);
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "students");
  touchSchoolSyncVersion(schoolId, "recycle_bin");
  import("./utils/faceRecognitionEngineV2")
    .then((m) => m.deleteFaceDescriptor(studentId, schoolId))
    .catch(() => {});
};

// ── RECYCLE BIN (DELETED TEACHERS & STUDENTS MANAGEMENT) ─────────────────────
export const subscribeToRecycleBin = (
  schoolId: string,
  cb: (data: {
    teachers: Array<SchoolTeacher & { deletedAt?: string }>;
    students: Array<SchoolStudent & { deletedAt?: string }>;
  }) => void
) => {
  if (!schoolId) {
    cb({ teachers: [], students: [] });
    return () => {};
  }

  let active = true;
  const cacheKey = `${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`;

  const emitLocal = () => {
    if (!active) return;
    const teachers = [...getLocalRecycleTeachers(schoolId)].sort((a, b) => (b.deletedAt || "").localeCompare(a.deletedAt || ""));
    const students = [...getLocalRecycleStudents(schoolId)].sort((a, b) => (b.deletedAt || "").localeCompare(a.deletedAt || ""));
    cb({ teachers, students });
  };

  void whenSchoolIdbReady().then(async () => {
    if (!active) return;
    emitLocal();
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "recycle_bin",
      cacheKey,
      () => isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000) || getLocalRecycleTeachers(schoolId).length > 0 || getLocalRecycleStudents(schoolId).length > 0,
      10 * 60 * 1000
    );
    if (!fetch || !active) return;

    await dedupInflight(`getRecycleBin_${schoolId}`, async () => {
      const tMap = new Map<string, SchoolTeacher & { deletedAt?: string }>();
      const sMap = new Map<string, SchoolStudent & { deletedAt?: string }>();
      let fsOk = false;

      if (db) {
        try {
          const [tSnap, sSnap] = await Promise.all([
            withTimeout(getDocs(col(`schools/${schoolId}/recycle_bin_teachers`)), 2500),
            withTimeout(getDocs(col(`schools/${schoolId}/recycle_bin_students`)), 2500),
          ]);
          fsOk = true;
          tSnap.docs.forEach((docSnap) => {
            const data = docSnap.data() as any;
            const id = data?.id || docSnap.id;
            if (id) tMap.set(id, { ...data, id, schoolId: data?.schoolId || schoolId });
          });
          sSnap.docs.forEach((docSnap) => {
            const data = docSnap.data() as any;
            const id = data?.id || docSnap.id;
            if (id) sMap.set(id, { ...data, id, schoolId: data?.schoolId || schoolId });
          });
        } catch {}
      }

      if (!fsOk && rtdb) {
        try {
          const [tSnap, sSnap]: any = await Promise.all([
            withTimeout(get(ref(rtdb, `schools/${schoolId}/recycle_bin_teachers`)), 2500).catch(() => null),
            withTimeout(get(ref(rtdb, `schools/${schoolId}/recycle_bin_students`)), 2500).catch(() => null),
          ]);
          const tVal = tSnap?.val?.();
          if (tVal && typeof tVal === "object") {
            Object.entries(tVal).forEach(([k, v]: [string, any]) => {
              if (v && typeof v === "object") tMap.set(v.id || k, { ...v, id: v.id || k, schoolId: v.schoolId || schoolId });
            });
          }
          const sVal = sSnap?.val?.();
          if (sVal && typeof sVal === "object") {
            Object.entries(sVal).forEach(([k, v]: [string, any]) => {
              if (v && typeof v === "object") sMap.set(v.id || k, { ...v, id: v.id || k, schoolId: v.schoolId || schoolId });
            });
          }
          if (tSnap || sSnap) fsOk = true;
        } catch {}
      }

      if (fsOk) {
        setLocalRecycleTeachers(schoolId, Array.from(tMap.values()));
        setLocalRecycleStudents(schoolId, Array.from(sMap.values()));
        markSchoolCacheFresh(cacheKey, remoteVer);
      }
    });

    if (active) emitLocal();
  });

  const onBinEvent = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    emitLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("recycle-bin-updated", onBinEvent);
    window.addEventListener("school-idb-hydrated", emitLocal);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("recycle-bin-updated", onBinEvent);
      window.removeEventListener("school-idb-hydrated", emitLocal);
    }
  };
};

export const restoreTeacherFromRecycleBin = async (schoolId: string, teacherId: string): Promise<SchoolTeacher | null> => {
  if (!schoolId || !teacherId) return null;
  let snapshot: any = getLocalRecycleTeachers(schoolId).find((t) => t.id === teacherId) || null;
  if (!snapshot && db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2000);
      if (snap && snap.exists()) snapshot = snap.data();
    } catch {}
  }
  if (!snapshot && rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2000);
      if (snap && snap.exists()) snapshot = snap.val();
    } catch {}
  }
  if (!snapshot) return null;

  const { deletedAt: _d, deletedEntityType: _et, isDeleted: _id, ...cleanFields } = snapshot;
  const restoredTeacher: SchoolTeacher = {
    ...cleanFields,
    id: teacherId,
    schoolId,
    active: true,
    status: "active",
  };

  // Clear local & cloud tombstones and save restored teacher
  clearTeacherDeletedLocally(schoolId, teacherId);
  await saveTeacher(restoredTeacher);

  // Remove from Recycle Bin stores
  setLocalRecycleTeachers(schoolId, getLocalRecycleTeachers(schoolId).filter((t) => t.id !== teacherId));
  markSchoolCacheFresh(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("teacher-restored", { detail: { schoolId, teacher: restoredTeacher } }));
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "teacher", removedId: teacherId } }));
  }

  const cleanupTasks: Promise<any>[] = [];
  if (rtdb) {
    cleanupTasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2500).catch(() => {}));
  }
  if (db) {
    cleanupTasks.push(withTimeout(deleteDoc(d(`schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2500).catch(() => {}));
  }
  await Promise.allSettled(cleanupTasks);
  touchSchoolSyncVersion(schoolId, "recycle_bin");
  return restoredTeacher;
};

export const restoreStudentFromRecycleBin = async (schoolId: string, studentId: string): Promise<SchoolStudent | null> => {
  if (!schoolId || !studentId) return null;
  let snapshot: any = getLocalRecycleStudents(schoolId).find((s) => s.id === studentId) || null;
  if (!snapshot && db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/recycle_bin_students/${studentId}`)), 2000);
      if (snap && snap.exists()) snapshot = snap.data();
    } catch {}
  }
  if (!snapshot && rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/recycle_bin_students/${studentId}`)), 2000);
      if (snap && snap.exists()) snapshot = snap.val();
    } catch {}
  }
  if (!snapshot && rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 2000);
      if (snap && snap.exists()) snapshot = snap.val();
    } catch {}
  }
  if (!snapshot) return null;

  const { deletedAt: _d, deletedEntityType: _et, isDeleted: _id, ...cleanFields } = snapshot;
  const restoredStudent: SchoolStudent = sanitizeForFirestore({
    ...cleanFields,
    id: studentId,
    schoolId,
    active: true,
    isDeleted: false,
    status: "active",
  });

  // Update active students local cache + cloud
  const current = getLocalStudents(schoolId);
  setLocalStudents(schoolId, [restoredStudent, ...current.filter((s) => s.id !== studentId)]);
  markSchoolCacheFresh(`${LOCAL_STUDENTS_PREFIX}${schoolId}`);
  setLocalRecycleStudents(schoolId, getLocalRecycleStudents(schoolId).filter((s) => s.id !== studentId));
  markSchoolCacheFresh(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("student-updated", { detail: { schoolId, studentId, data: restoredStudent } }));
    window.dispatchEvent(new CustomEvent("student-restored", { detail: { schoolId, student: restoredStudent } }));
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "student", removedId: studentId } }));
  }

  const tasks: Promise<any>[] = [];
  if (rtdb) {
    tasks.push(withTimeout(set(ref(rtdb, `schools/${schoolId}/students/${studentId}`), restoredStudent), 2500).catch(() => {}));
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/deleted_students/${studentId}`)), 2500).catch(() => {}));
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/recycle_bin_students/${studentId}`)), 2500).catch(() => {}));
  }
  if (db) {
    tasks.push(withTimeout(setDoc(d(`schools/${schoolId}/students/${studentId}`), restoredStudent), 2500).catch(() => {}));
    tasks.push(withTimeout(deleteDoc(d(`schools/${schoolId}/recycle_bin_students/${studentId}`)), 2500).catch(() => {}));
  }
  await Promise.allSettled(tasks);
  touchSchoolSyncVersion(schoolId, "students");
  touchSchoolSyncVersion(schoolId, "recycle_bin");
  return restoredStudent;
};

export const permanentDeleteTeacherFromBin = async (schoolId: string, teacherId: string): Promise<void> => {
  if (!schoolId || !teacherId) return;
  setLocalRecycleTeachers(schoolId, getLocalRecycleTeachers(schoolId).filter((t) => t.id !== teacherId));
  markSchoolCacheFresh(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "teacher", removedId: teacherId } }));
  }
  const tasks: Promise<any>[] = [];
  if (rtdb) {
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2500).catch(() => {}));
  }
  if (db) {
    tasks.push(withTimeout(deleteDoc(d(`schools/${schoolId}/recycle_bin_teachers/${teacherId}`)), 2500).catch(() => {}));
  }
  await Promise.allSettled(tasks);
  touchSchoolSyncVersion(schoolId, "recycle_bin");
};

export const permanentDeleteStudentFromBin = async (schoolId: string, studentId: string): Promise<void> => {
  if (!schoolId || !studentId) return;
  setLocalRecycleStudents(schoolId, getLocalRecycleStudents(schoolId).filter((s) => s.id !== studentId));
  markSchoolCacheFresh(`${LOCAL_RECYCLE_STUDENTS_PREFIX}${schoolId}`);
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("recycle-bin-updated", { detail: { schoolId, type: "student", removedId: studentId } }));
  }
  const tasks: Promise<any>[] = [];
  if (rtdb) {
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/recycle_bin_students/${studentId}`)), 2500).catch(() => {}));
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 2500).catch(() => {}));
    tasks.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/deleted_students/${studentId}`)), 2500).catch(() => {}));
  }
  if (db) {
    tasks.push(withTimeout(deleteDoc(d(`schools/${schoolId}/recycle_bin_students/${studentId}`)), 2500).catch(() => {}));
    tasks.push(withTimeout(deleteDoc(d(`schools/${schoolId}/students/${studentId}`)), 2500).catch(() => {}));
  }
  await Promise.allSettled(tasks);
  touchSchoolSyncVersion(schoolId, "recycle_bin");
};

// ── ATTENDANCE ───────────────────────────────────────────────────────────────
const LOCAL_ATTENDANCE_PREFIX = "nst_school_attendance_";

export const getLocalAttendance = (schoolId: string): AttendanceRecord[] => {
  try {
    const list = getSchoolCacheSync<AttendanceRecord[]>(`${LOCAL_ATTENDANCE_PREFIX}${schoolId}`, []);
    if (!shouldUseDemoForSchool(schoolId)) {
      return Array.isArray(list) ? list.filter(r => !isDemoRecord(r)) : [];
    }
    if (Array.isArray(list) && list.length > 0) return list;
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.attendanceRecords && demo.attendanceRecords.length > 0) {
      return demo.attendanceRecords;
    }
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalAttendance = (schoolId: string, records: AttendanceRecord[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_ATTENDANCE_PREFIX}${schoolId}`, Array.isArray(records) ? records : []);
  } catch {}
};

export const saveAttendance = async (record: AttendanceRecord) => {
  const sanitized = sanitizeForFirestore(record);
  const id = `${record.classId}_${record.date}`;
  const docFreshKey = `nst_att_doc_${record.schoolId}_${id}`;

  // 0. No-op skip: if IndexedDB already holds exact same records & doc was recently synced, avoid cloud write!
  try {
    const prev = getLocalAttendance(record.schoolId).find((r: any) => `${r.classId}_${r.date}` === id);
    if (
      prev &&
      isSchoolCacheFresh(docFreshKey, 30 * 60 * 1000) &&
      JSON.stringify(prev.students || {}) === JSON.stringify(sanitized.students || {})
    ) {
      return;
    }
  } catch {}

  // 1. Immediately cache in IndexedDB
  try {
    const current = getLocalAttendance(record.schoolId);
    const updated = [sanitized, ...current.filter((r: any) => `${r.classId}_${r.date}` !== id)];
    setLocalAttendance(record.schoolId, updated);
    markSchoolCacheFresh(`${LOCAL_ATTENDANCE_PREFIX}${record.schoolId}`);
    markSchoolCacheFresh(docFreshKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("attendance-updated", { detail: { schoolId: record.schoolId, classId: record.classId, date: record.date, record: sanitized } }));
  }

  // 2. Firestore-first write (RTDB fallback only if Firestore fails — cuts attendance cloud writes by 50%)
  let firestoreOk = false;
  let rtdbOk = false;
  let lastError: any = null;

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${record.schoolId}/attendance/${id}`), sanitized), 3000);
      firestoreOk = true;
    } catch (e) {
      lastError = e;
      console.warn("[school-firebase] saveAttendance Firestore failed:", e);
    }
  }

  if (!firestoreOk && rtdb) {
    try {
      await ensureFirebaseAuthSession().catch(() => null);
      await withTimeout(set(ref(rtdb, `schools/${record.schoolId}/attendance/${id}`), sanitized), 3000);
      rtdbOk = true;
    } catch (e) {
      if (!lastError) lastError = e;
      console.warn("[school-firebase] saveAttendance RTDB failed:", e);
    }
  }

  if (!firestoreOk && !rtdbOk) {
    const rawMsg = String(lastError?.message || "");
    if (/permission[_-]?denied/i.test(rawMsg)) {
      throw new Error("क्लाउड सेव अनुमति (Permission) त्रुटि — कृपया ऐप रीफ्रेश या री-लॉगिन करके दोबारा प्रयास करें।");
    }
    throw new Error(rawMsg || "Cloud attendance write failed (both Firestore & RTDB unreachable).");
  }
  touchSchoolSyncVersion(record.schoolId, "attendance");
};

export const getAttendance = async (schoolId: string, classId: string, date: string): Promise<AttendanceRecord | null> => {
  await whenSchoolIdbReady();
  const id = `${classId}_${date}`;
  const local = getLocalAttendance(schoolId).find((r: any) => `${r.classId}_${r.date}` === id || (r.classId === classId && r.date === date));
  if (local) return local;
  const missKey = `nst_att_doc_${schoolId}_${id}`;
  if (isSchoolCacheFresh(missKey, 5 * 60 * 1000)) return null;

  return dedupInflight(`getAttendance_${schoolId}_${id}`, async () => {
    if (db) {
      try {
        const snap = await withTimeout(getDoc(d(`schools/${schoolId}/attendance/${id}`)), 2500);
        if (snap && snap.exists()) {
          const rec = snap.data() as AttendanceRecord;
          const cur = getLocalAttendance(schoolId);
          setLocalAttendance(schoolId, [rec, ...cur.filter((r: any) => `${r.classId}_${r.date}` !== id)]);
          markSchoolCacheFresh(missKey);
          return rec;
        }
        markSchoolCacheFresh(missKey);
      } catch {}
    }
    return null;
  });
};

export const getMonthlyAttendance = async (schoolId: string, classId: string, month: string): Promise<AttendanceRecord[]> => {
  await whenSchoolIdbReady();
  const local = getLocalAttendance(schoolId).filter((r: any) => r.classId === classId && String(r.date || "").startsWith(month));
  const monthCacheKey = `nst_att_m_${schoolId}_${classId}_${month}`;
  if (local.length > 0 || isSchoolCacheFresh(monthCacheKey, 5 * 60 * 1000)) return local;

  return dedupInflight(`getMonthlyAtt_${schoolId}_${classId}_${month}`, async () => {
    if (db) {
      try {
        const snap = await withTimeout(getDocs(query(col(`schools/${schoolId}/attendance`), where("classId", "==", classId))), 2500);
        const docs = snap.docs
          .map(d => d.data() as AttendanceRecord)
          .filter(r => r.classId === classId && String(r.date || "").startsWith(month));
        markSchoolCacheFresh(monthCacheKey);
        if (docs.length > 0) {
          const current = getLocalAttendance(schoolId);
          const merged = [...docs, ...current.filter(c => !docs.some(d => `${d.classId}_${d.date}` === `${c.classId}_${c.date}`))];
          setLocalAttendance(schoolId, merged);
          return docs;
        }
      } catch {}
    }
    return local;
  });
};

export const getAllSchoolAttendance = async (schoolId: string): Promise<AttendanceRecord[]> => {
  const cacheKey = `${LOCAL_ATTENDANCE_PREFIX}${schoolId}`;
  return dedupInflight(`getAllAtt_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "attendance",
      cacheKey,
      () => getLocalAttendance(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      5 * 60 * 1000
    );

    const local = getLocalAttendance(schoolId);
    if (!fetch) return local;

    const byKey = new Map<string, AttendanceRecord>();
    local.forEach((r: any) => {
      if (r?.classId && r?.date) byKey.set(`${r.classId}_${r.date}`, r);
    });

    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/attendance`)), 3500);
        fsOk = true;
        if (snap?.docs) {
          snap.docs.forEach((docSnap: any) => {
            const r = docSnap.data() as AttendanceRecord;
            if (r?.classId && r?.date) byKey.set(`${r.classId}_${r.date}`, r);
          });
        }
      } catch {}
    }

    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/attendance`)), 3000);
        const val = (snap as any)?.val?.();
        if (val && typeof val === "object") {
          Object.values(val).forEach((r: any) => {
            if (r?.classId && r?.date && !byKey.has(`${r.classId}_${r.date}`)) {
              byKey.set(`${r.classId}_${r.date}`, r as AttendanceRecord);
            }
          });
        }
      } catch {}
    }

    const merged = Array.from(byKey.values());
    if (merged.length > 0 || fsOk) {
      setLocalAttendance(schoolId, merged);
      markSchoolCacheFresh(cacheKey, remoteVer);
    }
    return merged;
  });
};

export const subscribeToAttendance = (
  schoolId: string, classId: string, date: string, cb: (r: AttendanceRecord | null) => void
) => {
  const id = `${classId}_${date}`;
  let active = true;

  const deliverLocal = () => {
    if (!active) return null;
    const local = getLocalAttendance(schoolId).find((r: any) => `${r.classId}_${r.date}` === id) || null;
    if (local) cb(local);
    return local;
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    const local = deliverLocal();
    getAttendance(schoolId, classId, date)
      .then((rec) => {
        if (active && (rec || !local)) cb(rec);
      })
      .catch(() => {
        if (active && !local) cb(null);
      });
  });

  const onAttUpdated = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    if (e?.detail?.classId === classId && e?.detail?.date === date && e?.detail?.record) {
      cb(e.detail.record as AttendanceRecord);
    } else {
      deliverLocal();
    }
  };

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("attendance-updated", onAttUpdated);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("attendance-updated", onAttUpdated);
    }
  };
};

export const calculateStayDuration = (
  inTimeStr?: string,
  outTimeStr?: string,
  inTimestamp?: number,
  outTimestamp?: number
): string => {
  // Prefer accurate epoch timestamps (handles midnight rollover & multi-day shifts)
  if (
    typeof inTimestamp === "number" &&
    typeof outTimestamp === "number" &&
    Number.isFinite(inTimestamp) &&
    Number.isFinite(outTimestamp) &&
    outTimestamp >= inTimestamp
  ) {
    const diffMins = Math.floor((outTimestamp - inTimestamp) / 60000);
    const hours = Math.floor(diffMins / 60);
    const mins = diffMins % 60;
    return `${hours > 0 ? `${hours}h ` : ""}${mins}m`;
  }

  if (!inTimeStr || !outTimeStr) return "";
  try {
    const parseTime = (tStr: string) => {
      const match = tStr.match(/(\d+):(\d+)(?::(\d+))?\s*(AM|PM)?/i);
      if (!match) return null;
      let h = parseInt(match[1], 10);
      const m = parseInt(match[2], 10);
      const ampm = match[4]?.toUpperCase();
      if (ampm === "PM" && h < 12) h += 12;
      if (ampm === "AM" && h === 12) h = 0;
      return h * 60 + m;
    };
    const inMins = parseTime(inTimeStr);
    const outMins = parseTime(outTimeStr);
    if (inMins === null || outMins === null) return "";
    // Handle midnight rollover if outMins < inMins
    const diff = outMins >= inMins ? outMins - inMins : (24 * 60 - inMins) + outMins;
    const hours = Math.floor(diff / 60);
    const mins = diff % 60;
    return `${hours > 0 ? `${hours}h ` : ""}${mins}m`;
  } catch {
    return "";
  }
};

export const markStudentQrAttendance = async (params: {
  schoolId: string;
  classId: string;
  studentId: string;
  studentName?: string;
  rollNo?: string;
  sessionId?: string;
  date?: string;
  markedBy?: string;
  scanMode?: "auto" | "in" | "out";
  cutoffTime?: string; // e.g. "09:30" (Late IN cutoff)
  outStartTime?: string; // e.g. "12:30" (Auto OUT dispersal start time)
  prayerTime?: string; // legacy alias
}): Promise<{
  success: boolean;
  message: string;
  action: "in" | "out";
  inTime?: string;
  outTime?: string;
  stayDuration?: string;
  isLate?: boolean;
  alreadyMarked?: boolean;
  tooEarlyForOut?: boolean;
  cloudSaved?: boolean;
  record?: AttendanceRecord;
}> => {
  const date = params.date || todayStr();
  const now = new Date();
  const nowMs = now.getTime();
  const timeFormatted = now.toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
  const docId = `${params.classId}_${date}`;

  if (!db && !rtdb) {
    return {
      success: false,
      action: "in",
      cloudSaved: false,
      message: "Firebase उपलब्ध नहीं है। क्लाउड सेविंग के बिना हाजिरी दर्ज नहीं की जा सकती।"
    };
  }

  try {
    const docRef = d(`schools/${params.schoolId}/attendance/${docId}`);
    let storedInCutoff: string | null = null;
    let storedOutStart: string | null = null;
    try {
      if (typeof window !== "undefined") {
        storedInCutoff = localStorage.getItem(`nst_kiosk_in_cutoff_${params.schoolId}`);
        storedOutStart = localStorage.getItem(`nst_kiosk_out_start_${params.schoolId}`);
      }
    } catch {}

    const cutoff = params.cutoffTime || storedInCutoff || "09:30";
    const [cutHourRaw, cutMinRaw] = cutoff.split(":").map(Number);
    const cutHour = Number.isFinite(cutHourRaw) ? cutHourRaw : 9;
    const cutMin = Number.isFinite(cutMinRaw) ? cutMinRaw : 30;
    const isPastCutoff = now.getHours() > cutHour || (now.getHours() === cutHour && now.getMinutes() > cutMin);

    let outStartMinutes = 12 * 60 + 30; // Default 12:30 PM
    let outStartRaw = params.outStartTime || storedOutStart || "";
    if (!outStartRaw && params.prayerTime) {
      const [pHour, pMin] = params.prayerTime.split(":").map(Number);
      outStartMinutes = (Number.isFinite(pHour) ? pHour : 9) * 60 + (Number.isFinite(pMin) ? pMin : 0) + 60;
      const oh = Math.floor(outStartMinutes / 60) % 24;
      const om = outStartMinutes % 60;
      outStartRaw = `${String(oh).padStart(2, "0")}:${String(om).padStart(2, "0")}`;
    } else {
      if (!outStartRaw) outStartRaw = "12:30";
      const [oH, oM] = outStartRaw.split(":").map(Number);
      outStartMinutes = (Number.isFinite(oH) ? oH : 12) * 60 + (Number.isFinite(oM) ? oM : 30);
    }

    const outPeriod = Math.floor(outStartMinutes / 60) >= 12 ? "PM" : "AM";
    const outHour12 = Math.floor(outStartMinutes / 60) % 12 === 0 ? 12 : Math.floor(outStartMinutes / 60) % 12;
    const outStart12h = `${String(outHour12).padStart(2, "0")}:${String(outStartMinutes % 60).padStart(2, "0")} ${outPeriod}`;
    const nowMinutes = now.getHours() * 60 + now.getMinutes();

    type TxOutcome = {
      committed: boolean;
      result: {
        success: boolean;
        message: string;
        action: "in" | "out";
        inTime?: string;
        outTime?: string;
        stayDuration?: string;
        isLate?: boolean;
        alreadyMarked?: boolean;
        tooEarlyForOut?: boolean;
        cloudSaved?: boolean;
        record?: AttendanceRecord;
      };
    };

    // ── ATOMIC FIRESTORE TRANSACTION (with RTDB fallback if Firestore fails or auth is absent) ──
    const studentDocRef = d(`schools/${params.schoolId}/students/${params.studentId}`);
    const computeQrAttendanceOutcome = (
      existing: AttendanceRecord | null,
      stData: any | null
    ): TxOutcome => {
      if (stData) {
        const stStatus = typeof stData?.status === "string" ? stData.status.toLowerCase() : "";
        if (
          stData?.active === false ||
          stData?.isDeleted === true ||
          stData?.tcIssued === true ||
          stStatus === "deleted" ||
          stStatus === "disabled" ||
          stStatus === "inactive"
        ) {
          return {
            committed: false,
            result: {
              success: false,
              action: "in",
              alreadyMarked: false,
              cloudSaved: false,
              message: `⚠️ ${params.studentName || 'छात्र'} का खाता निष्क्रिय (Inactive / Deleted / TC Issued) है। हाजिरी दर्ज नहीं की जा सकती।`
            }
          };
        }
      }

      const studentsMap = existing?.students ? { ...existing.students } : {};
      const existingEntry = studentsMap[params.studentId];

      let action: "in" | "out" = "in";
      if (params.scanMode === "out") {
        action = "out";
      } else if (params.scanMode === "in") {
        action = "in";
      } else {
        if (!existingEntry?.inTime) {
          action = "in";
        } else if (!existingEntry?.outTime) {
          if (nowMinutes >= outStartMinutes) {
            action = "out";
          } else {
            return {
              committed: false,
              result: {
                success: true,
                action: "in",
                inTime: existingEntry.inTime,
                outTime: existingEntry.outTime,
                stayDuration: existingEntry.stayDuration,
                isLate: existingEntry.status === "late",
                alreadyMarked: true,
                tooEarlyForOut: true,
                cloudSaved: true,
                message: `⏳ ${params.studentName || 'छात्र'} का आगमन (IN) पहले से दर्ज है (${existingEntry.inTime})। ऑटो OUT ${outStart12h} के बाद लगेगा (अभी तुरंत छुट्टी लगाने के लिए ऊपर 'OUT' मोड चुनें)।`,
                record: existing || undefined
              }
            };
          }
        } else {
          action = "out";
        }
      }

      if (action === "in") {
        if (existingEntry?.inTime) {
          return {
            committed: false,
            result: {
              success: true,
              action: "in",
              inTime: existingEntry.inTime,
              outTime: existingEntry.outTime,
              stayDuration: existingEntry.stayDuration,
              isLate: existingEntry.status === "late",
              alreadyMarked: true,
              cloudSaved: true,
              message: `${params.studentName || 'छात्र'} का आगमन समय पहले से दर्ज है (${existingEntry.inTime})।`,
              record: existing || undefined
            }
          };
        }
      } else {
        if (existingEntry?.outTime) {
          return {
            committed: false,
            result: {
              success: true,
              action: "out",
              inTime: existingEntry.inTime,
              outTime: existingEntry.outTime,
              stayDuration: existingEntry.stayDuration,
              isLate: existingEntry.status === "late",
              alreadyMarked: true,
              cloudSaved: true,
              message: `${params.studentName || 'छात्र'} का प्रस्थान समय पहले से दर्ज है (${existingEntry.outTime})।`,
              record: existing || undefined
            }
          };
        }

        if (!existingEntry?.inTime) {
          return {
            committed: false,
            result: {
              success: false,
              action: "out",
              alreadyMarked: false,
              cloudSaved: false,
              message: `⚠️ ${params.studentName || 'छात्र'} का आज आगमन (IN) दर्ज नहीं है। प्रस्थान (OUT) से पहले आगमन (IN) आवश्यक है।`,
              record: existing || undefined
            }
          };
        }

        let elapsedMinutes: number | null = null;
        if (typeof existingEntry.inTimestamp === "number" && Number.isFinite(existingEntry.inTimestamp)) {
          elapsedMinutes = Math.floor((nowMs - existingEntry.inTimestamp) / 60000);
        } else if (existingEntry.inTime) {
          try {
            const inParts = existingEntry.inTime.match(/(\d+):(\d+)(?::(\d+))?\s*(AM|PM)?/i);
            if (inParts) {
              let h = parseInt(inParts[1], 10);
              const m = parseInt(inParts[2], 10);
              const meridiem = (inParts[4] || "").toUpperCase();
              if (meridiem === "PM" && h < 12) h += 12;
              if (meridiem === "AM" && h === 12) h = 0;
              const inDate = new Date();
              inDate.setHours(h, m, 0, 0);
              elapsedMinutes = Math.floor((nowMs - inDate.getTime()) / 60000);
            }
          } catch {}
        }

        const requiredMinGap = params.scanMode === "out" ? 1 : 30;
        if (elapsedMinutes !== null && elapsedMinutes >= 0 && elapsedMinutes < requiredMinGap) {
          const remainingMin = requiredMinGap - elapsedMinutes;
          return {
            committed: false,
            result: {
              success: false,
              action: "out",
              alreadyMarked: true,
              tooEarlyForOut: true,
              cloudSaved: false,
              inTime: existingEntry.inTime,
              message: `⚠️ ${params.studentName || 'छात्र'} का आगमन अभी दर्ज हुआ है (${existingEntry.inTime})। प्रस्थान (OUT) ${requiredMinGap} मिनट बाद ही मान्य होगा (शेष: ${remainingMin} मिनट)।`,
              record: existing || undefined
            }
          };
        }
      }

      let inTime = existingEntry?.inTime;
      let outTime = existingEntry?.outTime;
      let inTimestamp = existingEntry?.inTimestamp;
      let outTimestamp = existingEntry?.outTimestamp;
      let stayDuration = existingEntry?.stayDuration;
      let isLate = existingEntry?.status === "late";
      let status: "present" | "late" | "half_day" | "absent" | "leave" | "bunk" = existingEntry?.status || "present";

      if (action === "in") {
        inTime = timeFormatted;
        inTimestamp = nowMs;
        if (isPastCutoff) {
          isLate = true;
          status = "late";
        } else {
          status = "present";
        }
      } else {
        outTime = timeFormatted;
        outTimestamp = nowMs;
        stayDuration = calculateStayDuration(inTime, outTime, inTimestamp, outTimestamp);
      }

      studentsMap[params.studentId] = {
        present: true,
        name: params.studentName || existingEntry?.name || "Student",
        rollNo: params.rollNo || existingEntry?.rollNo || "",
        inTime,
        outTime,
        inTimestamp,
        outTimestamp,
        stayDuration,
        status,
        scanType: action,
        note: action === "in"
          ? (isLate ? `Entry (Late) at ${inTime}` : `Entry at ${inTime}`)
          : `Exit at ${outTime} (Stay: ${stayDuration || 'Recorded'})`
      };

      const record: AttendanceRecord = {
        date,
        schoolId: params.schoolId,
        classId: params.classId,
        sessionId: params.sessionId || existing?.sessionId || "",
        markedBy: params.markedBy || existing?.markedBy || "QR_STUDENT_SCAN",
        students: studentsMap,
        createdAt: existing?.createdAt || now.toISOString()
      };

      const sanitizedRecord = sanitizeForFirestore(record);
      const message = action === "in"
        ? (isLate ? `Late Punch-In recorded at ${inTime}!` : `Entry Punch-In recorded at ${inTime}!`)
        : `Exit Punch-Out recorded at ${outTime}! Stay duration: ${stayDuration || 'Saved'}`;

      return {
        committed: true,
        result: {
          success: true,
          action,
          inTime,
          outTime,
          stayDuration,
          isLate,
          alreadyMarked: false,
          cloudSaved: true,
          message,
          record: sanitizedRecord
        }
      };
    };

    let txOutcome: TxOutcome | null = null;
    if (await isSupabaseSchemaReady().catch(() => false)) {
      try {
        const [snap, studentSnap] = await withTimeout(
          Promise.all([getDoc(docRef), getDoc(studentDocRef)]),
          3000
        );
        const existing = snap.exists() ? (snap.data() as AttendanceRecord) : null;
        const stData = studentSnap.exists() ? studentSnap.data() : null;
        const outcome = computeQrAttendanceOutcome(existing, stData);
        if (outcome.committed && outcome.result.record) {
          await withTimeout(setDoc(docRef, outcome.result.record), 3000);
        }
        txOutcome = outcome;
      } catch (sbErr) {
        console.warn("[school-firebase] Supabase markStudentQrAttendance fallback:", sbErr);
      }
    }
    if (!txOutcome && db) {
      await ensureFirebaseAuthSession().catch(() => null);
      try {
        const { doc: fsDocRef } = await import("firebase/firestore");
        txOutcome = await withTimeout(
          runTransaction(db, async (transaction) => {
            const [snap, studentSnap] = await Promise.all([
              transaction.get(fsDocRef(db, `schools/${params.schoolId}/attendance/${docId}`)),
              transaction.get(fsDocRef(db, `schools/${params.schoolId}/students/${params.studentId}`)),
            ]);
            const existing = snap.exists() ? (snap.data() as AttendanceRecord) : null;
            const stData = studentSnap.exists() ? studentSnap.data() : null;
            const outcome = computeQrAttendanceOutcome(existing, stData);
            if (outcome.committed && outcome.result.record) {
              transaction.set(fsDocRef(db, `schools/${params.schoolId}/attendance/${docId}`), outcome.result.record);
            }
            return outcome;
          }),
          4500
        );
      } catch (fsErr) {
        console.warn("[school-firebase] Firestore markStudentQrAttendance failed, trying RTDB fallback:", fsErr);
      }
    }

    // RTDB atomic fallback if Firestore failed (e.g. permission-denied for School PIN login) or unavailable
    if (!txOutcome && rtdb) {
      await ensureFirebaseAuthSession().catch(() => null);
      let latestOutcome: TxOutcome | null = null;
      const rtdbAttRef = ref(rtdb, `schools/${params.schoolId}/attendance/${docId}`);
      await withTimeout(
        rtdbRunTransaction(rtdbAttRef, (currentVal: any) => {
          const outcome = computeQrAttendanceOutcome(
            currentVal && typeof currentVal === "object" ? (currentVal as AttendanceRecord) : null,
            null
          );
          latestOutcome = outcome;
          if (outcome.committed && outcome.result.record) {
            return outcome.result.record;
          }
          return undefined;
        }),
        4500
      );
      txOutcome = latestOutcome;
    }

    if (!txOutcome) {
      throw new Error("क्लाउड डेटाबेस सेव असफल रहा। कृपया नेटवर्क जांच कर पुनः प्रयास करें।");
    }

    if (txOutcome.committed && txOutcome.result.record) {
      // Update local cache & mirror to RTDB only AFTER atomic transaction commits
      try {
        const current = getLocalAttendance(params.schoolId);
        const updated = [txOutcome.result.record, ...current.filter((r: any) => `${r.classId}_${r.date}` !== docId)];
        setLocalAttendance(params.schoolId, updated);
      } catch {}

      if (rtdb) {
        void set(ref(rtdb, `schools/${params.schoolId}/attendance/${docId}`), txOutcome.result.record).catch(() => {});
      }
    }

    return txOutcome.result;
  } catch (err: any) {
    console.error("[school-firebase] markStudentQrAttendance atomic transaction error:", err);
    const rawMsg = String(err?.message || "");
    const isPermErr = /permission[_-]?denied/i.test(rawMsg);
    return {
      success: false,
      action: "in",
      cloudSaved: false,
      message: isPermErr
        ? "क्लाउड सेव अनुमति (Permission) त्रुटि — कृपया ऐप रीफ्रेश या री-लॉगिन करके दोबारा प्रयास करें।"
        : rawMsg || "क्लाउड डेटाबेस सेव असफल रहा। कृपया नेटवर्क जांच कर पुनः प्रयास करें।"
    };
  }
};

export const checkTodayStudentAttendance = async (
  schoolId: string,
  classId: string,
  studentId: string
): Promise<{ marked: boolean; present: boolean; date: string }> => {
  const date = todayStr();
  try {
    const record = await getAttendance(schoolId, classId, date);
    if (!record || !record.students) return { marked: false, present: false, date };
    const st = record.students[studentId];
    if (st && st.present !== undefined) {
      return { marked: true, present: st.present, date };
    }
    return { marked: false, present: false, date };
  } catch {
    return { marked: false, present: false, date };
  }
};

// ── ADMIN & STAFF ATTENDANCE HELPERS ──────────────────────────────────────────

export const getAdminAttendance = (schoolId: string, date: string): AdminAttendanceRecord => {
  const key = `nst_admin_att_${schoolId}_${date}`;
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw);
  } catch {}
  return {
    schoolId,
    adminId: "ADMIN-01",
    adminName: "School Admin & Principal",
    date,
    present: false,
    updatedAt: new Date().toISOString(),
  };
};

export const saveAdminAttendance = async (rec: AdminAttendanceRecord): Promise<void> => {
  const key = `nst_admin_att_${rec.schoolId}_${rec.date}`;
  try {
    localStorage.setItem(key, JSON.stringify(rec));
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("admin-attendance-updated", { detail: rec }));
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `school_admin_attendance/${rec.schoolId}/${rec.date}`), rec), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`school_admin_attendance/${rec.schoolId}_${rec.date}`), rec, { merge: true }), 2000);
    } catch {}
  }
};

export const getStaffDailyAttendance = (schoolId: string, date: string): StaffDailyAttendanceRecord => {
  const key = `nst_staff_daily_att_${schoolId}_${date}`;
  try {
    const cached = getSchoolCacheSync<StaffDailyAttendanceRecord | null>(key, null);
    if (cached && typeof cached === "object") return cached;
    if (typeof localStorage !== "undefined") {
      const raw = localStorage.getItem(key);
      if (raw) {
        const parsed = JSON.parse(raw) as StaffDailyAttendanceRecord;
        setSchoolCacheSync(key, parsed);
        try { localStorage.removeItem(key); } catch {}
        return parsed;
      }
    }
  } catch {}
  return {
    schoolId,
    date,
    records: {},
  };
};

export const fetchStaffDailyAttendance = async (schoolId: string, date: string): Promise<StaffDailyAttendanceRecord> => {
  await whenSchoolIdbReady();
  const key = `nst_staff_daily_att_${schoolId}_${date}`;
  const localRec = getStaffDailyAttendance(schoolId, date);
  const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "staff_attendance",
    key,
    () => Object.keys(localRec.records || {}).length > 0 || isSchoolCacheFresh(key, 10 * 60 * 1000),
    10 * 60 * 1000
  );
  if (!fetch) return localRec;

  return dedupInflight(`staff_att_day:${schoolId}:${date}`, async () => {
    if (db) {
      try {
        const docSnap = await withTimeout(getDoc(d(`schools/${schoolId}/staff_attendance/${date}`)), 2500);
        if (docSnap && docSnap.exists()) {
          const cloudData = docSnap.data() as StaffDailyAttendanceRecord;
          const normalized: StaffDailyAttendanceRecord = {
            schoolId,
            date,
            records: cloudData?.records || {},
          };
          setSchoolCacheSync(key, normalized);
          markSchoolCacheFresh(key, remoteVer);
          return normalized;
        }
      } catch (e) {
        console.warn("[school-firebase] fetchStaffDailyAttendance Firestore failed:", e);
      }
    }
    if (rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `school_staff_attendance/${schoolId}/${date}`)), 2500);
        if (snap && snap.exists()) {
          const cloudData = snap.val() as StaffDailyAttendanceRecord;
          const normalized: StaffDailyAttendanceRecord = {
            schoolId,
            date,
            records: cloudData?.records || {},
          };
          setSchoolCacheSync(key, normalized);
          markSchoolCacheFresh(key, remoteVer);
          return normalized;
        }
      } catch (e) {
        console.warn("[school-firebase] fetchStaffDailyAttendance RTDB read failed:", e);
      }
    }
    markSchoolCacheFresh(key, remoteVer);
    return localRec;
  });
};

export const saveStaffDailyAttendance = async (
  rec: StaffDailyAttendanceRecord
): Promise<{ success: boolean; cloudSaved: boolean; error?: string }> => {
  const key = `nst_staff_daily_att_${rec.schoolId}_${rec.date}`;
  const sanitized = sanitizeForFirestore(rec);

  try {
    const prev = getSchoolCacheSync<StaffDailyAttendanceRecord | null>(key, null);
    if (
      prev &&
      isSchoolCacheFresh(key, 15 * 60 * 1000) &&
      JSON.stringify(prev.records || {}) === JSON.stringify(sanitized.records || {})
    ) {
      return { success: true, cloudSaved: true };
    }
  } catch {}

  try {
    setSchoolCacheSync(key, sanitized);
    markSchoolCacheFresh(key);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-daily-attendance-updated", { detail: sanitized }));
  }

  let cloudSaved = false;
  let lastError = "";

  if (db) {
    try {
      await withTimeout(
        setDoc(d(`schools/${rec.schoolId}/staff_attendance/${rec.date}`), sanitized),
        3000
      );
      cloudSaved = true;
    } catch (err: any) {
      lastError = err?.message || "Firestore staff attendance save failed";
      console.warn("[school-firebase] saveStaffDailyAttendance Firestore error:", err);
    }
  }

  if (!cloudSaved && rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `school_staff_attendance/${rec.schoolId}/${rec.date}`), sanitized), 3000);
      cloudSaved = true;
    } catch (err: any) {
      if (!lastError) lastError = err?.message || "RTDB staff attendance save failed";
      console.error("[school-firebase] saveStaffDailyAttendance RTDB error:", err);
    }
  } else if (!cloudSaved && !lastError) {
    lastError = "Firebase unavailable";
  }

  if (cloudSaved) {
    touchSchoolSyncVersion(rec.schoolId, "staff_attendance");
  }

  return {
    success: cloudSaved,
    cloudSaved,
    error: cloudSaved ? undefined : lastError,
  };
};

export const getMonthlyStaffDailyAttendance = async (
  schoolId: string,
  yearMonth: string
): Promise<Record<string, Record<string, any>>> => {
  if (!schoolId || !yearMonth) return {};
  await whenSchoolIdbReady();
  const prefix = `${yearMonth}-`;
  const result: Record<string, Record<string, any>> = {};

  const mergeDateRecord = (dateStr: string, recs: Record<string, any> | undefined) => {
    if (!dateStr || !dateStr.startsWith(prefix) || !recs || typeof recs !== "object") return;
    if (!result[dateStr]) result[dateStr] = {};
    Object.entries(recs).forEach(([staffId, entry]) => {
      if (entry && typeof entry === "object") {
        result[dateStr][staffId] = { ...(result[dateStr][staffId] || {}), ...entry };
      }
    });
  };

  // 1. Seed from IndexedDB + any un-migrated localStorage cache
  const idbPrefix = `nst_staff_daily_att_${schoolId}_${prefix}`;
  for (const [k, val] of getSchoolCacheEntriesByPrefix(idbPrefix)) {
    const dateStr = k.slice(`nst_staff_daily_att_${schoolId}_`.length);
    mergeDateRecord(dateStr, val?.records);
  }
  try {
    if (typeof localStorage !== "undefined") {
      for (let i = 0; i < localStorage.length; i++) {
        const k = localStorage.key(i);
        if (k && k.startsWith(idbPrefix)) {
          const dateStr = k.slice(`nst_staff_daily_att_${schoolId}_`.length);
          const parsed = JSON.parse(localStorage.getItem(k) || "{}");
          mergeDateRecord(dateStr, parsed?.records);
          setSchoolCacheSync(k, parsed);
        }
      }
    }
  } catch {}

  const monthCacheKey = `nst_staff_daily_att_m_${schoolId}_${yearMonth}`;
  const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "staff_attendance",
    monthCacheKey,
    () => Object.keys(result).length > 0 || isSchoolCacheFresh(monthCacheKey, 24 * 60 * 60 * 1000),
    10 * 60 * 1000
  );
  if (!fetch) return result;

  return dedupInflight(`staff_att_m:${schoolId}:${yearMonth}`, async () => {
    let fsOk = false;
    if (db) {
      try {
        const colSnap = await withTimeout(getDocs(col(`schools/${schoolId}/staff_attendance`)), 3000);
        fsOk = true;
        if (colSnap && !colSnap.empty) {
          colSnap.forEach((docSnap) => {
            const data = docSnap.data() as StaffDailyAttendanceRecord;
            const dateStr = data?.date || docSnap.id;
            if (dateStr.startsWith(prefix) && data?.records) {
              mergeDateRecord(dateStr, data.records);
            }
          });
        }
      } catch (e) {
        console.warn("[school-firebase] getMonthlyStaffDailyAttendance Firestore failed:", e);
      }
    }

    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `school_staff_attendance/${schoolId}`)), 3000);
        if (snap && snap.exists()) {
          const val = snap.val() || {};
          Object.entries(val).forEach(([dateStr, dayRec]: [string, any]) => {
            if (dateStr.startsWith(prefix) && dayRec?.records) {
              mergeDateRecord(dateStr, dayRec.records);
            }
          });
        }
      } catch (e) {
        console.warn("[school-firebase] getMonthlyStaffDailyAttendance RTDB failed:", e);
      }
    }

    // Persist per-date records in IndexedDB
    try {
      Object.entries(result).forEach(([dateStr, records]) => {
        const key = `nst_staff_daily_att_${schoolId}_${dateStr}`;
        setSchoolCacheSync(key, { schoolId, date: dateStr, records });
      });
      if (fsOk || Object.keys(result).length > 0) {
        markSchoolCacheFresh(monthCacheKey, remoteVer);
      }
    } catch {}

    return result;
  });
};

export const markStaffAttendanceAtomic = async (params: {
  schoolId: string;
  staffId: string;
  staffName: string;
  role?: "TEACHER" | "ACCOUNTANT" | "STAFF" | "ADMIN";
  employeeId?: string;
  date?: string;
  scanMode?: "auto" | "in" | "out";
  currentShiftMode?: "in" | "out";
  cutoffTime?: string;
  outStartTime?: string;
}): Promise<{
  success: boolean;
  cloudSaved: boolean;
  action: "in" | "out";
  isLate?: boolean;
  alreadyMarked?: boolean;
  tooEarlyForOut?: boolean;
  inTime?: string;
  outTime?: string;
  stayDuration?: string;
  inTimestamp?: number;
  outTimestamp?: number;
  message: string;
  record?: StaffDailyAttendanceRecord;
}> => {
  const date = params.date || todayStr();
  const now = new Date();
  const nowMs = now.getTime();
  const timeFormatted = now.toLocaleTimeString("en-IN", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
  });

  if (!db && !rtdb) {
    return {
      success: false,
      cloudSaved: false,
      action: "in",
      message: "Firebase उपलब्ध नहीं है। क्लाउड सेविंग के बिना शिक्षक की हाजिरी दर्ज नहीं की जा सकती।",
    };
  }

  let storedCutoff: string | null = null;
  let storedOutStart: string | null = null;
  try {
    if (typeof window !== "undefined") {
      storedCutoff = localStorage.getItem(`nst_kiosk_in_cutoff_${params.schoolId}`);
      storedOutStart = localStorage.getItem(`nst_kiosk_out_start_${params.schoolId}`);
    }
  } catch {}
  const cutoffRaw = params.cutoffTime || storedCutoff || "08:15";
  const [cH, cM] = cutoffRaw.split(":").map(Number);
  const cutoffMinutes = (Number.isFinite(cH) ? cH : 8) * 60 + (Number.isFinite(cM) ? cM : 15);
  const outStartRaw = params.outStartTime || storedOutStart || "12:30";
  const [oH, oM] = outStartRaw.split(":").map(Number);
  const outStartMinutes = (Number.isFinite(oH) ? oH : 12) * 60 + (Number.isFinite(oM) ? oM : 30);
  const outPeriod = Math.floor(outStartMinutes / 60) >= 12 ? "PM" : "AM";
  const outHour12 = Math.floor(outStartMinutes / 60) % 12 === 0 ? 12 : Math.floor(outStartMinutes / 60) % 12;
  const outStart12h = `${String(outHour12).padStart(2, "0")}:${String(outStartMinutes % 60).padStart(2, "0")} ${outPeriod}`;
  const nowMinutes = now.getHours() * 60 + now.getMinutes();
  const isPastCutoff = nowMinutes > cutoffMinutes;

  type StaffTxRejection = {
    success: boolean;
    alreadyMarked?: boolean;
    tooEarlyForOut?: boolean;
    action: "in" | "out";
    inTime?: string;
    outTime?: string;
    stayDuration?: string;
    message: string;
  };

  type StaffTxCompute =
    | { committed: false; rejection: StaffTxRejection }
    | { committed: true; dayObj: StaffDailyAttendanceRecord };

  const computeStaffOutcome = (currentData: any): StaffTxCompute => {
    const dayObj: StaffDailyAttendanceRecord =
      currentData && typeof currentData === "object"
        ? {
            schoolId: currentData.schoolId || params.schoolId,
            date: currentData.date || date,
            records:
              currentData.records && typeof currentData.records === "object"
                ? { ...currentData.records }
                : {},
          }
        : { schoolId: params.schoolId, date, records: {} };

    const existingRec = dayObj.records[params.staffId];

    let action: "in" | "out" =
      params.scanMode === "out"
        ? "out"
        : params.scanMode === "in"
        ? "in"
        : (params.currentShiftMode || "in");

    if (params.scanMode === "auto") {
      if (!existingRec?.inTime) {
        action = "in";
      } else if (!existingRec?.outTime) {
        if (nowMinutes >= outStartMinutes) {
          action = "out";
        } else {
          return {
            committed: false,
            rejection: {
              success: true,
              alreadyMarked: true,
              tooEarlyForOut: true,
              action: "in",
              inTime: existingRec.inTime,
              outTime: existingRec.outTime,
              stayDuration: existingRec.stayDuration,
              message: `⏳ शिक्षक ${params.staffName} का IN पहले से दर्ज है (${existingRec.inTime})। ऑटो OUT ${outStart12h} के बाद लगेगा (तुरंत OUT के लिए 'OUT' मोड चुनें)।`,
            },
          };
        }
      } else {
        action = "out";
      }
    }

    if (action === "in") {
      if (existingRec?.inTime) {
        return {
          committed: false,
          rejection: {
            success: true,
            alreadyMarked: true,
            action: "in",
            inTime: existingRec.inTime,
            outTime: existingRec.outTime,
            stayDuration: existingRec.stayDuration,
            message: `शिक्षक ${params.staffName} का आगमन (IN) पहले से दर्ज है (${existingRec.inTime})।`,
          },
        };
      }
    } else {
      if (!existingRec?.inTime) {
        return {
          committed: false,
          rejection: {
            success: false,
            alreadyMarked: false,
            action: "out",
            message: `⚠️ शिक्षक ${params.staffName} का आज आगमन (IN) दर्ज नहीं है। प्रस्थान (OUT) से पहले आगमन (IN) आवश्यक है।`,
          },
        };
      }

      if (existingRec?.outTime) {
        return {
          committed: false,
          rejection: {
            success: true,
            alreadyMarked: true,
            action: "out",
            inTime: existingRec.inTime,
            outTime: existingRec.outTime,
            stayDuration: existingRec.stayDuration,
            message: `शिक्षक ${params.staffName} का प्रस्थान (OUT) पहले से दर्ज है (${existingRec.outTime})।`,
          },
        };
      }

      let elapsedMinutes: number | null = null;
      if (typeof existingRec.inTimestamp === "number" && Number.isFinite(existingRec.inTimestamp)) {
        elapsedMinutes = Math.floor((nowMs - existingRec.inTimestamp) / 60000);
      } else if (existingRec.inTime) {
        try {
          const inParts = existingRec.inTime.match(/(\d+):(\d+)(?::(\d+))?\s*(AM|PM)?/i);
          if (inParts) {
            let h = parseInt(inParts[1], 10);
            const m = parseInt(inParts[2], 10);
            const meridiem = (inParts[4] || "").toUpperCase();
            if (meridiem === "PM" && h < 12) h += 12;
            if (meridiem === "AM" && h === 12) h = 0;
            const inDate = new Date();
            inDate.setHours(h, m, 0, 0);
            elapsedMinutes = Math.floor((nowMs - inDate.getTime()) / 60000);
          }
        } catch {}
      }

      const requiredMinGap = params.scanMode === "out" ? 1 : 30;
      if (elapsedMinutes !== null && elapsedMinutes >= 0 && elapsedMinutes < requiredMinGap) {
        return {
          committed: false,
          rejection: {
            success: false,
            alreadyMarked: true,
            tooEarlyForOut: true,
            action: "out",
            inTime: existingRec.inTime,
            message: `⚠️ शिक्षक ${params.staffName} का आगमन अभी दर्ज हुआ है (${existingRec.inTime})। प्रस्थान ${requiredMinGap} मिनट बाद ही मान्य होगा (शेष: ${requiredMinGap - elapsedMinutes} मिनट)।`,
          },
        };
      }
    }

    const inTime = action === "in" ? timeFormatted : existingRec!.inTime!;
    const inTimestamp = action === "in" ? nowMs : existingRec?.inTimestamp;
    const outTime = action === "out" ? timeFormatted : existingRec?.outTime;
    const outTimestamp = action === "out" ? nowMs : existingRec?.outTimestamp;
    const stayDuration =
      action === "out"
        ? calculateStayDuration(inTime, outTime, inTimestamp, outTimestamp)
        : existingRec?.stayDuration;

    const entryIsLate =
      action === "in"
        ? Boolean(isPastCutoff)
        : Boolean(existingRec?.status === "late" || (existingRec as any)?.isLate);
    const entryStatus = entryIsLate ? "late" : "present";

    dayObj.records[params.staffId] = sanitizeForFirestore({
      id: params.staffId,
      name: params.staffName,
      role: params.role || "TEACHER",
      employeeId: params.employeeId || "Faculty",
      present: true,
      status: entryStatus,
      isLate: entryIsLate,
      inTime,
      outTime,
      inTimestamp,
      outTimestamp,
      stayDuration,
      scanType: action,
    });

    return {
      committed: true,
      dayObj: sanitizeForFirestore(dayObj),
    };
  };

  const docRef = d(`schools/${params.schoolId}/staff_attendance/${date}`);
  const dayRef = rtdb ? ref(rtdb, `school_staff_attendance/${params.schoolId}/${date}`) : null;
  let committedDay: StaffDailyAttendanceRecord | null = null;
  let rejectedOutcome: StaffTxRejection | null = null;
  let lastCloudError: any = null;

  // 1. SUPABASE FIRST (Works seamlessly regardless of Firebase anonymous auth restrictions)
  try {
    if (await isSupabaseSchemaReady().catch(() => false)) {
      const snap = await withTimeout(getDoc(docRef), 3000);
      let existingData: any = snap && snap.exists() ? snap.data() : null;
      if (!existingData) {
        const localFallback = getStaffDailyAttendance(params.schoolId, date);
        if (localFallback && Object.keys(localFallback.records || {}).length > 0) {
          existingData = localFallback;
        }
      }
      const outcome = computeStaffOutcome(existingData);
      if ('rejection' in outcome) {
        rejectedOutcome = outcome.rejection;
      } else {
        await withTimeout(setDoc(docRef, outcome.dayObj, { merge: false }), 3500);
        committedDay = outcome.dayObj;
      }
    }
  } catch (sbErr) {
    lastCloudError = sbErr;
    console.warn("[school-firebase] markStaffAttendanceAtomic Supabase path fallback:", sbErr);
  }

  // 2. FIREBASE RTDB TRANSACTION FALLBACK (Ensure Firebase Auth session first)
  if (!committedDay && !rejectedOutcome && dayRef) {
    await ensureFirebaseAuthSession().catch(() => null);
    try {
      let rtdbRej: StaffTxRejection | null = null;
      const txRes = await withTimeout(
        rtdbRunTransaction(dayRef, (currentData: any) => {
          const outcome = computeStaffOutcome(currentData);
          if ('rejection' in outcome) {
            rtdbRej = outcome.rejection;
            return;
          }
          rtdbRej = null;
          return outcome.dayObj;
        }),
        4500
      );
      if (rtdbRej) {
        rejectedOutcome = rtdbRej;
      } else if (txRes.committed && txRes.snapshot.exists()) {
        committedDay = txRes.snapshot.val() as StaffDailyAttendanceRecord;
      }
    } catch (rtdbErr) {
      lastCloudError = rtdbErr;
      console.warn("[school-firebase] markStaffAttendanceAtomic RTDB fallback failed:", rtdbErr);
    }
  }

  // 3. FIRESTORE TRANSACTION FALLBACK
  if (!committedDay && !rejectedOutcome && db) {
    await ensureFirebaseAuthSession().catch(() => null);
    try {
      const { doc: fsDocRef } = await import("firebase/firestore");
      const fsRef = fsDocRef(db, `schools/${params.schoolId}/staff_attendance/${date}`);
      let fsRej: StaffTxRejection | null = null;
      const fsCommitted = await withTimeout(
        runTransaction(db, async (transaction) => {
          const snap = await transaction.get(fsRef);
          const existing = snap.exists() ? snap.data() : null;
          const outcome = computeStaffOutcome(existing);
          if ('rejection' in outcome) {
            fsRej = outcome.rejection;
            return null;
          }
          fsRej = null;
          transaction.set(fsRef, outcome.dayObj);
          return outcome.dayObj;
        }),
        4500
      );
      if (fsRej) {
        rejectedOutcome = fsRej;
      } else if (fsCommitted) {
        committedDay = fsCommitted;
      }
    } catch (fsErr) {
      lastCloudError = fsErr;
      console.warn("[school-firebase] markStaffAttendanceAtomic Firestore fallback failed:", fsErr);
    }
  }

  if (rejectedOutcome) {
    return {
      ...rejectedOutcome,
      cloudSaved: Boolean(rejectedOutcome.alreadyMarked && !rejectedOutcome.tooEarlyForOut),
    };
  }

  if (!committedDay) {
    const rawMsg = String(lastCloudError?.message || "");
    const isPermErr = /permission[_-]?denied/i.test(rawMsg);
    return {
      success: false,
      cloudSaved: false,
      action: "in",
      message: isPermErr
        ? "क्लाउड सेव अनुमति (Permission) त्रुटि — कृपया ऐप रीफ्रेश या री-लॉगिन करके दोबारा प्रयास करें।"
        : rawMsg || "शिक्षक की हाजिरी क्लाउड पर सेव नहीं हो पाई। कृपया दोबारा प्रयास करें।",
    };
  }

  const savedEntry = committedDay.records?.[params.staffId];

  // Update IndexedDB cache & broadcast event ONLY after cloud save commits
  try {
    const staffAttKey = `nst_staff_daily_att_${params.schoolId}_${date}`;
    setSchoolCacheSync(staffAttKey, committedDay);
    markSchoolCacheFresh(staffAttKey);
    touchSchoolSyncVersion(params.schoolId, "staff_attendance");
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-daily-attendance-updated", { detail: committedDay }));
  }
  if (dayRef) {
    void set(dayRef, committedDay).catch(() => {});
  }
  if (db) {
    void setDoc(docRef, committedDay).catch(() => {});
  }

  const finalAction = (savedEntry?.scanType || "in") as "in" | "out";
  const finalIsLate = Boolean((savedEntry as any)?.isLate || savedEntry?.status === "late");
  return {
    success: true,
    cloudSaved: true,
    action: finalAction,
    isLate: finalIsLate,
    alreadyMarked: false,
    inTime: savedEntry?.inTime,
    outTime: savedEntry?.outTime,
    inTimestamp: savedEntry?.inTimestamp,
    outTimestamp: savedEntry?.outTimestamp,
    stayDuration: savedEntry?.stayDuration,
    message:
      finalAction === "in"
        ? finalIsLate
          ? `⚠️ शिक्षक ${params.staffName} का आगमन (Late) दर्ज हुआ (${savedEntry?.inTime})।`
          : `शिक्षक ${params.staffName} का आगमन (IN) दर्ज हुआ (${savedEntry?.inTime})।`
        : `शिक्षक ${params.staffName} का प्रस्थान (OUT) दर्ज हुआ (${savedEntry?.outTime})।`,
    record: committedDay,
  };
};

export const saveSchoolLiveLocation = async (
  schoolId: string,
  locationData: {
    latitude: number;
    longitude: number;
    locationRadiusMeters?: number;
    locationAddress?: string;
    geoFenceEnabled?: boolean;
  }
): Promise<void> => {
  const nowIso = new Date().toISOString();
  const updatePayload = {
    latitude: locationData.latitude,
    longitude: locationData.longitude,
    locationRadiusMeters: locationData.locationRadiusMeters || 200,
    locationAddress: locationData.locationAddress || "",
    geoFenceEnabled: locationData.geoFenceEnabled ?? true,
    locationUpdatedAt: nowIso,
  };

  // Update local school record cache
  const localSchools = getLocalSchools();
  const updatedList = localSchools.map((s) => (s.id === schoolId ? { ...s, ...updatePayload } : s));
  setLocalSchools(updatedList);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-profile-updated", { detail: { schoolId, ...updatePayload } }));
  }

  // Update Firebase Firestore and Realtime Database
  if (db) {
    try {
      await withTimeout(updateDoc(d(`schools/${schoolId}`), updatePayload), 2500);
    } catch {}
  }
  if (rtdb) {
    try {
      await withTimeout(update(ref(rtdb, `schools/${schoolId}`), updatePayload), 2000);
    } catch {}
  }
};

// ── MARKS / EXAMS ────────────────────────────────────────────────────────────

// ── EXAMS ───────────────────────────────────────────────────────────────────
const LOCAL_EXAMS_PREFIX = "nst_school_exams_";

export const getLocalExams = (schoolId: string): ExamEntry[] => {
  try {
    const list = getSchoolCacheSync<ExamEntry[]>(`${LOCAL_EXAMS_PREFIX}${schoolId}`, []);
    const arr = Array.isArray(list) ? list : [];
    const filtered = !shouldUseDemoForSchool(schoolId) ? arr.filter(e => !isDemoRecord(e)) : arr;
    if (filtered.length > 0) return filtered;
    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.exams && demo.exams.length > 0) {
        return demo.exams;
      }
    }
    return filtered;
  } catch {
    return [];
  }
};

export const setLocalExams = (schoolId: string, exams: ExamEntry[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_EXAMS_PREFIX}${schoolId}`, Array.isArray(exams) ? exams : []);
  } catch {}
};

export const saveExam = async (exam: ExamEntry) => {
  const sanitized = sanitizeForFirestore(exam);
  const cacheKey = `${LOCAL_EXAMS_PREFIX}${exam.schoolId}`;
  try {
    const current = getLocalExams(exam.schoolId);
    const updated = [sanitized, ...current.filter((e: any) => e.id !== exam.id)];
    setLocalExams(exam.schoolId, updated);
    markSchoolCacheFresh(cacheKey);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("exam-updated", {
        detail: { schoolId: exam.schoolId, classId: exam.classId, exam: sanitized }
      })
    );
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${exam.schoolId}/exams/${exam.id}`), sanitized), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${exam.schoolId}/exams/${exam.id}`), sanitized), 2500);
    } catch (e) {
      console.warn("[school-firebase] saveExam sync notice:", e);
    }
  }
  touchSchoolSyncVersion(exam.schoolId, "exams");
};

export const getExams = async (schoolId: string, classId?: string): Promise<ExamEntry[]> => {
  if (!schoolId) return [];
  const cacheKey = `${LOCAL_EXAMS_PREFIX}${schoolId}`;
  const allExams = await dedupInflight(`getExams_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "exams",
      cacheKey,
      () => getLocalExams(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      15 * 60 * 1000
    );
    const local = getLocalExams(schoolId);
    if (!fetch || shouldUseDemoForSchool(schoolId)) {
      return local;
    }
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/exams`)), 2500);
        const all = snap.docs.map(docSnap => docSnap.data() as ExamEntry).filter(e => e && !isDemoRecord(e));
        setLocalExams(schoolId, all);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return all;
      } catch {}
    }
    if (rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/exams`)), 2000);
        const val = snap?.val?.();
        if (val && typeof val === "object") {
          const all = (Object.values(val) as ExamEntry[]).filter(e => e && !isDemoRecord(e));
          setLocalExams(schoolId, all);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return all;
        }
      } catch {}
    }
    if (local.length > 0) markSchoolCacheFresh(cacheKey, remoteVer);
    return local;
  });

  return classId ? allExams.filter(e => e.classId === classId) : allExams;
};

export const subscribeToExams = (schoolId: string, classId: string, cb: (exams: ExamEntry[]) => void) => {
  if (!schoolId) return () => {};
  let active = true;

  const deliverCurrent = () => {
    if (!active) return;
    const local = getLocalExams(schoolId).filter(e => !classId || e.classId === classId);
    cb(local);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverCurrent();
    if (!shouldUseDemoForSchool(schoolId)) {
      getExams(schoolId, classId)
        .then((list) => {
          if (active) cb(list);
        })
        .catch(() => {});
    }
  });

  const handleExamUpdated = (e: any) => {
    if (e.detail?.schoolId === schoolId && (!classId || !e.detail?.classId || e.detail?.classId === classId)) {
      deliverCurrent();
    }
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverCurrent);
    window.addEventListener("exam-updated", handleExamUpdated);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverCurrent);
      window.removeEventListener("exam-updated", handleExamUpdated);
    }
  };
};

export const deleteExam = async (schoolId: string, examId: string) => {
  const cacheKey = `${LOCAL_EXAMS_PREFIX}${schoolId}`;
  try {
    const current = getLocalExams(schoolId);
    setLocalExams(schoolId, current.filter(e => e.id !== examId));
    markSchoolCacheFresh(cacheKey);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("exam-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await remove(ref(rtdb, `schools/${schoolId}/exams/${examId}`)); } catch {}
  }
  if (db) {
    try { await deleteDoc(d(`schools/${schoolId}/exams/${examId}`)); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "exams");
};

// ── FEE ─────────────────────────────────────────────────────────────────────
const LOCAL_FEES_PREFIX = "nst_school_fees_";

export const getLocalFees = (schoolId: string): MonthlyFee[] => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.fees && Array.isArray(demo.fees) && demo.fees.length > 0) {
      return demo.fees;
    }
  }

  try {
    const parsed = getSchoolCacheSync<MonthlyFee[]>(`${LOCAL_FEES_PREFIX}${schoolId}`, []);
    if (Array.isArray(parsed) && parsed.length > 0) {
      return !useDemo ? parsed.filter(f => !isDemoRecord(f)) : parsed;
    }
  } catch {}

  if (!useDemo) {
    return [];
  }

  const demo = getDemoSchoolDataset(true);
  if (demo && demo.fees && Array.isArray(demo.fees) && demo.fees.length > 0) {
    setSchoolCacheSync(`${LOCAL_FEES_PREFIX}${schoolId}`, demo.fees);
    return demo.fees;
  }
  return [];
};

export const setLocalFees = (schoolId: string, fees: MonthlyFee[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_FEES_PREFIX}${schoolId}`, Array.isArray(fees) ? fees : []);
  } catch {}
};

export const saveFee = async (fee: MonthlyFee) => {
  const sanitized = sanitizeForFirestore(fee);
  const isAdmissionFee = fee.feeType === "admission" || fee.receiptCategory === "admission";
  const id = isAdmissionFee
    ? `${fee.studentId}_adm_${fee.receiptNo || fee.month || Date.now()}`
    : `${fee.studentId}_${fee.month || fee.receiptNo || Date.now()}`;

  try {
    const current = getLocalFees(fee.schoolId);
    const updated = [
      sanitized,
      ...current.filter((f: any) => {
        const fIsAdm = f.feeType === "admission" || f.receiptCategory === "admission";
        if (isAdmissionFee || fIsAdm) {
          if (isAdmissionFee && fIsAdm && f.receiptNo && fee.receiptNo) {
            return f.receiptNo !== fee.receiptNo;
          }
          return true;
        }
        if (f.studentId && fee.studentId && f.month && fee.month) {
          return !(f.studentId === fee.studentId && f.month === fee.month);
        }
        if (f.receiptNo && fee.receiptNo) {
          return f.receiptNo !== fee.receiptNo;
        }
        return true;
      })
    ];
    setLocalFees(fee.schoolId, updated);
    markSchoolCacheFresh(`${LOCAL_FEES_PREFIX}${fee.schoolId}`);
    if (fee.studentId) markSchoolCacheFresh(`nst_std_fees_${fee.schoolId}_${fee.studentId}`);
    if (fee.month) markSchoolCacheFresh(`nst_month_fees_${fee.schoolId}_${fee.month}`);
    markSchoolCacheFresh(`nst_raw_fees_${fee.schoolId}`);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("fee-updated", {
        detail: { schoolId: fee.schoolId, studentId: fee.studentId, fee: sanitized }
      })
    );
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${fee.schoolId}/fees/${id}`), sanitized), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${fee.schoolId}/fees/${id}`), sanitized), 2500);
    } catch (e) {
      console.warn("[school-firebase] saveFee sync notice:", e);
    }
  }
  touchSchoolSyncVersion(fee.schoolId, "fees");
};

export const subscribeToStudentFees = (
  schoolId: string,
  studentId: string,
  cb: (fees: MonthlyFee[]) => void
) => {
  if (!schoolId || !studentId) {
    cb([]);
    return () => {};
  }
  let active = true;

  const deliverCurrent = () => {
    if (!active) return;
    const local = getLocalFees(schoolId)
      .filter(f => f.studentId === studentId)
      .sort((a, b) => (b.month || "").localeCompare(a.month || ""));
    cb(local);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverCurrent();
    if (!shouldUseDemoForSchool(schoolId)) {
      getStudentFees(schoolId, studentId)
        .then((list) => {
          if (active) cb(list);
        })
        .catch(() => {});
    }
  });

  const handleFeeUpdate = (e: any) => {
    if (e.detail?.schoolId === schoolId && (!e.detail?.studentId || e.detail?.studentId === studentId)) {
      deliverCurrent();
    }
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverCurrent);
    window.addEventListener("fee-updated", handleFeeUpdate);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverCurrent);
      window.removeEventListener("fee-updated", handleFeeUpdate);
    }
  };
};

export const getStudentFees = async (schoolId: string, studentId: string): Promise<MonthlyFee[]> => {
  if (!schoolId || !studentId) return [];
  const cacheKey = `nst_std_fees_${schoolId}_${studentId}`;
  return dedupInflight(`getStudentFees_${schoolId}_${studentId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "fees",
      cacheKey,
      () => getLocalFees(schoolId).some(f => f.studentId === studentId) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      5 * 60 * 1000
    );

    const local = getLocalFees(schoolId)
      .filter(f => f.studentId === studentId)
      .sort((a, b) => (b.month || "").localeCompare(a.month || ""));

    if (!fetch || shouldUseDemoForSchool(schoolId)) return local;

    if (db) {
      try {
        const snap = await withTimeout(
          getDocs(query(col(`schools/${schoolId}/fees`), where("studentId", "==", studentId))),
          2500
        );
        const all = snap.docs
          .map(docSnap => docSnap.data() as MonthlyFee)
          .sort((a, b) => (b.month || "").localeCompare(a.month || ""));
        markSchoolCacheFresh(cacheKey, remoteVer);
        if (all.length > 0) {
          const cur = getLocalFees(schoolId);
          const merged = [...all, ...cur.filter(c => c.studentId !== studentId)];
          setLocalFees(schoolId, merged);
          return all;
        }
        return local;
      } catch {}
    }
    return local;
  });
};

export const getMonthlyFees = async (schoolId: string, month: string, classId?: string, sessionId?: string): Promise<MonthlyFee[]> => {
  await whenSchoolIdbReady();
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  const local = getLocalFees(schoolId).filter(
    f => f.month === month && (!classId || isStudentInClass(f, classId)) && (!sessionId || f.sessionId === sessionId)
  );
  const demo = useDemo ? getDemoSchoolDataset(true) : null;
  let demoFees = (demo && demo.fees && demo.fees.length > 0)
    ? demo.fees.filter(
        f => f.month === month && (!classId || isStudentInClass(f, classId)) && (!sessionId || isDemoSessionId(sessionId) || f.sessionId === sessionId)
      )
    : [];

  if (useDemo && demoFees.length === 0 && demo && demo.students && demo.students.length > 0) {
    const relevantStudents = (demo.students || []).filter(
      s => (!classId || isStudentInClass(s, classId)) && (!sessionId || s.sessionId === sessionId)
    );
    demoFees = relevantStudents.map((st, idx) => {
      const isPaid = (idx % 4) !== 3; // 75% paid, 25% due
      const amount = st.monthlyFee || 2000;
      return {
        schoolId,
        sessionId: st.sessionId || sessionId || "demo_session_2026_27",
        studentId: st.id,
        studentName: st.name,
        rollNo: st.rollNo,
        classId: st.classId,
        className: st.className,
        month,
        amount,
        monthlyAmount: amount,
        arrearsAmount: isPaid ? 0 : amount,
        arrearsMonths: isPaid ? [] : [month],
        paid: isPaid,
        paidDate: isPaid ? `${month}-${String(5 + (idx % 15)).padStart(2, "0")}` : undefined,
        paidBy: isPaid ? "Admin / Cashier" : undefined,
        receiptNo: isPaid ? `RCP-${month.replace("-", "")}-${(st.rollNo || "01").padStart(2, "0")}` : undefined,
        paymentMode: isPaid ? (idx % 2 === 0 ? "Cash" : "online_upi") : undefined,
        note: isPaid ? "Monthly tuition fee received" : `Fee pending for ${month}`,
      } as MonthlyFee;
    });
  }

  const map = new Map<string, MonthlyFee>();
  demoFees.forEach(f => map.set(f.studentId, f));
  local.forEach(f => {
    if (useDemo || !isDemoRecord(f)) {
      map.set(f.studentId, f);
    }
  });

  if (!useDemo) {
    const cacheKey = `nst_month_fees_${schoolId}_${month}`;
    const cloudMonthFees = await dedupInflight(`getMonthlyFees_${schoolId}_${month}`, async () => {
      const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
        schoolId,
        "fees",
        cacheKey,
        () => local.length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
        5 * 60 * 1000
      );
      if (!fetch) return null;

      let fsOk = false;
      const fetched: MonthlyFee[] = [];
      if (db) {
        try {
          const qSnap = await withTimeout(getDocs(query(col(`schools/${schoolId}/fees`), where("month", "==", month))), 2500);
          fsOk = true;
          (qSnap as any).docs.forEach((docSnap: any) => {
            const f = docSnap.data() as MonthlyFee;
            if (f && !isDemoRecord(f)) fetched.push(f);
          });
        } catch {}
      }

      if (!fsOk && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/fees`)), 2000);
          if (snap.exists()) {
            const rtdbList = (Object.values(snap.val() || {}) as MonthlyFee[]).filter(
              f => f && f.month === month && !isDemoRecord(f)
            );
            fetched.push(...rtdbList);
          }
        } catch {}
      }

      if (fsOk || fetched.length > 0) {
        const cur = getLocalFees(schoolId);
        const mergedMap = new Map<string, MonthlyFee>();
        cur.forEach(f => mergedMap.set(`${f.studentId}_${f.month || (f as any).id || f.receiptNo || ""}`, f));
        fetched.forEach(f => mergedMap.set(`${f.studentId}_${f.month || (f as any).id || f.receiptNo || ""}`, f));
        setLocalFees(schoolId, Array.from(mergedMap.values()));
        markSchoolCacheFresh(cacheKey, remoteVer);
      }
      return fetched;
    });

    if (cloudMonthFees && cloudMonthFees.length > 0) {
      let filtered = cloudMonthFees;
      if (classId) filtered = filtered.filter(f => isStudentInClass(f, classId));
      if (sessionId) filtered = filtered.filter(f => !f.sessionId || f.sessionId === sessionId);
      filtered.forEach(rf => {
        const prev = map.get(rf.studentId);
        if (!prev || rf.paid || rf.razorpayPaymentId || (rf.updatedAt && (!prev.updatedAt || rf.updatedAt > prev.updatedAt))) {
          map.set(rf.studentId, rf);
        }
      });
    }
  }

  const result = Array.from(map.values()).sort((a, b) => (a.studentName || "").localeCompare(b.studentName || ""));
  return !useDemo ? result.filter(f => !isDemoRecord(f)) : result;
};

export const getAllMonthlyFees = getMonthlyFees;

export const getSchoolFeeHistory = async (schoolId: string, sessionId?: string): Promise<MonthlyFee[]> => {
  await whenSchoolIdbReady();
  const useDemo = shouldUseDemoForSchool(schoolId, sessionId);
  const cacheKey = `${LOCAL_FEES_PREFIX}${schoolId}`;

  if (!useDemo) {
    await dedupInflight(`getSchoolFeeHistory_${schoolId}`, async () => {
      const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
        schoolId,
        "fees",
        cacheKey,
        () => getLocalFees(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
        5 * 60 * 1000
      );
      if (!fetch) return;

      let fsOk = false;
      const mergedMap = new Map<string, MonthlyFee>();
      getLocalFees(schoolId).forEach(lf => {
        if (!isDemoRecord(lf)) {
          const k = lf.studentId && lf.month ? `${lf.studentId}_${lf.month}` : (lf.receiptNo || (lf as any).id || String(Math.random()));
          mergedMap.set(k, lf);
        }
      });

      if (db) {
        try {
          const snap = await withTimeout(getDocs(col(`schools/${schoolId}/fees`)), 2500);
          fsOk = true;
          snap.docs.forEach(docSnap => {
            const af = docSnap.data() as MonthlyFee;
            if (!af || isDemoRecord(af)) return;
            const key = af.studentId && af.month ? `${af.studentId}_${af.month}` : (af.receiptNo || docSnap.id);
            mergedMap.set(key, af);
          });
        } catch {}
      }

      if (!fsOk && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/fees`)), 2000);
          if (snap.exists()) {
            fsOk = true;
            (Object.values(snap.val() || {}) as MonthlyFee[]).forEach(af => {
              if (!af || isDemoRecord(af)) return;
              const key = af.studentId && af.month ? `${af.studentId}_${af.month}` : (af.receiptNo || (af as any).id || String(Math.random()));
              mergedMap.set(key, af);
            });
          }
        } catch {}
      }

      if (fsOk) {
        setLocalFees(schoolId, Array.from(mergedMap.values()));
        markSchoolCacheFresh(cacheKey, remoteVer);
      }
    });
  }

  const local = getLocalFees(schoolId);
  const demo = useDemo ? getDemoSchoolDataset(true) : null;
  let demoFees: MonthlyFee[] = (demo && demo.fees) ? demo.fees : [];
  if (sessionId && !isDemoSessionId(sessionId)) {
    demoFees = demoFees.filter((f: any) => f.sessionId === sessionId);
  }

  const feeMap = new Map<string, MonthlyFee>();
  demoFees.forEach((df: any) => {
    if (df.studentId && df.month) feeMap.set(`${df.studentId}_${df.month}`, df);
  });
  local.forEach((lf: any) => {
    if (!useDemo && isDemoRecord(lf)) return;
    if (sessionId && lf.sessionId && lf.sessionId !== sessionId) return;
    if (lf.studentId && lf.month) feeMap.set(`${lf.studentId}_${lf.month}`, lf);
    else feeMap.set(lf.receiptNo || lf.id || String(Math.random()), lf);
  });

  return Array.from(feeMap.values());
};

const getRawFeeDedupKey = (f: any): string => {
  const recNo = String(f?.receiptNo || f?.receiptNumber || "").trim().toUpperCase();
  const sId = String(f?.studentId || "").trim();
  if (recNo) {
    return `${sId}|REC|${recNo}`;
  }
  const isAdm = f?.feeType === "admission" || f?.receiptCategory === "admission";
  if (isAdm) {
    return `${sId}|ADM|${f?.month || f?.id || f?._docId || ""}`;
  }
  return `${sId}|MON|${f?.month || f?.id || f?._docId || Math.random()}`;
};

const pickNewerFeeRecord = (prev: any, next: any): any => {
  if (!prev) return next;
  const prevCancelled = String(prev.status || "").toUpperCase() === "CANCELLED" || prev.cancelled === true;
  const nextCancelled = String(next.status || "").toUpperCase() === "CANCELLED" || next.cancelled === true;
  if (nextCancelled && !prevCancelled) {
    return { ...prev, ...next, _docId: next._docId || prev._docId };
  }
  if (prevCancelled && !nextCancelled) {
    return { ...next, ...prev, _docId: prev._docId || next._docId };
  }
  if (next.updatedAt && (!prev.updatedAt || next.updatedAt > prev.updatedAt)) {
    return { ...prev, ...next, _docId: next._docId || prev._docId };
  }
  const prevPaid = Number(prev.paidAmount || (prev.paid ? prev.amount : 0) || 0);
  const nextPaid = Number(next.paidAmount || (next.paid ? next.amount : 0) || 0);
  if ((!prev.paid && next.paid) || nextPaid > prevPaid || (next.receiptNo && !prev.receiptNo)) {
    return { ...prev, ...next, _docId: next._docId || prev._docId };
  }
  return { ...next, ...prev, _docId: prev._docId || next._docId };
};

export const getAllSchoolFeeReceiptsRaw = async (schoolId: string): Promise<Array<MonthlyFee & {
  _docId?: string;
  _source?: string;
  _appId?: string;
  _isSynthetic?: boolean;
  admissionNo?: string;
  phone?: string;
  receiptNumber?: string;
}>> => {
  if (!schoolId) return [];
  await whenSchoolIdbReady();
  const useDemo = shouldUseDemoForSchool(schoolId);
  const feeMap = new Map<string, any>();

  const upsert = (item: any) => {
    if (!item || typeof item !== "object") return;
    if (!useDemo && isDemoRecord(item)) return;
    const key = getRawFeeDedupKey(item);
    feeMap.set(key, pickNewerFeeRecord(feeMap.get(key), item));
  };

  // 1. Local IndexedDB cache (`nst_school_fees_<schoolId>`)
  try {
    const localFees = getLocalFees(schoolId);
    localFees.forEach((lf) => upsert({ ...lf, _source: "local_fees" }));
  } catch {}

  // 2. Legacy `school_fee_records_<schoolId>` localStorage key
  try {
    const rawLegacy = localStorage.getItem(`school_fee_records_${schoolId}`);
    if (rawLegacy) {
      const parsed = JSON.parse(rawLegacy);
      if (Array.isArray(parsed)) {
        parsed.forEach((rf) => upsert({ ...rf, _source: "legacy_local" }));
      }
    }
  } catch {}

  // 3. Version-checked cloud fetch (Firestore-first; RTDB only fallback if Firestore fails)
  const rawFeesCacheKey = `${LOCAL_FEES_PREFIX}${schoolId}`;
  const [{ fetch: shouldFetchFees, remoteVer }, studentsList, classesList, applicationsList] = await Promise.all([
    useDemo
      ? Promise.resolve({ fetch: false, remoteVer: 0 })
      : shouldFetchDomainFromCloud(
          schoolId,
          "fees",
          rawFeesCacheKey,
          () => getLocalFees(schoolId).length > 0 || isSchoolCacheFresh(rawFeesCacheKey, 24 * 60 * 60 * 1000),
          5 * 60 * 1000
        ),
    getStudents(schoolId).catch(() => getLocalStudents(schoolId)),
    getClasses(schoolId).catch(() => getLocalClasses(schoolId)),
    getAdmissionApplications(schoolId).catch(() => [] as any[]),
  ]);

  if (shouldFetchFees && !useDemo) {
    let fsOk = false;
    const cloudFees: any[] = [];
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/fees`)), 3000);
        fsOk = true;
        snap.docs.forEach((docSnap) => {
          cloudFees.push({
            ...(docSnap.data() as MonthlyFee),
            _docId: docSnap.id,
            _source: "fees_firestore",
          });
        });
      } catch {}
    }
    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/fees`)), 2500);
        if (snap.exists()) {
          fsOk = true;
          const val = snap.val() || {};
          Object.entries(val)
            .filter(([, v]) => v && typeof v === "object")
            .forEach(([k, v]) => {
              cloudFees.push({
                ...(v as MonthlyFee),
                _docId: k,
                _source: "fees_rtdb",
              });
            });
        }
      } catch {}
    }
    cloudFees.forEach(upsert);
    if (fsOk) {
      setLocalFees(schoolId, cloudFees.map(({ _docId, _source, ...rest }) => rest as MonthlyFee));
      markSchoolCacheFresh(rawFeesCacheKey, remoteVer);
    }
  }

  const studentById = new Map<string, SchoolStudent>();
  (studentsList || []).forEach((st) => {
    if (st?.id && (useDemo || !isDemoRecord(st))) {
      studentById.set(st.id, st);
    }
  });

  const classById = new Map<string, string>();
  (classesList || []).forEach((cls) => {
    if (cls?.id) {
      classById.set(cls.id, `${cls.name}${cls.section ? ` (${cls.section})` : ""}`.trim());
    }
  });

  // Track seen receipt numbers so synthetic fallbacks never duplicate real fee docs
  const seenReceiptNos = new Set<string>();
  feeMap.forEach((f) => {
    const rNo = String(f.receiptNo || f.receiptNumber || "").trim().toUpperCase();
    if (rNo) seenReceiptNos.add(rNo);
  });

  // 4. Fallback synthesis from Student admissionReceiptNo / admissionBalanceHistory / reAdmissionReceiptNo
  studentById.forEach((st) => {
    const clsName = st.className || classById.get(st.classId) || "";
    const admRec = String(st.admissionReceiptNo || "").trim();
    const admPaid = Number(st.admissionPaidAmount || 0);
    if (admRec && admPaid > 0 && !seenReceiptNos.has(admRec.toUpperCase()) && !(st as any).admissionReceiptCancelled) {
      seenReceiptNos.add(admRec.toUpperCase());
      upsert({
        schoolId,
        sessionId: st.sessionId || "",
        studentId: st.id,
        studentName: st.name,
        rollNo: st.rollNo || "",
        classId: st.classId || "",
        className: clsName,
        admissionNo: st.admissionNo || "",
        phone: st.phone || "",
        month: ((st as any).admissionDate || st.joinDate || st.createdAt || new Date().toISOString()).slice(0, 7),
        amount: Number(st.admissionTotalAmount || admPaid),
        paid: Number(st.admissionDueBalance || 0) <= 0,
        paidDate: (st as any).admissionDate || st.joinDate || st.createdAt,
        receiptNo: admRec,
        paidAmount: admPaid,
        balanceDue: Number(st.admissionDueBalance || 0),
        feeType: "admission",
        receiptCategory: "admission",
        paymentMode: "Counter / Admission",
        _source: "student_admission",
        _isSynthetic: true,
      });
    }

    if (Array.isArray(st.admissionBalanceHistory)) {
      st.admissionBalanceHistory.forEach((hist: any, idx: number) => {
        const hRec = String(hist?.receiptNo || "").trim();
        const hPaid = Number(hist?.paidAmount || 0);
        if (hRec && hPaid > 0 && !hist?.cancelled && !seenReceiptNos.has(hRec.toUpperCase())) {
          seenReceiptNos.add(hRec.toUpperCase());
          upsert({
            schoolId,
            sessionId: st.sessionId || "",
            studentId: st.id,
            studentName: st.name,
            rollNo: st.rollNo || "",
            classId: st.classId || "",
            className: clsName,
            admissionNo: st.admissionNo || "",
            phone: st.phone || "",
            month: String(hist.date || new Date().toISOString()).slice(0, 7),
            amount: hPaid,
            paid: true,
            paidDate: hist.date || new Date().toISOString().slice(0, 10),
            receiptNo: hRec,
            paidAmount: hPaid,
            feeType: "admission",
            receiptCategory: "admission",
            paymentMode: hist.paymentMode || "Cash",
            _source: "student_balance_history",
            _balHistoryIndex: idx,
            _isSynthetic: true,
          });
        }
      });
    }

    const readmRec = String(st.reAdmissionReceiptNo || "").trim();
    const readmPaid = Number(st.reAdmissionPaidAmount || 0);
    if (readmRec && readmPaid > 0 && !seenReceiptNos.has(readmRec.toUpperCase())) {
      seenReceiptNos.add(readmRec.toUpperCase());
      upsert({
        schoolId,
        sessionId: st.sessionId || "",
        studentId: st.id,
        studentName: st.name,
        rollNo: st.rollNo || "",
        classId: st.classId || "",
        className: clsName,
        admissionNo: st.admissionNo || "",
        phone: st.phone || "",
        month: (st.reAdmissionDate || new Date().toISOString()).slice(0, 7),
        amount: Number(st.reAdmissionFee || readmPaid),
        paid: true,
        paidDate: st.reAdmissionDate || st.createdAt,
        receiptNo: readmRec,
        paidAmount: readmPaid,
        feeType: "admission",
        receiptCategory: "admission",
        paymentMode: "Re-Admission",
        _source: "student_readmission",
        _isSynthetic: true,
      });
    }
  });

  // 5. Fallback synthesis from Admission Applications (`admissionFeeDetails`)
  (applicationsList || []).forEach((app: any) => {
    const det = app?.admissionFeeDetails;
    const aRec = String(det?.receiptNo || "").trim();
    const aPaid = Number(det?.paidAmount || 0);
    if (aRec && aPaid > 0 && !det?.cancelled && !seenReceiptNos.has(aRec.toUpperCase())) {
      seenReceiptNos.add(aRec.toUpperCase());
      const st = app.enrolledStudentId ? studentById.get(app.enrolledStudentId) : undefined;
      upsert({
        schoolId,
        sessionId: app.targetSessionId || st?.sessionId || "",
        studentId: app.enrolledStudentId || app.id,
        studentName: app.studentName || st?.name || "Student",
        rollNo: app.assignedRollNo || st?.rollNo || "",
        classId: app.classId || st?.classId || "",
        className: app.className || st?.className || classById.get(app.classId) || "",
        admissionNo: st?.admissionNo || app.applicationNo || "",
        phone: app.phone || st?.phone || "",
        month: String(det.paidDate || app.appliedAt || new Date().toISOString()).slice(0, 7),
        amount: Number(det.totalPayable || aPaid),
        paid: Number(det.balanceDue || 0) <= 0,
        paidDate: det.paidDate || app.appliedAt,
        receiptNo: aRec,
        paidAmount: aPaid,
        balanceDue: Number(det.balanceDue || 0),
        feeType: "admission",
        receiptCategory: "admission",
        paymentMode: det.paymentMode || "Cash",
        items: det.items,
        _appId: app.id,
        _source: "admission_application",
        _isSynthetic: true,
      });
    }
  });

  // Enrich missing metadata (className, admissionNo, phone, paymentMode)
  const list = Array.from(feeMap.values()).map((f) => {
    const st = f.studentId ? studentById.get(f.studentId) : undefined;
    const resolvedClassName = f.className || st?.className || classById.get(f.classId) || "";
    const resolvedPayMode = f.paymentMode || f.payModeInfo?.payMode || "Cash";
    return {
      ...f,
      id: f.id || f.receiptNo || f._docId || `${f.studentId}_${f.month || "fee"}`,
      className: resolvedClassName,
      rollNo: f.rollNo || st?.rollNo || "",
      admissionNo: f.admissionNo || st?.admissionNo || "",
      phone: f.phone || st?.phone || "",
      paymentMode: resolvedPayMode,
    };
  });

  return list.sort((a, b) => {
    const da = String(a.paidDate || a.updatedAt || a.month || "");
    const dbDate = String(b.paidDate || b.updatedAt || b.month || "");
    return dbDate.localeCompare(da);
  });
};

export const cancelSchoolFeeReceipt = async (
  schoolId: string,
  receipt: any,
  cancelDetails: {
    voucherNo: string;
    reason: string;
    remarks: string;
    refundMode: string;
    authorizedBy: string;
    refundAmount: number;
  }
): Promise<void> => {
  if (!schoolId || !receipt) return;
  const nowIso = new Date().toISOString();
  const targetRecNo = String(receipt.receiptNo || receipt.receiptNumber || "").trim();

  // Strip internal UI/meta keys before saving to Firestore/RTDB
  const cleanBase: Record<string, any> = {};
  Object.entries(receipt).forEach(([k, v]) => {
    if (!k.startsWith("_") && k !== "admissionNo" && k !== "phone" && k !== "receiptNumber") {
      cleanBase[k] = v;
    }
  });

  const cancelledRecord: MonthlyFee & Record<string, any> = {
    ...(cleanBase as MonthlyFee),
    schoolId,
    status: "CANCELLED",
    cancelled: true,
    paid: false,
    paidAmount: 0,
    cancelledAt: nowIso,
    cancellationReason: cancelDetails.reason,
    refundVoucherNo: cancelDetails.voucherNo,
    refundMode: cancelDetails.refundMode,
    refundRemarks: cancelDetails.remarks,
    authorizedBy: cancelDetails.authorizedBy,
    refundedAmount: cancelDetails.refundAmount,
    updatedAt: nowIso,
  };

  // 1. Update local cache `nst_school_fees_<schoolId>`
  try {
    const currentLocal = getLocalFees(schoolId);
    const isMatch = (f: any) => {
      if (targetRecNo && (f.receiptNo === targetRecNo || (f as any).receiptNumber === targetRecNo)) return true;
      if (receipt.id && f.id === receipt.id) return true;
      if (
        f.studentId === receipt.studentId &&
        f.month === receipt.month &&
        Boolean(f.feeType === "admission" || f.receiptCategory === "admission") ===
          Boolean(receipt.feeType === "admission" || receipt.receiptCategory === "admission")
      ) {
        return true;
      }
      return false;
    };
    const foundLocal = currentLocal.some(isMatch);
    const updatedLocal = foundLocal
      ? currentLocal.map((f) => (isMatch(f) ? { ...f, ...cancelledRecord } : f))
      : [cancelledRecord, ...currentLocal];
    setLocalFees(schoolId, updatedLocal);
  } catch {}

  // 2. Update Firestore & RTDB under BOTH canonical saveFee id and original _docId (if different)
  const sanitized = sanitizeForFirestore(cancelledRecord);
  const isAdmissionFee = cancelledRecord.feeType === "admission" || cancelledRecord.receiptCategory === "admission";
  const canonicalId = isAdmissionFee
    ? `${cancelledRecord.studentId}_adm_${cancelledRecord.receiptNo || cancelledRecord.month || Date.now()}`
    : `${cancelledRecord.studentId}_${cancelledRecord.month || cancelledRecord.receiptNo || Date.now()}`;
  const docIdsToUpdate = Array.from(
    new Set([canonicalId, receipt._docId].filter((x): x is string => Boolean(x && typeof x === "string")))
  );

  await Promise.allSettled(
    docIdsToUpdate.flatMap((docId) => [
      rtdb ? withTimeout(set(ref(rtdb, `schools/${schoolId}/fees/${docId}`), sanitized), 2500) : Promise.resolve(),
      db ? withTimeout(setDoc(d(`schools/${schoolId}/fees/${docId}`), sanitized, { merge: true }), 3000) : Promise.resolve(),
    ])
  );

  // 3. Update legacy `school_fee_records_<schoolId>` if present
  try {
    const legacyKey = `school_fee_records_${schoolId}`;
    const rawLegacy = localStorage.getItem(legacyKey);
    if (rawLegacy) {
      const legacyArr = JSON.parse(rawLegacy);
      if (Array.isArray(legacyArr)) {
        const updatedLegacy = legacyArr.map((f: any) => {
          if (
            (targetRecNo && (f.receiptNo === targetRecNo || f.receiptNumber === targetRecNo)) ||
            (receipt.id && f.id === receipt.id)
          ) {
            return { ...f, ...cancelledRecord };
          }
          return f;
        });
        localStorage.setItem(legacyKey, JSON.stringify(updatedLegacy));
      }
    }
  } catch {}

  // 4. Restore student admission dues / mark balance history entry cancelled if applicable
  if (receipt.studentId && (isAdmissionFee || (targetRecNo && targetRecNo.startsWith("ADM-")))) {
    try {
      const studentsList = await getStudents(schoolId).catch(() => getLocalStudents(schoolId));
      const matchedStudent = studentsList.find((s) => s.id === receipt.studentId);
      if (matchedStudent) {
        const studentPatch: Record<string, any> = {};
        if (targetRecNo && matchedStudent.admissionReceiptNo === targetRecNo && !(matchedStudent as any).admissionReceiptCancelled) {
          const curPaid = Number(matchedStudent.admissionPaidAmount || 0);
          const restoreAmt = Math.min(curPaid, Number(cancelDetails.refundAmount || 0));
          studentPatch.admissionPaidAmount = Math.max(0, curPaid - restoreAmt);
          if (cancelDetails.refundMode !== "ADJUST_FUTURE_DUES") {
            studentPatch.admissionDueBalance = Number(matchedStudent.admissionDueBalance || 0) + restoreAmt;
          }
          studentPatch.admissionReceiptCancelled = true;
          studentPatch.admissionRefundVoucherNo = cancelDetails.voucherNo;
        }
        if (targetRecNo && Array.isArray(matchedStudent.admissionBalanceHistory)) {
          let changedHist = false;
          const nextHist = matchedStudent.admissionBalanceHistory.map((h: any) => {
            if (h?.receiptNo === targetRecNo && !h.cancelled) {
              changedHist = true;
              return { ...h, cancelled: true, refundVoucherNo: cancelDetails.voucherNo, cancelledAt: nowIso };
            }
            return h;
          });
          if (changedHist) {
            studentPatch.admissionBalanceHistory = nextHist;
            if (cancelDetails.refundMode !== "ADJUST_FUTURE_DUES") {
              studentPatch.admissionDueBalance =
                Number(matchedStudent.admissionDueBalance || 0) + Number(cancelDetails.refundAmount || 0);
            }
          }
        }
        if (Object.keys(studentPatch).length > 0) {
          await updateStudent(schoolId, matchedStudent.id, studentPatch);
        }
      }
    } catch {}
  }

  // 5. Update admission_application if this receipt also exists inside admissionFeeDetails
  if (targetRecNo) {
    try {
      const apps = await getAdmissionApplications(schoolId).catch(() => [] as any[]);
      const matchingApp = apps.find(
        (a: any) =>
          (receipt._appId && a.id === receipt._appId) ||
          (a?.admissionFeeDetails?.receiptNo === targetRecNo && !a?.admissionFeeDetails?.cancelled)
      );
      if (matchingApp && matchingApp.admissionFeeDetails) {
        await saveAdmissionApplication(schoolId, {
          ...matchingApp,
          admissionFeeDetails: {
            ...matchingApp.admissionFeeDetails,
            cancelled: true,
            refundVoucherNo: cancelDetails.voucherNo,
            cancelledAt: nowIso,
          } as any,
        });
      }
    } catch {}
  }

  markSchoolCacheFresh(`${LOCAL_FEES_PREFIX}${schoolId}`);
  if (receipt.studentId) markSchoolCacheFresh(`nst_std_fees_${schoolId}_${receipt.studentId}`);
  if (receipt.month) markSchoolCacheFresh(`nst_month_fees_${schoolId}_${receipt.month}`);
  touchSchoolSyncVersion(schoolId, "fees");

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("fee-updated", {
        detail: { schoolId, studentId: receipt.studentId, fee: sanitized },
      })
    );
  }
};


export const subscribeToClassFees = (schoolId: string, month: string, classId: string, cb: (fees: MonthlyFee[]) => void) => {
  if (!schoolId || !month) {
    cb([]);
    return () => {};
  }
  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    const local = getLocalFees(schoolId).filter(f => f.month === month && (!classId || f.classId === classId));
    cb(local);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getMonthlyFees(schoolId, month, classId)
      .then((list) => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onFeeEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("fee-updated", onFeeEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("fee-updated", onFeeEvt);
    }
  };
};

export const markFeePaid = async (
  schoolId: string,
  studentId: string,
  month: string,
  paidBy: string,
  collectorInfo?: {
    collectedBy?: string;
    collectedByRole?: "accountant" | "manager";
    collectedByName?: string;
    collectorSignatureUrl?: string;
  }
) => {
  const id = `${studentId}_${month}`;
  const patch: Record<string, any> = {
    paid: true,
    paidDate: new Date().toISOString(),
    paidBy,
    receiptNo: `RCP-${Date.now()}`
  };
  if (collectorInfo?.collectedBy) patch.collectedBy = collectorInfo.collectedBy;
  if (collectorInfo?.collectedByRole) patch.collectedByRole = collectorInfo.collectedByRole;
  if (collectorInfo?.collectedByName) patch.collectedByName = collectorInfo.collectedByName;
  if (collectorInfo?.collectorSignatureUrl) patch.collectorSignatureUrl = collectorInfo.collectorSignatureUrl;
  let paidAmount = 0;
  try {
    const cur = getLocalFees(schoolId);
    const existing = cur.find(f => f.studentId === studentId && f.month === month);
    paidAmount = existing?.amount || 0;
    setLocalFees(schoolId, cur.map(f => (f.studentId === studentId && f.month === month) ? { ...f, ...patch } : f));
    markSchoolCacheFresh(`${LOCAL_FEES_PREFIX}${schoolId}`);
    markSchoolCacheFresh(`nst_std_fees_${schoolId}_${studentId}`);
    markSchoolCacheFresh(`nst_month_fees_${schoolId}_${month}`);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("fee-updated", { detail: { schoolId, studentId, fee: patch } }));
  }
  if (rtdb) {
    try { await update(ref(rtdb, `schools/${schoolId}/fees/${id}`), sanitizeForFirestore(patch)); } catch {}
  }
  if (db) {
    try {
      await setDoc(d(`schools/${schoolId}/fees/${id}`), sanitizeForFirestore(patch), { merge: true });
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "fees");

  // Auto route Official Fee Receipt to student's NSTA Messenger School Desk
  try {
    const student = getLocalStudents(schoolId).find(s => s.id === studentId);
    autoSendFeeSlipToSchoolDesk({
      schoolId,
      studentId,
      studentName: student?.name || "Student",
      slipType: "FEE_RECEIPT",
      month,
      monthLabel: month,
      amount: paidAmount,
      balanceDue: 0,
      receiptNo: patch.receiptNo,
      dueDate: new Date().toISOString().split("T")[0],
    }).catch(() => {});
  } catch {}
};

export const updateStudentPhoto = async (schoolId: string, studentId: string, photoUrl: string) => {
  const cloudUrl = await ensureCloudImageUrl(photoUrl, `std_photo_${schoolId}_${studentId}`);
  let updatedRecord: SchoolStudent | null = null;
  try {
    const local = getLocalStudents(schoolId);
    const updated = local.map(s => {
      if (s.id === studentId || s.admissionNo === studentId || s.rollNo === studentId) {
        updatedRecord = { ...s, photoUrl: cloudUrl };
        return updatedRecord;
      }
      return s;
    });
    setLocalStudents(schoolId, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("student-updated", {
        detail: { schoolId, studentId, data: updatedRecord || { id: studentId, photoUrl: cloudUrl } }
      })
    );
  }

  if (rtdb) {
    try { await update(ref(rtdb, `schools/${schoolId}/students/${studentId}`), { photoUrl: cloudUrl }); } catch {}
  }
  if (db) {
    try {
      await setDoc(d(`schools/${schoolId}/students/${studentId}`), { photoUrl: cloudUrl }, { merge: true });
    } catch {}
  }
  return cloudUrl;
};

// ── HOMEWORK ─────────────────────────────────────────────────────────────────

export const saveHomework = async (hw: SchoolHomework) => {
  const sanitized = sanitizeForFirestore(hw);
  const key = `nst_school_homework_${hw.schoolId}`;
  try {
    const cur = getSchoolCacheSync<SchoolHomework[]>(key, []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur : []).filter(item => item.id !== hw.id)];
    setSchoolCacheSync(key, next);
    markSchoolCacheFresh(key);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("homework-updated", { detail: { schoolId: hw.schoolId, classId: hw.classId } }));
  }
  let fsOk = false;
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${hw.schoolId}/homework/${hw.id}`), sanitized), 2500);
      fsOk = true;
      touchSchoolSyncVersion(hw.schoolId, "homework");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${hw.schoolId}/homework/${hw.id}`), sanitized), 2000); } catch {}
  }
};

export const getHomework = async (schoolId: string, classId?: string): Promise<SchoolHomework[]> => {
  await whenSchoolIdbReady();
  const useDemo = shouldUseDemoForSchool(schoolId);
  const cacheKey = `nst_school_homework_${schoolId}`;
  let local = getSchoolCacheSync<SchoolHomework[]>(cacheKey, []);
  if (!Array.isArray(local)) local = [];

  if (!useDemo) {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "homework",
      cacheKey,
      () => local.length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      15 * 60 * 1000
    );
    if (fetch && db) {
      local = await dedupInflight<SchoolHomework[]>(`homework:${schoolId}`, async () => {
        try {
          const snap = await withTimeout(getDocs(col(`schools/${schoolId}/homework`)), 2500);
          const remote = snap.docs.map(docSnap => docSnap.data() as SchoolHomework);
          const merged = remote.length > 0
            ? [...remote, ...local.filter(l => !remote.some(r => r.id === l.id))]
            : local;
          setSchoolCacheSync(cacheKey, merged);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return merged;
        } catch {
          return local;
        }
      });
    }
  }

  const filtered = classId ? local.filter(h => !h.classId || isStudentInClass(h as any, classId) || h.classId === classId) : local;
  const clean = !useDemo ? filtered.filter(h => !isDemoRecord(h)) : filtered;
  return clean.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
};

// ── MCQ RESULTS (school) ─────────────────────────────────────────────────────
const LOCAL_MCQ_RES_PREFIX = "nst_school_mcq_res_";

export const saveSchoolMCQResult = async (result: SchoolMCQResult) => {
  const clean = sanitizeForFirestore(result);
  const cacheKey = `${LOCAL_MCQ_RES_PREFIX}${result.schoolId}`;
  try {
    const cur = getSchoolCacheSync<SchoolMCQResult[]>(cacheKey, []);
    setSchoolCacheSync(cacheKey, [clean, ...(Array.isArray(cur) ? cur : []).filter(r => r.id !== result.id)]);
    markSchoolCacheFresh(cacheKey);
  } catch {}
  await setDoc(d(`schools/${result.schoolId}/mcq_results/${result.id}`), clean);
  touchSchoolSyncVersion(result.schoolId, "mcq_results");
};

export const getClassMCQResults = async (schoolId: string, classId: string): Promise<SchoolMCQResult[]> => {
  await whenSchoolIdbReady();
  const cacheKey = `${LOCAL_MCQ_RES_PREFIX}${schoolId}`;
  const local = getSchoolCacheSync<SchoolMCQResult[]>(cacheKey, []);
  const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "mcq_results",
    cacheKey,
    () => (Array.isArray(local) && local.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
    15 * 60 * 1000
  );

  let pool = Array.isArray(local) ? local : [];
  if (fetch && db) {
    pool = await dedupInflight<SchoolMCQResult[]>(`mcq_results:${schoolId}`, async () => {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/mcq_results`)), 2500);
        const list = snap.docs.map(docSnap => docSnap.data() as SchoolMCQResult);
        setSchoolCacheSync(cacheKey, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {
        return pool;
      }
    });
  }

  return pool
    .filter(r => r.classId === classId)
    .sort((a, b) => (b.date || "").localeCompare(a.date || ""));
};

// ── SCHOOL USER PROFILE ──────────────────────────────────────────────────────

export const saveSchoolUserProfile = async (profile: SchoolUserProfile) => {
  const sanitized = sanitizeForFirestore(profile);
  setSchoolCacheSync(`nst_school_user_${profile.uid}`, sanitized);
  const safeUid = cleanRtdbUid(profile.uid);

  await ensureFirebaseAuthSession().catch(() => null);

  await Promise.allSettled([
    sbRtdbSet(`school_users/${safeUid}`, sanitized),
    rtdb ? withTimeout(set(ref(rtdb, `school_users/${safeUid}`), sanitized), 2500) : Promise.resolve(),
    db ? withTimeout(setDoc(d(`school_users/${profile.uid}`), sanitized), 3000) : Promise.resolve(),
  ]);
};

export const getSchoolUserProfile = async (uid: string, userEmail?: string): Promise<SchoolUserProfile | null> => {
  const normEmail = (userEmail || "").trim().toLowerCase();
  const safeUid = cleanRtdbUid(uid);

  // 0. Check IndexedDB RAM cached profile first (instant)
  const cached = getSchoolCacheSync<SchoolUserProfile | null>(`nst_school_user_${uid}`, null);
  if (cached && cached.schoolId) {
    return cached;
  }

  await ensureFirebaseAuthSession().catch(() => null);

  // 1. Check RTDB (fastest remote)
  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `school_users/${safeUid}`)), 1800);
      const val = snap?.val?.();
      if (val && val.schoolId) {
        setSchoolCacheSync(`nst_school_user_${uid}`, val);
        return val as SchoolUserProfile;
      }
    } catch {}
  }

  // 2. Check Firestore school_users document
  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`school_users/${uid}`)), 2500);
      if (snap.exists()) {
        const data = snap.data() as SchoolUserProfile;
        if (data && data.schoolId) {
          setSchoolCacheSync(`nst_school_user_${uid}`, data);
          return data;
        }
      }
    } catch {}
  }

  // 2.5 Check Supabase RTDB mirror
  try {
    const sbProfile = await withTimeout(sbRtdbGet<SchoolUserProfile>(`school_users/${safeUid}`), 2000);
    if (sbProfile && sbProfile.schoolId) {
      setSchoolCacheSync(`nst_school_user_${uid}`, sbProfile);
      return sbProfile;
    }
  } catch {}

  // 3. FIRST check if this email was allotted to a SPECIFIC school in SuperAdminPanel!
  // This guarantees Multi-School Admin isolation (School 2's admin ALWAYS opens School 2!).
  if (normEmail) {
    const schools = await getAllSchools();
    const adminSchool = schools.find(s =>
      (s.adminEmail && s.adminEmail.trim().toLowerCase() === normEmail) ||
      (s.email && s.email.trim().toLowerCase() === normEmail)
    );

    if (adminSchool) {
      const autoProfile: SchoolUserProfile = {
        uid,
        schoolId: adminSchool.id,
        role: "SCHOOL_ADMIN",
        name: adminSchool.name + " Admin",
        email: normEmail,
      };
      saveSchoolUserProfile(autoProfile).catch(() => {});
      return autoProfile;
    }
  }

  // 4. Fallback for global default demo school admin emails
  const isAdminEmailMatch =
    normEmail === "nadimanwar794@gmail.com" ||
    normEmail === "nadiman0636indo@gmail.com" ||
    normEmail === "admin@dps.edu.in" ||
    normEmail === "dpsgurgaon45@dps.edu.in" ||
    normEmail.startsWith("admin@") ||
    normEmail.includes("schooladmin") ||
    normEmail.includes("principal") ||
    uid === "admin_uid" ||
    uid.toLowerCase().includes("admin");

  if (isAdminEmailMatch) {
    const autoProfile: SchoolUserProfile = {
      uid,
      schoolId: DEFAULT_SCHOOL_ID,
      role: "SCHOOL_ADMIN",
      name: "SHAHID KHAN SIR (Principal & School Admin)",
      email: normEmail || "n@gmail.com",
    };
    saveSchoolUserProfile(autoProfile).catch(() => {});
    return autoProfile;
  }

  return null;
};

export const subscribeToSchoolUserProfile = (uid: string, cb: (p: SchoolUserProfile | null) => void) =>
  onSnapshot(
    d(`school_users/${uid}`),
    snap => cb(snap.exists() ? snap.data() as SchoolUserProfile : null),
    err => { console.warn(`[school-firebase] subscribeToSchoolUserProfile error:`, err?.code || err); cb(null); }
  );

// ── LOCK CODE ────────────────────────────────────────────────────────────────

export const setSchoolLockCode = async (schoolId: string, lockCode: string, active: boolean) => {
  await updateSchool(schoolId, { lockCode, lockCodeActive: active });
};

export const verifySchoolLockCode = async (schoolId: string, enteredCode: string): Promise<boolean> => {
  const snap = await getDoc(d(`schools/${schoolId}`));
  if (!snap.exists()) return false;
  const school = snap.data();
  if (!school.lockCodeActive || !school.lockCode) return true;
  return school.lockCode === enteredCode;
};

// ── ASSIGN SCHOOL ROLE BY EMAIL ───────────────────────────────────────────────
// Check if an email is already allotted to any school (Strict 1 Email = 1 School Rule)
export const checkEmailSchoolAllotment = async (
  email: string,
  excludeSchoolId?: string
): Promise<{ isAllotted: boolean; schoolName?: string; schoolId?: string }> => {
  const normEmail = (email || '').trim().toLowerCase();
  if (!normEmail) return { isAllotted: false };

  // 1. Check all schools in memory / cache / db
  const allSchools = await getAllSchools();
  const existing = allSchools.find(
    s => (!excludeSchoolId || s.id !== excludeSchoolId) && s.adminEmail && s.adminEmail.trim().toLowerCase() === normEmail
  );
  if (existing) {
    return { isAllotted: true, schoolName: existing.name, schoolId: existing.id };
  }

  // 2. Check RTDB index
  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `school_admins_by_email/${normEmail.replace(/\./g, '_')}`)), 1500);
      const val = (snap as any)?.val?.();
      if (val && val.schoolId && (!excludeSchoolId || val.schoolId !== excludeSchoolId)) {
        const found = allSchools.find(s => s.id === val.schoolId);
        return { isAllotted: true, schoolName: found?.name || val.schoolId, schoolId: val.schoolId };
      }
    } catch {}
  }

  // 3. Check Firestore school_users
  if (db) {
    try {
      const q = query(col('school_users'), where('email', '==', normEmail), where('role', 'in', ['SCHOOL_ADMIN', 'SCHOOL_SUB_ADMIN']));
      const snap = await withTimeout(getDocs(q), 1500);
      if (!snap.empty) {
        const foundDoc = snap.docs.find(doc => {
          const sId = doc.data()?.schoolId;
          return sId && (!excludeSchoolId || sId !== excludeSchoolId);
        });
        if (foundDoc) {
          const sId = foundDoc.data().schoolId;
          const found = allSchools.find(s => s.id === sId);
          return { isAllotted: true, schoolName: found?.name || sId, schoolId: sId };
        }
      }
    } catch {}
  }

  return { isAllotted: false };
};

// Fast & reliable: updates School adminEmail, updates RTDB, and binds school_users with 1-to-1 enforcement
export const assignSchoolAdminByEmail = async (schoolId: string, email: string): Promise<SchoolUserProfile> => {
  const normEmail = email.trim().toLowerCase();
  if (!normEmail) throw new Error("Email address required");

  // Strict Rule: 1 Email / ID = 1 School Allotment
  const allotmentCheck = await checkEmailSchoolAllotment(normEmail, schoolId);
  if (allotmentCheck.isAllotted) {
    throw new Error(
      `Yeh Email (${normEmail}) pehle se school "${allotmentCheck.schoolName}" ko allot hai! Ek email/ID par sirf 1 hi school allot ho sakta hai.`
    );
  }

  // 1. Immediately update school adminEmail
  await updateSchool(schoolId, { adminEmail: normEmail });

  // 2. Lookup existing user in Firestore or RTDB
  let targetUid = "";
  let targetName = normEmail;

  try {
    const q = query(col('users'), where('email', '==', normEmail));
    const snap = await withTimeout(getDocs(q), 2500);
    if (!snap.empty) {
      const uDoc = snap.docs[0];
      targetUid = uDoc.id || uDoc.data()?.id;
      targetName = uDoc.data()?.name || uDoc.data()?.displayName || normEmail;
    }
  } catch (err) {
    console.warn("[school-firebase] email query in users error:", err);
  }

  // If UID not found yet, use hashed or normalized key so it activates immediately
  if (!targetUid) {
    targetUid = `pending_${normEmail.replace(/[^a-z0-9]/g, '_')}`;
  }

  const profile: SchoolUserProfile = {
    uid: targetUid,
    schoolId,
    role: 'SCHOOL_ADMIN',
    name: targetName,
    email: normEmail,
  };

  // 3. Save profile in Firestore and RTDB
  if (db && !targetUid.startsWith('pending_')) {
    await withTimeout(setDoc(d(`school_users/${targetUid}`), sanitizeForFirestore(profile)), 3000);
  }
  if (rtdb) {
    await withTimeout(set(ref(rtdb, `school_admins_by_email/${normEmail.replace(/\./g, '_')}`), {
      schoolId,
      email: normEmail,
      assignedAt: new Date().toISOString()
    }), 2000).catch(() => {});
  }

  return profile;
};

export const assignSchoolSubAdminByEmail = async (schoolId: string, email: string): Promise<SchoolUserProfile> => {
  const normEmail = email.trim().toLowerCase();
  const q = query(col('users'), where('email', '==', normEmail));
  const snap = await withTimeout(getDocs(q), 2500);
  let uid = snap.empty ? `pending_${normEmail.replace(/[^a-z0-9]/g, '_')}` : snap.docs[0].id;
  let name = snap.empty ? normEmail : snap.docs[0].data()?.name || normEmail;

  const profile: SchoolUserProfile = {
    uid,
    schoolId,
    role: 'SCHOOL_SUB_ADMIN',
    name,
    email: normEmail,
  };
  await withTimeout(setDoc(d(`school_users/${uid}`), sanitizeForFirestore(profile)), 3000);
  return profile;
};

export const removeSchoolUserByUid = async (uid: string) => {
  await deleteDoc(d(`school_users/${uid}`));
  if (rtdb) {
    try { await remove(ref(rtdb, `school_users/${uid}`)); } catch {}
  }
};

export const getSchoolAdmins = async (schoolId: string): Promise<SchoolUserProfile[]> => {
  const q = query(col('school_users'), where('schoolId', '==', schoolId), where('role', 'in', ['SCHOOL_ADMIN', 'SCHOOL_SUB_ADMIN']));
  const snap = await getDocs(q);
  return snap.docs.map(d => ({ uid: d.id, ...(d.data() as any) } as SchoolUserProfile));
};

// ── FEE ALL CLASSES ──────────────────────────────────────────────────────────
// (Handled by getMonthlyFees above)

// ── ACCOUNT LINKING (NAME + MOBILE + ROLL NUMBER) ─────────────────────────────
// Student enters Name, Mobile Number, and Roll Number → strict match against school students

export const linkStudentAccount = async (
  schoolId: string,
  iicUid: string,
  studentName: string,
  mobileNumber: string,
  rollNo: string,
  classId?: string
): Promise<{ success: boolean; message: string; studentId?: string; student?: SchoolStudent }> => {
  const cleanName = (studentName || "").trim().toLowerCase().replace(/\s+/g, " ");
  const cleanRoll = (rollNo || "").trim().toLowerCase();
  const cleanPhone = (mobileNumber || "").replace(/\D/g, "").slice(-10); // last 10 digits

  if (!cleanName) {
    return { success: false, message: "Kripya apna poora Naam daalein." };
  }
  if (!cleanRoll) {
    return { success: false, message: "Kripya apna Roll Number daalein." };
  }
  if (!cleanPhone || cleanPhone.length < 10) {
    return { success: false, message: "Kripya 10 ankon ka Mobile Number daalein." };
  }

  // Fetch all students for this school
  const snap = await withTimeout(getDocs(col(`schools/${schoolId}/students`)), 3500);
  const allStudents = snap.docs.map(d => ({ id: d.id, ...d.data() })) as SchoolStudent[];

  const normalize = (s: string) => (s || "").trim().toLowerCase().replace(/\s+/g, " ");

  // Matching algorithm:
  // 1. Roll number must match exactly
  // 2. Name must match or start with same first/last name
  // 3. Mobile: if student record already has phone, it must match. If student record has no phone yet, we match by Roll + Name and save the mobile!
  const match = allStudents.find(s => {
    if (classId && s.classId && s.classId !== classId) return false;

    const sRoll = normalize(s.rollNo);
    const sName = normalize(s.name);
    const sPhone = (s.phone || "").replace(/\D/g, "").slice(-10);

    const rollMatches = sRoll === cleanRoll;
    const nameMatches = sName === cleanName || sName.includes(cleanName) || cleanName.includes(sName);

    if (!rollMatches || !nameMatches) return false;

    // If student record already had a phone, verify it
    if (sPhone && sPhone.length >= 10) {
      return sPhone === cleanPhone;
    }

    // If student didn't have phone filled during admission, Roll + Name matched
    return true;
  });

  if (!match) {
    return {
      success: false,
      message: "❌ Record Match Nahi Hua! Kripya apna Naam, Roll Number aur Mobile Number sahi daalein (jo school register mein darj hai), ya school admin se sampark karein."
    };
  }

  // Already linked to someone else?
  if (match.iicUid && match.iicUid !== iicUid) {
    return {
      success: false,
      message: "Yeh student record pehle se kisi aur account se link hai. Agar yeh aapka record hai to school admin se reset karwayen."
    };
  }

  // Update student record with iicUid and verified phone
  const updatePayload: any = { iicUid };
  if (!match.phone || match.phone.replace(/\D/g, "").slice(-10) !== cleanPhone) {
    updatePayload.phone = cleanPhone;
  }
  await updateDoc(d(`schools/${schoolId}/students/${match.id}`), sanitizeForFirestore(updatePayload));

  // Save school user profile
  const profile: SchoolUserProfile = {
    uid: iicUid,
    schoolId,
    role: 'SCHOOL_STUDENT',
    name: match.name,
    email: match.email || '',
    studentRef: match.id,
    classId: match.classId,
    sessionId: match.sessionId,
  };
  await saveSchoolUserProfile(profile);

  return {
    success: true,
    message: `🎉 Mubarak ho ${match.name}! Aapka account successfully link ho gaya hai.`,
    studentId: match.id,
    student: match
  };
};

// ── 9-MODULE CRUD HELPERS ────────────────────────────────────────────────────

// 1. NOTICES & EVENTS
export const saveNotice = async (notice: import('./school-types').SchoolNotice) => {
  const sanitized = sanitizeForFirestore(notice);
  const key = `nst_school_notices_${notice.schoolId}`;
  try {
    const cur = getSchoolCacheSync<any[]>(key, []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur : []).filter((n: any) => n.id !== notice.id)];
    setSchoolCacheSync(key, next);
    markSchoolCacheFresh(key);
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("notices-updated", { detail: { schoolId: notice.schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${notice.schoolId}/notices/${notice.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${notice.schoolId}/notices/${notice.id}`), sanitized), 2500); } catch {}
  }
  touchSchoolSyncVersion(notice.schoolId, "notices");
};

export const getNotices = async (schoolId: string): Promise<import('./school-types').SchoolNotice[]> => {
  if (!schoolId) return [];
  const cacheKey = `nst_school_notices_${schoolId}`;
  return dedupInflight(`getNotices_${schoolId}`, async () => {
    const useDemo = shouldUseDemoForSchool(schoolId);
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "notices",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      15 * 60 * 1000
    );

    let local = getSchoolCacheSync<import('./school-types').SchoolNotice[]>(cacheKey, []);
    if (!Array.isArray(local)) local = [];

    if (fetch && !useDemo) {
      let fsOk = false;
      if (db) {
        try {
          const snap = await withTimeout(getDocs(col(`schools/${schoolId}/notices`)), 2500);
          fsOk = true;
          const remote = snap.docs.map(docSnap => docSnap.data() as import('./school-types').SchoolNotice).filter(n => !isDemoRecord(n));
          local = remote;
          setSchoolCacheSync(cacheKey, remote);
          markSchoolCacheFresh(cacheKey, remoteVer);
        } catch {}
      }
      if (!fsOk && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/notices`)), 2000);
          const val = snap?.val?.();
          if (val && typeof val === "object") {
            const remote = (Object.values(val) as import('./school-types').SchoolNotice[]).filter(n => !isDemoRecord(n));
            local = remote;
            setSchoolCacheSync(cacheKey, remote);
            markSchoolCacheFresh(cacheKey, remoteVer);
          }
        } catch {}
      }
    }

    const sorted = [...local].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    return !useDemo ? sorted.filter(n => !isDemoRecord(n)) : sorted;
  });
};

export const subscribeToNotices = (
  schoolId: string,
  cb: (notices: import('./school-types').SchoolNotice[]) => void
) => {
  if (!schoolId) return () => {};
  let active = true;
  const useDemo = shouldUseDemoForSchool(schoolId);
  const deliverLocal = () => {
    if (!active) return;
    const list = getSchoolCacheSync<any[]>(`nst_school_notices_${schoolId}`, []);
    if (Array.isArray(list)) {
      const clean = !useDemo ? list.filter((n: any) => !isDemoRecord(n)) : list;
      cb([...clean].sort((a: any, b: any) => (b.createdAt || "").localeCompare(a.createdAt || "")));
    }
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    if (!useDemo) {
      getNotices(schoolId)
        .then((list) => {
          if (active) cb(list);
        })
        .catch(() => {});
    }
  });

  const onLocalEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("notices-updated", onLocalEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("notices-updated", onLocalEvt);
    }
  };
};

export const deleteNotice = async (schoolId: string, noticeId: string) => {
  const key = `nst_school_notices_${schoolId}`;
  try {
    const cur = getSchoolCacheSync<any[]>(key, []);
    if (Array.isArray(cur)) {
      setSchoolCacheSync(key, cur.filter((n: any) => n.id !== noticeId));
      markSchoolCacheFresh(key);
    }
  } catch {}
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("notices-updated", { detail: { schoolId } }));
  }
  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/notices/${noticeId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/notices/${noticeId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "notices");
};

// 2. CERTIFICATES (TC, Character, Bonafide, Merit)
export const saveCertificate = async (cert: import('./school-types').SchoolCertificate) => {
  const sanitized = sanitizeForFirestore(cert);
  const key = `nst_school_certificates_${cert.schoolId}`;
  try {
    const cur = getSchoolCacheSync<any[]>(key, []);
    setSchoolCacheSync(key, [sanitized, ...(Array.isArray(cur) ? cur : []).filter((c: any) => c.id !== cert.id)]);
    markSchoolCacheFresh(key);
  } catch {}
  await setDoc(d(`schools/${cert.schoolId}/certificates/${cert.id}`), sanitized);
  touchSchoolSyncVersion(cert.schoolId, "certificates");
};

export const getCertificates = async (schoolId: string): Promise<import('./school-types').SchoolCertificate[]> => {
  if (!schoolId) return [];
  const cacheKey = `nst_school_certificates_${schoolId}`;
  return dedupInflight(`getCertificates_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "certificates",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      15 * 60 * 1000
    );
    const local = getSchoolCacheSync<import('./school-types').SchoolCertificate[]>(cacheKey, []);
    if (!fetch && Array.isArray(local)) {
      return [...local].sort((a, b) => (b.issueDate || "").localeCompare(a.issueDate || ""));
    }
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/certificates`)), 2500);
        const list = snap.docs.map(doc => doc.data() as import('./school-types').SchoolCertificate).sort((a, b) => (b.issueDate || "").localeCompare(a.issueDate || ""));
        setSchoolCacheSync(cacheKey, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }
    return Array.isArray(local) ? local : [];
  });
};

// 3. ADMIT CARD CONFIG
export const saveAdmitCardConfig = async (config: import('./school-types').SchoolAdmitCardConfig) => {
  const sanitized = sanitizeForFirestore(config);
  const key = `nst_school_admit_cards_${config.schoolId}`;
  try {
    const cur = getSchoolCacheSync<any[]>(key, []);
    setSchoolCacheSync(key, [sanitized, ...(Array.isArray(cur) ? cur : []).filter((c: any) => c.id !== config.id)]);
    markSchoolCacheFresh(key);
  } catch {}
  await setDoc(d(`schools/${config.schoolId}/admit_cards/${config.id}`), sanitized);
  touchSchoolSyncVersion(config.schoolId, "admit_cards");
};

export const getAdmitCardConfigs = async (schoolId: string): Promise<import('./school-types').SchoolAdmitCardConfig[]> => {
  if (!schoolId) return [];
  const cacheKey = `nst_school_admit_cards_${schoolId}`;
  return dedupInflight(`getAdmitCardConfigs_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "admit_cards",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      15 * 60 * 1000
    );
    const local = getSchoolCacheSync<import('./school-types').SchoolAdmitCardConfig[]>(cacheKey, []);
    if (!fetch && Array.isArray(local)) return local;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/admit_cards`)), 2500);
        const list = snap.docs.map(doc => doc.data() as import('./school-types').SchoolAdmitCardConfig);
        setSchoolCacheSync(cacheKey, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }
    return Array.isArray(local) ? local : [];
  });
};

// 4. STAFF HRM & LEAVE MANAGEMENT
export const setLocalStaffEmployees = (schoolId: string, staffList: import('./school-types').StaffEmployee[]) => {
  if (!schoolId) return;
  const deletedIds = getDeletedTeacherIds(schoolId);
  const useDemo = shouldUseDemoForSchool(schoolId);
  const clean = (Array.isArray(staffList) ? staffList : []).filter(
    (s) => isActiveStaffRecord(s) && !deletedIds.has(s.id) && (useDemo || !isDemoRecord(s))
  );
  try {
    setSchoolCacheSync(`${LOCAL_STAFF_PREFIX}${schoolId}`, clean);
    if (typeof localStorage !== "undefined") localStorage.removeItem(`${LOCAL_STAFF_PREFIX}${schoolId}`);
  } catch {}
};

export const getLocalStaffEmployees = (schoolId: string): import('./school-types').StaffEmployee[] => {
  if (!schoolId) return [];
  const deletedIds = getDeletedTeacherIds(schoolId);
  const useDemo = shouldUseDemoForSchool(schoolId);
  let pool: import('./school-types').StaffEmployee[] = [];
  try {
    const idbList = getSchoolCacheSync<import('./school-types').StaffEmployee[]>(`${LOCAL_STAFF_PREFIX}${schoolId}`, []);
    if (Array.isArray(idbList) && idbList.length > 0) pool = idbList;
  } catch {}
  if (pool.length === 0) {
    try {
      const raw = typeof localStorage !== "undefined" ? localStorage.getItem(`${LOCAL_STAFF_PREFIX}${schoolId}`) : null;
      if (raw) {
        const parsed = JSON.parse(raw);
        if (Array.isArray(parsed)) pool = parsed;
      }
    } catch {}
  }
  return pool.filter(
    (s) => isActiveStaffRecord(s) && !deletedIds.has(s.id) && (useDemo || !isDemoRecord(s))
  );
};

export const saveStaffEmployee = async (staff: import('./school-types').StaffEmployee) => {
  clearTeacherDeletedLocally(staff.schoolId, staff.id);
  const prepared = { ...staff, active: staff.active ?? true };
  const sanitized = sanitizeForFirestore(prepared);

  const cur = getLocalStaffEmployees(staff.schoolId);
  setLocalStaffEmployees(staff.schoolId, [sanitized, ...cur.filter((s) => s.id !== staff.id)]);
  markSchoolCacheFresh(`${LOCAL_STAFF_PREFIX}${staff.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-updated", { detail: { schoolId: staff.schoolId, staff: sanitized } }));
  }

  if (rtdb) {
    try {
      await Promise.allSettled([
        withTimeout(set(ref(rtdb, `schools/${staff.schoolId}/staff/${staff.id}`), sanitized), 2000),
        withTimeout(remove(ref(rtdb, `schools/${staff.schoolId}/deleted_staff/${staff.id}`)), 2000),
      ]);
    } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${staff.schoolId}/staff/${staff.id}`), sanitized), 3000); } catch {}
  }
  touchSchoolSyncVersion(staff.schoolId, "staff");
};

export const getStaffEmployees = async (schoolId: string): Promise<import('./school-types').StaffEmployee[]> => {
  if (!schoolId) return [];
  const cacheKey = `${LOCAL_STAFF_PREFIX}${schoolId}`;
  return dedupInflight(`getStaffEmployees_${schoolId}`, async () => {
    const useDemo = shouldUseDemoForSchool(schoolId);
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "staff",
      cacheKey,
      () => getLocalStaffEmployees(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      10 * 60 * 1000
    );

    const local = getLocalStaffEmployees(schoolId);
    if (!fetch) {
      return local;
    }

    const deletedIds = getDeletedTeacherIds(schoolId);
    const rawMap = new Map<string, import('./school-types').StaffEmployee>();
    let fsOk = false;
    let rtdbOk = false;

    const [activeTeacherIds] = await Promise.all([
      getTeachers(schoolId)
        .then((tList) => new Set(tList.map((t) => t.id)))
        .catch(() => null as Set<string> | null),
      (async () => {
        if (db) {
          try {
            const snap: any = await withTimeout(getDocs(col(`schools/${schoolId}/staff`)), 2500);
            fsOk = true;
            (snap?.docs || []).forEach((docSnap: any) => {
              const data = docSnap.data() as import('./school-types').StaffEmployee;
              const sid = data?.id || docSnap.id;
              if (!sid || (!useDemo && isDemoRecord(data))) return;
              rawMap.set(sid, { ...data, id: sid, schoolId: data?.schoolId || schoolId });
            });
          } catch {}
        }
        if (!fsOk && rtdb) {
          try {
            const [delSSnap, delTSnap, stSnap]: any = await Promise.all([
              withTimeout(get(ref(rtdb, `schools/${schoolId}/deleted_staff`)), 2000).catch(() => null),
              withTimeout(get(ref(rtdb, `schools/${schoolId}/deleted_teachers`)), 2000).catch(() => null),
              withTimeout(get(ref(rtdb, `schools/${schoolId}/staff`)), 2500).catch(() => null),
            ]);
            const val1 = delSSnap?.val?.();
            if (val1 && typeof val1 === "object") Object.keys(val1).forEach((id) => id && deletedIds.add(id));
            const val2 = delTSnap?.val?.();
            if (val2 && typeof val2 === "object") Object.keys(val2).forEach((id) => id && deletedIds.add(id));
            const val = stSnap?.val?.();
            if (stSnap) rtdbOk = true;
            if (val && typeof val === "object") {
              Object.entries(val).forEach(([k, v]: [string, any]) => {
                if (!v || typeof v !== "object") return;
                const sid = v.id || k;
                if (!sid || (!useDemo && isDemoRecord(v))) return;
                rawMap.set(sid, { ...v, id: sid, schoolId: v.schoolId || schoolId });
              });
            }
          } catch {}
        }
      })(),
    ]);

    if (fsOk || rtdbOk) {
      const cleanList: import('./school-types').StaffEmployee[] = [];
      const orphanIds: string[] = [];
      rawMap.forEach((s) => {
        if (!isActiveStaffRecord(s) || deletedIds.has(s.id) || (!useDemo && isDemoRecord(s))) return;
        if (
          activeTeacherIds !== null &&
          s.department === "Academic / Faculty" &&
          !activeTeacherIds.has(s.id)
        ) {
          orphanIds.push(s.id);
          return;
        }
        cleanList.push(s);
      });

      if (orphanIds.length > 0) {
        orphanIds.forEach((oid) => {
          void deleteStaffEmployee(schoolId, oid).catch(() => {});
        });
      }

      setLocalStaffEmployees(schoolId, cleanList);
      markSchoolCacheFresh(cacheKey, remoteVer);
      if (cleanList.length > 0) return cleanList;
    }

    if (useDemo) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.staffEmployees && demo.staffEmployees.length > 0) {
        return demo.staffEmployees;
      }
    }
    return fsOk || rtdbOk ? [] : local;
  });
};

export const deleteStaffEmployee = async (schoolId: string, staffId: string) => {
  if (!schoolId || !staffId) return;
  const deletedAt = new Date().toISOString();
  const deletePatch = {
    active: false,
    isDeleted: true,
    status: "deleted",
    deletedAt,
  };

  markTeacherDeletedLocally(schoolId, staffId);
  markSchoolCacheFresh(`${LOCAL_STAFF_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-deleted", { detail: { schoolId, staffId } }));
    window.dispatchEvent(new CustomEvent("teacher-deleted", { detail: { schoolId, teacherId: staffId } }));
  }

  if (rtdb) {
    try {
      await Promise.allSettled([
        withTimeout(remove(ref(rtdb, `schools/${schoolId}/staff/${staffId}`)), 2500),
        withTimeout(remove(ref(rtdb, `schools/${schoolId}/teachers/${staffId}`)), 2500),
        withTimeout(set(ref(rtdb, `schools/${schoolId}/deleted_staff/${staffId}`), { id: staffId, deletedAt }), 2500),
        withTimeout(set(ref(rtdb, `schools/${schoolId}/deleted_teachers/${staffId}`), { id: staffId, deletedAt }), 2500),
      ]);
    } catch {}
  }

  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/staff/${staffId}`)), 3000);
    } catch {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/staff/${staffId}`), deletePatch, { merge: true }), 3000);
      } catch {}
    }
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/teachers/${staffId}`)), 3000);
    } catch {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/teachers/${staffId}`), deletePatch, { merge: true }), 3000);
      } catch {}
    }
  }

  touchSchoolSyncVersion(schoolId, "staff");
  touchSchoolSyncVersion(schoolId, "teachers");
  import("./utils/faceRecognitionEngineV2")
    .then((m) => m.deleteFaceDescriptor(staffId, schoolId))
    .catch(() => {});
};

const LOCAL_STAFF_LEAVES_PREFIX = "nst_staff_leaves_";

const mergeStaffLeaveLists = (
  ...lists: import('./school-types').StaffLeave[][]
): import('./school-types').StaffLeave[] => {
  const byId = new Map<string, import('./school-types').StaffLeave>();
  for (const list of lists) {
    if (!Array.isArray(list)) continue;
    for (const item of list) {
      if (!item?.id) continue;
      const prev = byId.get(item.id);
      if (!prev) {
        byId.set(item.id, item);
      } else {
        // Prefer finalized (approved/rejected) or newer status
        const prevFinal = prev.status !== "pending";
        const nextFinal = item.status !== "pending";
        byId.set(item.id, nextFinal && !prevFinal ? item : { ...prev, ...item });
      }
    }
  }
  return Array.from(byId.values()).sort((a, b) =>
    String(b.appliedAt || "").localeCompare(String(a.appliedAt || ""))
  );
};

export const getLocalStaffLeaves = (schoolId: string): import('./school-types').StaffLeave[] => {
  try {
    return getSchoolCacheSync<import('./school-types').StaffLeave[]>(`${LOCAL_STAFF_LEAVES_PREFIX}${schoolId}`, []);
  } catch {
    return [];
  }
};

export const setLocalStaffLeaves = (schoolId: string, leaves: import('./school-types').StaffLeave[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_STAFF_LEAVES_PREFIX}${schoolId}`, Array.isArray(leaves) ? leaves : []);
  } catch {}
};

export const saveStaffLeave = async (leave: import('./school-types').StaffLeave) => {
  const clean = sanitizeForFirestore(leave) as import('./school-types').StaffLeave;
  const current = getLocalStaffLeaves(leave.schoolId);
  const next = mergeStaffLeaveLists([clean], current);
  setLocalStaffLeaves(leave.schoolId, next);
  markSchoolCacheFresh(`${LOCAL_STAFF_LEAVES_PREFIX}${leave.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-leaves-updated", { detail: { schoolId: leave.schoolId, leave: clean } }));
  }

  await Promise.allSettled([
    withTimeout(set(ref(rtdb, `schools/${leave.schoolId}/staff_leaves/${leave.id}`), clean), 2500),
    withTimeout(setDoc(d(`schools/${leave.schoolId}/leaves/${leave.id}`), clean, { merge: true }), 3000),
  ]);
  touchSchoolSyncVersion(leave.schoolId, "staff_leaves");
};

export const getStaffLeaves = async (schoolId: string): Promise<import('./school-types').StaffLeave[]> => {
  if (!schoolId) return [];
  const cacheKey = `${LOCAL_STAFF_LEAVES_PREFIX}${schoolId}`;
  return dedupInflight(`getStaffLeaves_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "staff_leaves",
      cacheKey,
      () => getLocalStaffLeaves(schoolId).length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
      5 * 60 * 1000
    );

    const local = getLocalStaffLeaves(schoolId);
    if (!fetch) {
      if (local.length > 0) return local;
      if (shouldUseDemoForSchool(schoolId)) {
        return getDemoSchoolDataset(true)?.staffLeaves || [];
      }
      return [];
    }

    const remoteLists: import('./school-types').StaffLeave[][] = [local];
    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/leaves`)), 2500);
        fsOk = true;
        remoteLists.push(snap.docs.map(doc => doc.data() as import('./school-types').StaffLeave));
      } catch {}
    }
    if (!fsOk && rtdb) {
      try {
        const rtdbSnap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/staff_leaves`)), 2500);
        if (rtdbSnap.exists()) {
          const val = rtdbSnap.val() || {};
          remoteLists.push(Object.values(val) as import('./school-types').StaffLeave[]);
        }
      } catch {}
    }

    const merged = mergeStaffLeaveLists(...remoteLists);
    setLocalStaffLeaves(schoolId, merged);
    markSchoolCacheFresh(cacheKey, remoteVer);
    if (merged.length > 0) return merged;

    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.staffLeaves && demo.staffLeaves.length > 0) {
        return demo.staffLeaves;
      }
    }
    return [];
  });
};

export const updateStaffLeaveStatus = async (
  schoolId: string,
  leaveId: string,
  status: 'approved' | 'rejected',
  remarks?: string
) => {
  const patch = sanitizeForFirestore({
    status,
    remarks: remarks || '',
    reviewedAt: new Date().toISOString(),
  });
  const local = getLocalStaffLeaves(schoolId);
  const updatedLocal = local.map((l) => (l.id === leaveId ? { ...l, ...patch } : l));
  setLocalStaffLeaves(schoolId, updatedLocal);
  markSchoolCacheFresh(`${LOCAL_STAFF_LEAVES_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("staff-leaves-updated", { detail: { schoolId, leaveId, status } }));
  }

  await Promise.allSettled([
    withTimeout(update(ref(rtdb, `schools/${schoolId}/staff_leaves/${leaveId}`), patch), 2500),
    withTimeout(setDoc(d(`schools/${schoolId}/leaves/${leaveId}`), patch, { merge: true }), 3000),
  ]);
  touchSchoolSyncVersion(schoolId, "staff_leaves");
};

export const subscribeStaffLeaves = (
  schoolId: string,
  cb: (leaves: import('./school-types').StaffLeave[]) => void
) => {
  if (!schoolId) return () => {};
  let active = true;

  const emitLocal = () => {
    if (!active) return;
    const local = getLocalStaffLeaves(schoolId);
    if (local.length > 0) {
      cb(local);
    } else if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      cb(demo?.staffLeaves || []);
    } else {
      cb([]);
    }
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    emitLocal();
    getStaffLeaves(schoolId)
      .then((list) => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onLocalEvent = (e: any) => {
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    emitLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", emitLocal);
    window.addEventListener("staff-leaves-updated", onLocalEvent);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", emitLocal);
      window.removeEventListener("staff-leaves-updated", onLocalEvent);
    }
  };
};

// 5. STUDENT PROMOTION SYSTEM (Batch promote)
export const promoteStudents = async (
  schoolId: string,
  targetClassId: string,
  targetSessionId: string,
  studentIds: string[]
): Promise<{ success: boolean; count: number }> => {
  let count = 0;
  for (const id of studentIds) {
    try {
      await updateDoc(d(`schools/${schoolId}/students/${id}`), sanitizeForFirestore({
        classId: targetClassId,
        sessionId: targetSessionId,
      }));
      count++;
    } catch (e) {
      console.warn("[promoteStudents] Failed for student", id, e);
    }
  }
  return { success: true, count };
};


// ── UTILITY ──────────────────────────────────────────────────────────────────

export const generateId = (prefix?: string) => {
  const raw = typeof crypto !== 'undefined' && typeof crypto.randomUUID === 'function'
    ? crypto.randomUUID().replace(/-/g, '').slice(0, 20)
    : `${Date.now().toString(36)}${Math.random().toString(36).slice(2, 12)}`;
  return prefix ? `${prefix}_${raw}` : raw;
};

export const todayStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
};

export const currentMonthStr = () => {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
};

// ── ONLINE ADMISSION & REGISTRATIONS ─────────────────────────────────────────

const LOCAL_ADMISSIONS_KEY = (schoolId: string) => `nst_school_admissions_${schoolId}`;

export const generateNextAdmissionNo = (
  school?: { code?: string; name?: string; id?: string } | null,
  existingCount = 0
): string => {
  const year = new Date().getFullYear();
  const rawPrefix = (school?.code || school?.name || "SCH")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "")
    .slice(0, 4);
  const safePrefix = !rawPrefix || rawPrefix === "DPSA" ? "SCH" : rawPrefix;
  const seq = String(Math.max(1, existingCount + 1)).padStart(3, "0");
  const randSuffix = String(Math.floor(10 + Math.random() * 89));
  return `${safePrefix}-${year}-${seq}${randSuffix}`;
};

export const getAdmissionApplications = async (schoolId: string): Promise<import('./school-types').AdmissionApplication[]> => {
  if (!schoolId) return [];
  const cacheKey = LOCAL_ADMISSIONS_KEY(schoolId);
  return dedupInflight(`getAdmissions_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "admissions",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      5 * 60 * 1000
    );

    const localRaw = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(cacheKey, []);
    const localList = Array.isArray(localRaw) ? localRaw : [];
    if (!fetch) {
      const sorted = [...localList].sort((a, b) => (b.appliedAt || "").localeCompare(a.appliedAt || ""));
      if (sorted.length > 0) return sorted;
      if (shouldUseDemoForSchool(schoolId)) {
        return getDemoSchoolDataset(true)?.admissions || [];
      }
      return [];
    }

    const mergedMap = new Map<string, import('./school-types').AdmissionApplication>();
    localList.forEach(a => { if (a?.id) mergedMap.set(a.id, a); });

    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/admissions`)), 2500);
        fsOk = true;
        const remoteMap = new Map<string, import('./school-types').AdmissionApplication>();
        snap.docs.forEach(docSnap => {
          const data = docSnap.data() as import('./school-types').AdmissionApplication;
          if (data?.id) remoteMap.set(data.id, data);
        });
        const finalRemote = Array.from(remoteMap.values()).sort((a, b) => (b.appliedAt || "").localeCompare(a.appliedAt || ""));
        setSchoolCacheSync(cacheKey, finalRemote);
        markSchoolCacheFresh(cacheKey, remoteVer);
        if (finalRemote.length > 0) return finalRemote;
      } catch (e) {
        console.warn("[getAdmissionApplications] error:", e);
      }
    }

    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/admissions`)), 2000);
        const val = snap?.val?.();
        if (val && typeof val === "object") {
          Object.values(val).forEach((item: any) => {
            if (item?.id) mergedMap.set(item.id, { ...(mergedMap.get(item.id) || {}), ...item });
          });
        }
      } catch {}
    }

    const finalApps = Array.from(mergedMap.values()).sort((a, b) => (b.appliedAt || "").localeCompare(a.appliedAt || ""));
    if (finalApps.length > 0 || fsOk) {
      setSchoolCacheSync(cacheKey, finalApps);
      markSchoolCacheFresh(cacheKey, remoteVer);
      if (finalApps.length > 0) return finalApps;
    }
    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.admissions && demo.admissions.length > 0) {
        return demo.admissions;
      }
    }
    return finalApps;
  });
};

export const saveAdmissionApplication = async (schoolId: string, appData: import('./school-types').AdmissionApplication): Promise<void> => {
  const prepared = { ...appData, schoolId };
  if (prepared.photoUrl && prepared.photoUrl.startsWith("data:image/")) {
    prepared.photoUrl = await ensureCloudImageUrl(prepared.photoUrl, `adm_${schoolId}_${appData.id}`);
  }
  const sanitized = sanitizeForFirestore(prepared);

  try {
    const cur = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(LOCAL_ADMISSIONS_KEY(schoolId), []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur : []).filter(a => a.id !== appData.id)];
    setSchoolCacheSync(LOCAL_ADMISSIONS_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_ADMISSIONS_KEY(schoolId));
  } catch {}
  if (typeof window !== "undefined") {
    try { window.dispatchEvent(new CustomEvent("school-admission-alert", { detail: { schoolId } })); } catch {}
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${schoolId}/admissions/${appData.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/admissions/${appData.id}`), sanitized, { merge: true }), 3000); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "admissions");
};

export const updateAdmissionStatus = async (
  schoolId: string,
  appId: string,
  status: 'pending' | 'approved' | 'rejected',
  details?: Partial<import('./school-types').AdmissionApplication>
): Promise<void> => {
  const patch = sanitizeForFirestore({
    status,
    reviewedAt: new Date().toISOString(),
    ...(details || {})
  });

  try {
    const cur = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(LOCAL_ADMISSIONS_KEY(schoolId), []);
    if (Array.isArray(cur) && cur.length > 0) {
      const next = cur.map(a => a.id === appId ? { ...a, ...patch } : a);
      setSchoolCacheSync(LOCAL_ADMISSIONS_KEY(schoolId), next);
      markSchoolCacheFresh(LOCAL_ADMISSIONS_KEY(schoolId));
    }
  } catch {}
  if (typeof window !== "undefined") {
    try { window.dispatchEvent(new CustomEvent("school-admission-alert", { detail: { schoolId } })); } catch {}
  }

  if (rtdb) {
    try { await withTimeout(update(ref(rtdb, `schools/${schoolId}/admissions/${appId}`), patch), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${schoolId}/admissions/${appId}`), patch, { merge: true }), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "admissions");
};

export const deleteAdmissionApplication = async (
  schoolId: string,
  appId: string
): Promise<void> => {
  if (!schoolId || !appId) return;
  try {
    const cur = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(LOCAL_ADMISSIONS_KEY(schoolId), []);
    const next = (Array.isArray(cur) ? cur : []).filter((a) => a?.id !== appId);
    setSchoolCacheSync(LOCAL_ADMISSIONS_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_ADMISSIONS_KEY(schoolId));
  } catch {}

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/admissions/${appId}`)), 2500); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/admissions/${appId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "admissions");

  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(
        new CustomEvent("school-admission-deleted", {
          detail: { schoolId, appIds: [appId] },
        })
      );
    } catch {}
  }
};

export const deleteAdmissionApplicationsBulk = async (
  schoolId: string,
  appIds: string[]
): Promise<void> => {
  const cleanIds = Array.from(new Set((appIds || []).filter(Boolean)));
  if (!schoolId || cleanIds.length === 0) return;

  const idSet = new Set(cleanIds);
  try {
    const cur = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(LOCAL_ADMISSIONS_KEY(schoolId), []);
    const next = (Array.isArray(cur) ? cur : []).filter((a) => !idSet.has(a?.id));
    setSchoolCacheSync(LOCAL_ADMISSIONS_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_ADMISSIONS_KEY(schoolId));
  } catch {}

  await Promise.all(
    cleanIds.map(async (appId) => {
      if (rtdb) {
        try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/admissions/${appId}`)), 2500); } catch {}
      }
      if (db) {
        try { await withTimeout(deleteDoc(d(`schools/${schoolId}/admissions/${appId}`)), 2500); } catch {}
      }
    })
  );
  touchSchoolSyncVersion(schoolId, "admissions");

  if (typeof window !== "undefined") {
    try {
      window.dispatchEvent(
        new CustomEvent("school-admission-deleted", {
          detail: { schoolId, appIds: cleanIds },
        })
      );
    } catch {}
  }
};

export const subscribeAdmissionApplications = (
  schoolId: string,
  cb: (apps: import('./school-types').AdmissionApplication[]) => void
) => {
  if (!schoolId) {
    cb([]);
    return () => {};
  }
  let active = true;
  const sortApps = (list: import('./school-types').AdmissionApplication[]) =>
    [...list].sort((a, b) => (b.appliedAt || "").localeCompare(a.appliedAt || ""));

  const loadLocal = () => {
    if (!active) return;
    const localRaw = getSchoolCacheSync<import('./school-types').AdmissionApplication[]>(LOCAL_ADMISSIONS_KEY(schoolId), []);
    const arr = Array.isArray(localRaw) ? sortApps(localRaw) : [];
    if (arr.length > 0) {
      cb(arr);
      return;
    }
    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.admissions && demo.admissions.length > 0) {
        cb(demo.admissions);
        return;
      }
    }
    cb(arr);
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    loadLocal();
    getAdmissionApplications(schoolId)
      .then((list) => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onHydrated = () => loadLocal();
  const onAdmissionAlert = () => loadLocal();
  const onAdmissionDeleted = (ev: Event) => {
    const detail = (ev as CustomEvent)?.detail;
    if (detail?.schoolId && detail.schoolId !== schoolId) return;
    loadLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", onHydrated);
    window.addEventListener("school-admission-alert", onAdmissionAlert);
    window.addEventListener("school-admission-deleted", onAdmissionDeleted);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", onHydrated);
      window.removeEventListener("school-admission-alert", onAdmissionAlert);
      window.removeEventListener("school-admission-deleted", onAdmissionDeleted);
    }
  };
};

// ── PUBLIC INQUIRIES ──────────────────────────────────────────────────────────

const LOCAL_INQUIRIES_KEY = (schoolId: string) => `nst_inquiries_${schoolId}`;
const LOCAL_GALLERY_KEY = (schoolId: string) => `nst_gallery_${schoolId}`;

export const getSchoolPublicInquiries = async (schoolId: string): Promise<import('./school-types').SchoolPublicInquiry[]> => {
  if (!schoolId) return [];
  const cacheKey = LOCAL_INQUIRIES_KEY(schoolId);
  return dedupInflight(`getInquiries_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "inquiries",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      10 * 60 * 1000
    );
    const local = getSchoolCacheSync<import('./school-types').SchoolPublicInquiry[]>(cacheKey, []);
    const localList = Array.isArray(local) ? local : [];
    if (!fetch || isDemoSchoolId(schoolId) || !db) {
      return [...localList].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    }
    try {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/inquiries`)), 2500);
      const remote = snap.docs.map(doc => doc.data() as import('./school-types').SchoolPublicInquiry);
      const merged = [...remote].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
      setSchoolCacheSync(cacheKey, merged);
      markSchoolCacheFresh(cacheKey, remoteVer);
      return merged;
    } catch {}
    return [...localList].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
  });
};

export const saveSchoolPublicInquiry = async (schoolId: string, inquiry: import('./school-types').SchoolPublicInquiry): Promise<void> => {
  const payload = sanitizeForFirestore({ ...inquiry, schoolId, updatedAt: new Date().toISOString() });
  try {
    const cur = getSchoolCacheSync<import('./school-types').SchoolPublicInquiry[]>(LOCAL_INQUIRIES_KEY(schoolId), []);
    const next = [payload, ...(Array.isArray(cur) ? cur : []).filter(i => i.id !== payload.id)];
    setSchoolCacheSync(LOCAL_INQUIRIES_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_INQUIRIES_KEY(schoolId));
  } catch {}
  if (!isDemoSchoolId(schoolId) && db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/inquiries/${payload.id}`), payload, { merge: true }), 2500);
      touchSchoolSyncVersion(schoolId, "inquiries");
    } catch {}
  }
};

export const updateSchoolPublicInquiry = async (
  schoolId: string,
  inquiryId: string,
  patch: Partial<import('./school-types').SchoolPublicInquiry>
): Promise<void> => {
  const cleanPatch = sanitizeForFirestore({ ...patch, updatedAt: new Date().toISOString() });
  try {
    const cur = getSchoolCacheSync<import('./school-types').SchoolPublicInquiry[]>(LOCAL_INQUIRIES_KEY(schoolId), []);
    const next = (Array.isArray(cur) ? cur : []).map(i => (i.id === inquiryId ? { ...i, ...cleanPatch } : i));
    setSchoolCacheSync(LOCAL_INQUIRIES_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_INQUIRIES_KEY(schoolId));
  } catch {}
  if (!isDemoSchoolId(schoolId) && db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/inquiries/${inquiryId}`), cleanPatch, { merge: true }), 2500);
      touchSchoolSyncVersion(schoolId, "inquiries");
    } catch {}
  }
};

// ── GALLERY & EVENTS ─────────────────────────────────────────────────────────

export const getSchoolGallery = async (schoolId: string): Promise<import('./school-types').SchoolGalleryItem[]> => {
  if (!schoolId) return [];
  const cacheKey = LOCAL_GALLERY_KEY(schoolId);
  return dedupInflight(`getGallery_${schoolId}`, async () => {
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "gallery",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      15 * 60 * 1000
    );
    const local = getSchoolCacheSync<import('./school-types').SchoolGalleryItem[]>(cacheKey, []);
    const localList = Array.isArray(local) ? local : [];
    if (!fetch || isDemoSchoolId(schoolId) || !db) {
      return localList;
    }
    try {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/gallery`)), 2500);
      const remote = snap.docs.map(doc => doc.data() as import('./school-types').SchoolGalleryItem);
      setSchoolCacheSync(cacheKey, remote);
      markSchoolCacheFresh(cacheKey, remoteVer);
      return remote;
    } catch {}
    return localList;
  });
};

export const saveSchoolGalleryItem = async (schoolId: string, item: import('./school-types').SchoolGalleryItem): Promise<void> => {
  const preparedItem: any = { ...item, schoolId };
  if (preparedItem.imageUrl && typeof preparedItem.imageUrl === "string" && preparedItem.imageUrl.startsWith("data:image/")) {
    preparedItem.imageUrl = await ensureCloudImageUrl(preparedItem.imageUrl, `gal_${schoolId}_${item.id}`);
  }
  const payload = sanitizeForFirestore(preparedItem);
  try {
    const cur = getSchoolCacheSync<import('./school-types').SchoolGalleryItem[]>(LOCAL_GALLERY_KEY(schoolId), []);
    const next = [payload, ...(Array.isArray(cur) ? cur : []).filter(g => g.id !== payload.id)];
    setSchoolCacheSync(LOCAL_GALLERY_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_GALLERY_KEY(schoolId));
  } catch {}
  if (!isDemoSchoolId(schoolId) && db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/gallery/${payload.id}`), payload, { merge: true }), 2500);
      touchSchoolSyncVersion(schoolId, "gallery");
    } catch {}
  }
};

export const deleteSchoolGalleryItem = async (schoolId: string, itemId: string): Promise<void> => {
  try {
    const cur = getSchoolCacheSync<import('./school-types').SchoolGalleryItem[]>(LOCAL_GALLERY_KEY(schoolId), []);
    const next = (Array.isArray(cur) ? cur : []).filter(g => g.id !== itemId);
    setSchoolCacheSync(LOCAL_GALLERY_KEY(schoolId), next);
    markSchoolCacheFresh(LOCAL_GALLERY_KEY(schoolId));
  } catch {}
  if (!isDemoSchoolId(schoolId) && db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/gallery/${itemId}`)), 2500);
      touchSchoolSyncVersion(schoolId, "gallery");
    } catch {}
  }
};

// ── HOLIDAYS & FESTIVALS (LIVE REALTIME SYNC) ────────────────────────────────

const LOCAL_HOLIDAYS_KEY = (schoolId: string) => `nst_holidays_${schoolId}`;

export const getSchoolHolidays = async (schoolId: string): Promise<import('./school-types').SchoolHoliday[]> => {
  if (!schoolId) return [];
  const cacheKey = LOCAL_HOLIDAYS_KEY(schoolId);
  return dedupInflight(`getHolidays_${schoolId}`, async () => {
    try {
      const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
        schoolId,
        "holidays",
        cacheKey,
        () => {
          const list = getSchoolCacheSync<any[]>(cacheKey, []);
          return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
        },
        15 * 60 * 1000
      );
      const rawList = getSchoolCacheSync<import('./school-types').SchoolHoliday[]>(cacheKey, []);
      const localList = Array.isArray(rawList) ? rawList : [];
      if (!fetch) {
        return [...localList].sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
      }

      let fsOk = false;
      if (db) {
        try {
          const snap = await withTimeout(getDocs(col(`schools/${schoolId}/holidays`)), 2500);
          fsOk = true;
          const remote = snap.docs
            .map(docSnap => docSnap.data() as import('./school-types').SchoolHoliday)
            .sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
          setSchoolCacheSync(cacheKey, remote);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return remote;
        } catch {}
      }

      if (!fsOk && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/holidays`)), 2000);
          const val = snap?.val?.();
          if (val && typeof val === "object") {
            const remote = (Object.values(val) as import('./school-types').SchoolHoliday[])
              .sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
            setSchoolCacheSync(cacheKey, remote);
            markSchoolCacheFresh(cacheKey, remoteVer);
            return remote;
          }
        } catch {}
      }

      return [...localList].sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
    } catch {
      return [];
    }
  });
};

export const saveSchoolHoliday = async (schoolId: string, holiday: import('./school-types').SchoolHoliday): Promise<void> => {
  const sanitized = sanitizeForFirestore({ ...holiday, schoolId });
  try {
    const list = getSchoolCacheSync<import('./school-types').SchoolHoliday[]>(LOCAL_HOLIDAYS_KEY(schoolId), []);
    const updated = [sanitized, ...(Array.isArray(list) ? list : []).filter(h => h.id !== holiday.id)].sort((a, b) => (a.startDate || "").localeCompare(b.startDate || ""));
    setSchoolCacheSync(LOCAL_HOLIDAYS_KEY(schoolId), updated);
    markSchoolCacheFresh(LOCAL_HOLIDAYS_KEY(schoolId));
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("holidays-updated", { detail: { schoolId, holiday: sanitized } }));
    window.dispatchEvent(new CustomEvent("notices-updated", { detail: { schoolId } }));
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/holidays/${holiday.id}`), sanitized), 2000);
    } catch {}
  }

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/holidays/${holiday.id}`), sanitized), 2500);
    } catch (e) {
      console.warn("[school-firebase] saveSchoolHoliday:", e);
    }
  }
  touchSchoolSyncVersion(schoolId, "holidays");
};

export const deleteSchoolHoliday = async (schoolId: string, holidayId: string): Promise<void> => {
  try {
    const list = getSchoolCacheSync<import('./school-types').SchoolHoliday[]>(LOCAL_HOLIDAYS_KEY(schoolId), []);
    const updated = (Array.isArray(list) ? list : []).filter(h => h.id !== holidayId);
    setSchoolCacheSync(LOCAL_HOLIDAYS_KEY(schoolId), updated);
    markSchoolCacheFresh(LOCAL_HOLIDAYS_KEY(schoolId));
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("holidays-updated", { detail: { schoolId, holidayId } }));
    window.dispatchEvent(new CustomEvent("notices-updated", { detail: { schoolId } }));
  }

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/holidays/${holidayId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/holidays/${holidayId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "holidays");
};

export const subscribeToSchoolHolidays = (
  schoolId: string,
  cb: (holidays: import('./school-types').SchoolHoliday[]) => void
) => {
  if (!schoolId) return () => {};
  let active = true;
  const deliverLocal = () => {
    if (!active) return;
    const list = getSchoolCacheSync<any[]>(LOCAL_HOLIDAYS_KEY(schoolId), []);
    if (Array.isArray(list)) {
      cb([...list].sort((a: any, b: any) => (a.startDate || "").localeCompare(b.startDate || "")));
    }
  };

  void whenSchoolIdbReady().then(() => {
    if (!active) return;
    deliverLocal();
    getSchoolHolidays(schoolId)
      .then((list) => {
        if (active) cb(list);
      })
      .catch(() => {});
  });

  const onEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("holidays-updated", onEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("holidays-updated", onEvt);
    }
  };
};

// ── SCHOOL COMMUNITY FEED (PHOTOS, VIDEOS, HOLIDAYS, NOTICES, LIKES & COMMENTS) ──

export interface SchoolCommunityComment {
  id: string;
  userId: string;
  userName: string;
  userRole: "ADMIN" | "TEACHER" | "STUDENT" | string;
  text: string;
  createdAt: string;
}

export interface SchoolCommunityPost {
  id: string;
  schoolId: string;
  schoolName?: string;
  title?: string;
  text: string;
  category: "HOLIDAY" | "NOTICE" | "EVENT_MEDIA" | "HOMEWORK" | "GENERAL";
  imageUrl?: string;
  videoUrl?: string;
  holidayStartDate?: string;
  holidayEndDate?: string;
  classId?: string;
  className?: string;
  authorId: string;
  authorName: string;
  authorRole: "ADMIN" | "TEACHER" | "STUDENT" | string;
  isPinned?: boolean;
  commentsEnabled?: boolean;
  likes?: Record<string, boolean>;
  comments?: Record<string, SchoolCommunityComment>;
  createdAt: string;
}

const LOCAL_SCHOOL_COMMUNITY_KEY = (schoolId: string) => `nst_school_community_${schoolId}`;

export const saveSchoolCommunityPost = async (post: SchoolCommunityPost): Promise<void> => {
  if (!post?.schoolId || !post?.id) return;
  let finalImageUrl = post.imageUrl;
  if (finalImageUrl && finalImageUrl.startsWith("data:image/")) {
    finalImageUrl = await ensureCloudImageUrl(finalImageUrl, `comm_${post.schoolId}_${post.id}`);
  }
  const sanitized: SchoolCommunityPost = sanitizeForFirestore({
    ...post,
    imageUrl: finalImageUrl,
    commentsEnabled: post.commentsEnabled !== false,
    createdAt: post.createdAt || new Date().toISOString(),
  });

  try {
    const cur = getSchoolCacheSync<SchoolCommunityPost[]>(LOCAL_SCHOOL_COMMUNITY_KEY(post.schoolId), []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur : []).filter((p) => p.id !== post.id)].sort((a, b) =>
      (b.createdAt || "").localeCompare(a.createdAt || "")
    );
    setSchoolCacheSync(LOCAL_SCHOOL_COMMUNITY_KEY(post.schoolId), next);
    markSchoolCacheFresh(LOCAL_SCHOOL_COMMUNITY_KEY(post.schoolId));
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-community-updated", { detail: { schoolId: post.schoolId, post: sanitized } }));
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${post.schoolId}/community_posts/${post.id}`), sanitized), 2500);
    } catch {}
  }

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${post.schoolId}/community_posts/${post.id}`), sanitized), 3000);
    } catch {}
  }
  touchSchoolSyncVersion(post.schoolId, "community");
};

export const deleteSchoolCommunityPost = async (schoolId: string, postId: string): Promise<void> => {
  if (!schoolId || !postId) return;
  try {
    const cur = getSchoolCacheSync<SchoolCommunityPost[]>(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), []);
    if (Array.isArray(cur)) {
      setSchoolCacheSync(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), cur.filter((p) => p.id !== postId));
      markSchoolCacheFresh(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId));
    }
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-community-updated", { detail: { schoolId, deletedId: postId } }));
  }

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/community_posts/${postId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/community_posts/${postId}`)), 2500); } catch {}
  }
  touchSchoolSyncVersion(schoolId, "community");
};

export const toggleSchoolCommunityLike = async (
  schoolId: string,
  postId: string,
  userId: string,
  currentlyLiked: boolean
): Promise<void> => {
  if (!schoolId || !postId || !userId) return;
  const safeUid = String(userId).replace(/[.#$[\]/]/g, "_");

  try {
    const cur = getSchoolCacheSync<SchoolCommunityPost[]>(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), []);
    if (Array.isArray(cur) && cur.length > 0) {
      const next = cur.map((p) => {
        if (p.id !== postId) return p;
        const likes = { ...(p.likes || {}) };
        if (currentlyLiked) delete likes[safeUid];
        else likes[safeUid] = true;
        return { ...p, likes };
      });
      setSchoolCacheSync(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), next);
      markSchoolCacheFresh(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId));
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("school-community-updated", { detail: { schoolId } }));
      }
    }
  } catch {}

  if (rtdb) {
    try {
      const likeRef = ref(rtdb, `schools/${schoolId}/community_posts/${postId}/likes/${safeUid}`);
      if (currentlyLiked) await withTimeout(remove(likeRef), 2000);
      else await withTimeout(set(likeRef, true), 2000);
    } catch {}
  }

  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/community_posts/${postId}`)), 2000);
      if (snap.exists()) {
        const data = snap.data() as SchoolCommunityPost;
        const likes = { ...(data.likes || {}) };
        if (currentlyLiked) delete likes[safeUid];
        else likes[safeUid] = true;
        await withTimeout(updateDoc(d(`schools/${schoolId}/community_posts/${postId}`), { likes }), 2000);
      }
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "community");
};

export const addSchoolCommunityComment = async (
  schoolId: string,
  postId: string,
  comment: SchoolCommunityComment
): Promise<void> => {
  if (!schoolId || !postId || !comment?.id) return;
  const sanitized = sanitizeForFirestore(comment);

  try {
    const cur = getSchoolCacheSync<SchoolCommunityPost[]>(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), []);
    if (Array.isArray(cur) && cur.length > 0) {
      const next = cur.map((p) =>
        p.id === postId ? { ...p, comments: { ...(p.comments || {}), [comment.id]: sanitized } } : p
      );
      setSchoolCacheSync(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), next);
      markSchoolCacheFresh(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId));
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("school-community-updated", { detail: { schoolId } }));
      }
    }
  } catch {}

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/community_posts/${postId}/comments/${comment.id}`), sanitized), 2000);
    } catch {}
  }

  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/community_posts/${postId}`)), 2000);
      if (snap.exists()) {
        const data = snap.data() as SchoolCommunityPost;
        const comments = { ...(data.comments || {}), [comment.id]: sanitized };
        await withTimeout(updateDoc(d(`schools/${schoolId}/community_posts/${postId}`), { comments }), 2000);
      }
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "community");
};

export const deleteSchoolCommunityComment = async (
  schoolId: string,
  postId: string,
  commentId: string
): Promise<void> => {
  if (!schoolId || !postId || !commentId) return;
  try {
    const cur = getSchoolCacheSync<SchoolCommunityPost[]>(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), []);
    if (Array.isArray(cur) && cur.length > 0) {
      const next = cur.map((p) => {
        if (p.id !== postId) return p;
        const comments = { ...(p.comments || {}) };
        delete comments[commentId];
        return { ...p, comments };
      });
      setSchoolCacheSync(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId), next);
      markSchoolCacheFresh(LOCAL_SCHOOL_COMMUNITY_KEY(schoolId));
      if (typeof window !== "undefined") {
        window.dispatchEvent(new CustomEvent("school-community-updated", { detail: { schoolId } }));
      }
    }
  } catch {}

  if (rtdb) {
    try {
      await withTimeout(remove(ref(rtdb, `schools/${schoolId}/community_posts/${postId}/comments/${commentId}`)), 2000);
    } catch {}
  }
  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/community_posts/${postId}`)), 2000);
      if (snap.exists()) {
        const data = snap.data() as SchoolCommunityPost;
        const comments = { ...(data.comments || {}) };
        delete comments[commentId];
        await withTimeout(updateDoc(d(`schools/${schoolId}/community_posts/${postId}`), { comments }), 2000);
      }
    } catch {}
  }
  touchSchoolSyncVersion(schoolId, "community");
};

export const subscribeToSchoolCommunityPosts = (
  schoolId: string,
  cb: (posts: SchoolCommunityPost[]) => void
) => {
  if (!schoolId) return () => {};
  let active = true;
  const cacheKey = LOCAL_SCHOOL_COMMUNITY_KEY(schoolId);
  const sortPosts = (arr: SchoolCommunityPost[]) =>
    [...arr].sort((a, b) => {
      if (Boolean(a.isPinned) !== Boolean(b.isPinned)) return a.isPinned ? -1 : 1;
      return (b.createdAt || "").localeCompare(a.createdAt || "");
    });

  const deliverLocal = () => {
    if (!active) return;
    const parsed = getSchoolCacheSync<SchoolCommunityPost[]>(cacheKey, []);
    if (Array.isArray(parsed)) cb(sortPosts(parsed));
  };

  void whenSchoolIdbReady().then(async () => {
    if (!active) return;
    deliverLocal();
    const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
      schoolId,
      "community",
      cacheKey,
      () => {
        const list = getSchoolCacheSync<any[]>(cacheKey, []);
        return (Array.isArray(list) && list.length > 0) || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000);
      },
      5 * 60 * 1000
    );
    if (!fetch || !active) return;

    await dedupInflight(`getCommunityPosts_${schoolId}`, async () => {
      let fsOk = false;
      if (db) {
        try {
          const snap = await withTimeout(
            getDocs(query(col(`schools/${schoolId}/community_posts`), orderBy("createdAt", "desc"), limit(50))),
            2500
          );
          fsOk = true;
          const list = snap.docs.map((docSnap) => docSnap.data() as SchoolCommunityPost);
          setSchoolCacheSync(cacheKey, list);
          markSchoolCacheFresh(cacheKey, remoteVer);
        } catch {}
      }
      if (!fsOk && rtdb) {
        try {
          const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/community_posts`)), 2500);
          const val = snap?.val?.();
          if (val && typeof val === "object") {
            const arr = (Object.values(val) as SchoolCommunityPost[]).slice(0, 50);
            setSchoolCacheSync(cacheKey, arr);
            markSchoolCacheFresh(cacheKey, remoteVer);
          }
        } catch {}
      }
    });

    if (active) deliverLocal();
  });

  const onEvt = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) deliverLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("school-community-updated", onEvt);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("school-community-updated", onEvt);
    }
  };
};

export const updateClassFeeStructure = async (
  schoolId: string,
  classId: string,
  feeStructure: import('./school-types').ClassFeeStructure
): Promise<void> => {
  await updateClass(schoolId, classId, {
    feeStructure,
    defaultFee: feeStructure.tuitionFee || 0
  });
};

// ── MULTI-SCHOOL & MULTI-STUDENT PERMANENT USER ID BINDING ───────────────────

export const getStudentLinkKey = (st: { schoolId?: string; id?: string } | null | undefined, fallbackSchoolId = DEFAULT_SCHOOL_ID): string => {
  if (!st || !st.id) return "";
  return `${st.schoolId || fallbackSchoolId}__${st.id}`;
};

export const findStudentInSchoolRemote = async (
  schoolId: string,
  studentId?: string,
  admissionNo?: string
): Promise<import('./school-types').SchoolStudent | null> => {
  if (!schoolId) return null;
  if (rtdb && studentId) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/students/${studentId}`)), 2000);
      const val = snap?.val?.();
      if (val && val.id) return val as import('./school-types').SchoolStudent;
    } catch {}
  }
  if (db && studentId) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/students/${studentId}`)), 2500);
      if (snap.exists()) return snap.data() as import('./school-types').SchoolStudent;
    } catch {}
  }
  if (admissionNo && db) {
    try {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/students`)), 2500);
      const all = snap.docs.map((doc) => doc.data() as import('./school-types').SchoolStudent);
      const match = all.find(
        (s) => s.admissionNo && s.admissionNo.toLowerCase() === admissionNo.toLowerCase()
      );
      if (match) return match;
    } catch {}
  }
  return null;
};

export interface UserLinkedStudentsBundle {
  students: any[];
  activeStudentId?: string;
  activeStudentKey?: string;
  updatedAt: string;
}

const cleanRtdbUid = (uid: string) => String(uid || "guest").replace(/[.#$[\]/]/g, "_");

export const getLocalUserLinkedStudents = (uid: string): UserLinkedStudentsBundle | null => {
  if (!uid) return null;
  const cachedList = getSchoolCacheSync<UserLinkedStudentsBundle | null>(`nst_school_linked_list_${uid}`, null);
  if (cachedList && Array.isArray(cachedList.students)) {
    return cachedList;
  }
  const legacy = getSchoolCacheSync<any>(`nst_school_linked_${uid}`, null);
  if (legacy && legacy.type === "STUDENT" && legacy.id) {
    return {
      students: [legacy],
      activeStudentId: legacy.id,
      activeStudentKey: getStudentLinkKey(legacy),
      updatedAt: legacy.linkedAt || new Date().toISOString(),
    };
  }
  return null;
};

export const setLocalUserLinkedStudents = (
  uid: string,
  students: any[],
  activeStudentIdOrKey?: string
): void => {
  if (!uid) return;
  const cleanList = Array.isArray(students) ? students : [];
  const matchedActive =
    cleanList.find((s: any) => getStudentLinkKey(s) === activeStudentIdOrKey) ||
    cleanList.find((s: any) => s.id === activeStudentIdOrKey) ||
    cleanList[0] ||
    null;

  const bundle: UserLinkedStudentsBundle = {
    students: cleanList,
    activeStudentId: matchedActive?.id || "",
    activeStudentKey: matchedActive ? getStudentLinkKey(matchedActive) : "",
    updatedAt: new Date().toISOString(),
  };

  setSchoolCacheSync(`nst_school_linked_list_${uid}`, bundle);
  if (matchedActive) {
    setSchoolCacheSync(`nst_school_linked_${uid}`, matchedActive);
  } else {
    removeSchoolCacheSync(`nst_school_linked_${uid}`);
  }
};

export const getLocalLinkedTeacher = (uid: string): any | null => {
  if (!uid) return null;
  const saved = getSchoolCacheSync<any>(`nst_school_linked_${uid}`, null);
  if (saved && saved.type === "TEACHER") return saved;
  return null;
};

export const setLocalLinkedTeacher = (uid: string, teacherRecord: any | null): void => {
  if (!uid) return;
  if (teacherRecord) {
    setSchoolCacheSync(`nst_school_linked_${uid}`, teacherRecord);
  } else {
    removeSchoolCacheSync(`nst_school_linked_${uid}`);
  }
};

export const saveUserLinkedStudents = async (
  uid: string,
  students: any[],
  activeStudentIdOrKey?: string
): Promise<void> => {
  if (!uid) return;
  const cleanList = Array.isArray(students) ? students : [];
  const matchedActive =
    cleanList.find((s: any) => getStudentLinkKey(s) === activeStudentIdOrKey) ||
    cleanList.find((s: any) => s.id === activeStudentIdOrKey) ||
    cleanList[0] ||
    null;

  const bundle: UserLinkedStudentsBundle = sanitizeForFirestore({
    students: cleanList,
    activeStudentId: matchedActive?.id || "",
    activeStudentKey: matchedActive ? getStudentLinkKey(matchedActive) : "",
    updatedAt: new Date().toISOString(),
  });

  setSchoolCacheSync(`nst_school_linked_list_${uid}`, bundle);
  if (matchedActive) {
    setSchoolCacheSync(`nst_school_linked_${uid}`, matchedActive);
  } else {
    removeSchoolCacheSync(`nst_school_linked_${uid}`);
  }
  if (typeof window !== "undefined") {
    try {
      localStorage.setItem("nst_linked_students", JSON.stringify(cleanList));
      localStorage.setItem(
        `nst_user_linked_students_${uid}`,
        JSON.stringify({
          students: cleanList,
          activeStudentKey: bundle.activeStudentKey,
          activeStudentId: bundle.activeStudentId,
          updatedAt: bundle.updatedAt,
        })
      );
      if (matchedActive?.schoolId) {
        localStorage.setItem("nst_active_school_id", String(matchedActive.schoolId));
      }
    } catch {}
  }

  await ensureFirebaseAuthSession().catch(() => null);
  const safeUid = cleanRtdbUid(uid);

  await Promise.allSettled([
    sbRtdbSet(`school_user_links/${safeUid}`, bundle),
    rtdb ? withTimeout(set(ref(rtdb, `users/${safeUid}/linkedSchoolStudents`), bundle), 2500) : Promise.resolve(),
    rtdb ? withTimeout(set(ref(rtdb, `school_user_links/${safeUid}`), bundle), 2500) : Promise.resolve(),
    db ? withTimeout(setDoc(d(`school_user_links/${safeUid}`), bundle), 3000) : Promise.resolve(),
  ]);
};

export const getUserLinkedStudents = async (uid: string): Promise<UserLinkedStudentsBundle | null> => {
  if (!uid) return null;
  let localBundle = getLocalUserLinkedStudents(uid);
  if ((!localBundle || !localBundle.students?.length) && typeof window !== "undefined") {
    try {
      const lsRaw = localStorage.getItem(`nst_user_linked_students_${uid}`);
      if (lsRaw) {
        const parsed = JSON.parse(lsRaw);
        if (parsed && Array.isArray(parsed.students) && parsed.students.length > 0) {
          localBundle = {
            students: parsed.students,
            activeStudentId: parsed.activeStudentId || parsed.students[0]?.id || "",
            activeStudentKey: parsed.activeStudentKey || getStudentLinkKey(parsed.students[0]),
            updatedAt: parsed.updatedAt || new Date().toISOString(),
          };
        }
      }
    } catch {}
  }

  await ensureFirebaseAuthSession().catch(() => null);
  const safeUid = cleanRtdbUid(uid);

  const pickBest = (remote: UserLinkedStudentsBundle | null): UserLinkedStudentsBundle | null => {
    if (!remote || !Array.isArray(remote.students)) return null;
    if (remote.students.length > 0) {
      setSchoolCacheSync(`nst_school_linked_list_${uid}`, remote);
      return remote;
    }
    if (localBundle && Array.isArray(localBundle.students) && localBundle.students.length > 0) {
      const remoteTs = remote.updatedAt ? Date.parse(remote.updatedAt) : 0;
      const localTs = localBundle.updatedAt ? Date.parse(localBundle.updatedAt) : 0;
      if (localTs > remoteTs) {
        return localBundle;
      }
    }
    setSchoolCacheSync(`nst_school_linked_list_${uid}`, remote);
    removeSchoolCacheSync(`nst_school_linked_${uid}`);
    return remote;
  };

  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `school_user_links/${safeUid}`)), 2200);
      const res = pickBest(snap?.val?.());
      if (res) return res;
    } catch {}
  }

  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`school_user_links/${safeUid}`)), 2500);
      if (snap.exists()) {
        const res = pickBest(snap.data() as UserLinkedStudentsBundle);
        if (res) return res;
      }
    } catch {}
  }

  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `users/${safeUid}/linkedSchoolStudents`)), 2000);
      const res = pickBest(snap?.val?.());
      if (res) return res;
    } catch {}
  }

  try {
    const sbVal = await withTimeout(sbRtdbGet<UserLinkedStudentsBundle>(`school_user_links/${safeUid}`), 2000);
    const res = pickBest(sbVal);
    if (res) return res;
  } catch {}

  return localBundle;
};

/**
 * Verifies every linked student on an App User ID against each school's authoritative
 * cloud roster (Firestore + RTDB). If a school roster is reachable and confirms a student
 * was deleted or deactivated (missing from roster or active===false / isDeleted===true),
 * that stale student is automatically pruned. Offline/unreachable schools are preserved safely.
 */
export const verifyLinkedStudentsAuthoritative = async (
  students: any[],
  defaultSchoolId = DEFAULT_SCHOOL_ID
): Promise<{ validStudents: any[]; removedStudents: any[]; verifiedAnySchool: boolean }> => {
  const input = Array.isArray(students) ? students.filter(Boolean) : [];
  if (input.length === 0) {
    return { validStudents: [], removedStudents: [], verifiedAnySchool: false };
  }

  const schoolIds = Array.from(
    new Set(
      input
        .map((s: any) => String(s.schoolId || defaultSchoolId || "").trim())
        .filter(Boolean)
    )
  );

  const cloudCheckBySchool = new Map<
    string,
    {
      cloudVerified: boolean;
      hasRosterData: boolean;
      activeMap: Map<string, any>;
      deletedIdSet: Set<string>;
      rawMap: Map<string, any>;
    }
  >();

  await Promise.all(
    schoolIds.map(async (schId) => {
      try {
        const [{ cloudVerified, students: activeList, rawAllRecords }, deletedRtdbSet] = await Promise.all([
          getActiveCloudStudents(schId),
          (async () => {
            const setIds = new Set<string>();
            if (rtdb) {
              try {
                const delSnap = await withTimeout(get(ref(rtdb, `schools/${schId}/deleted_students`)), 2000);
                const val = delSnap?.val?.();
                if (val && typeof val === "object") {
                  Object.keys(val).forEach((k) => setIds.add(k));
                }
              } catch {}
            }
            return setIds;
          })(),
        ]);

        const activeMap = new Map<string, any>();
        activeList.forEach((st: any) => {
          if (st?.id) activeMap.set(st.id, st);
          if (st?.admissionNo) activeMap.set(`adm:${String(st.admissionNo).trim().toLowerCase()}`, st);
          if (st?.name && st?.rollNo) {
            activeMap.set(`rn:${String(st.rollNo).trim().toLowerCase()}__${String(st.name).trim().toLowerCase()}`, st);
          }
          const digits = String(st?.phone || "").replace(/\D/g, "").slice(-10);
          if (digits.length === 10 && st?.name) {
            activeMap.set(`ph:${digits}__${String(st.name).trim().toLowerCase()}`, st);
          }
        });

        const rawMap = new Map<string, any>();
        rawAllRecords.forEach((st: any) => {
          if (st?.id) rawMap.set(st.id, st);
          if (st?.admissionNo) rawMap.set(`adm:${String(st.admissionNo).trim().toLowerCase()}`, st);
          if (!isActiveSchoolStudentRecord(st) && st?.id) {
            deletedRtdbSet.add(st.id);
          }
        });

        cloudCheckBySchool.set(schId, {
          cloudVerified: cloudVerified || deletedRtdbSet.size > 0,
          hasRosterData: cloudVerified && activeList.length > 0,
          activeMap,
          deletedIdSet: deletedRtdbSet,
          rawMap,
        });
      } catch {
        cloudCheckBySchool.set(schId, {
          cloudVerified: false,
          hasRosterData: false,
          activeMap: new Map(),
          deletedIdSet: new Set(),
          rawMap: new Map(),
        });
      }
    })
  );

  const validStudents: any[] = [];
  const removedStudents: any[] = [];
  let verifiedAnySchool = false;

  for (const linked of input) {
    const schId = String(linked.schoolId || defaultSchoolId || "").trim();
    const check = cloudCheckBySchool.get(schId);

    // Keep demo students ONLY when demo mode is active for demo school and not explicitly deleted
    if (shouldUseDemoForSchool(schId) && isDemoRecord(linked)) {
      if (!check?.deletedIdSet.has(linked.id)) {
        validStudents.push(linked);
      } else {
        removedStudents.push(linked);
      }
      continue;
    }

    if (!check || !check.cloudVerified) {
      // Offline / cloud unreachable -> keep safely rather than wiping user's list blindly
      validStudents.push(linked);
      continue;
    }

    verifiedAnySchool = true;
    const admKey = linked.admissionNo ? `adm:${String(linked.admissionNo).trim().toLowerCase()}` : "";
    const rnKey =
      linked.name && linked.rollNo
        ? `rn:${String(linked.rollNo).trim().toLowerCase()}__${String(linked.name).trim().toLowerCase()}`
        : "";
    const phDigits = String(linked.phone || "").replace(/\D/g, "").slice(-10);
    const phKey = phDigits.length === 10 && linked.name ? `ph:${phDigits}__${String(linked.name).trim().toLowerCase()}` : "";

    // Explicit deleted tombstone or inactive raw record
    if ((linked.id && check.deletedIdSet.has(linked.id)) || (linked.id && check.rawMap.has(linked.id) && !isActiveSchoolStudentRecord(check.rawMap.get(linked.id)))) {
      removedStudents.push(linked);
      continue;
    }

    const activeMatch =
      (linked.id ? check.activeMap.get(linked.id) : undefined) ||
      (admKey ? check.activeMap.get(admKey) : undefined) ||
      (rnKey ? check.activeMap.get(rnKey) : undefined) ||
      (phKey ? check.activeMap.get(phKey) : undefined);

    if (activeMatch) {
      verifiedAnySchool = true;
      validStudents.push({
        ...linked,
        ...activeMatch,
        type: "STUDENT",
        schoolId: activeMatch.schoolId || schId,
        schoolName: linked.schoolName || activeMatch.schoolName || "",
      });
    } else if (!check.hasRosterData) {
      // Only tombstones existed or roster returned empty — keep linked student safely
      validStudents.push(linked);
    } else {
      verifiedAnySchool = true;
      // School's full cloud roster responded cleanly, and this student no longer exists in it!
      removedStudents.push(linked);
    }
  }

  return { validStudents, removedStudents, verifiedAnySchool };
};

// ── TEACHER REFERRAL 10% COMMISSION PAYOUTS & SETTINGS ───────────────────────

const LOCAL_REFERRAL_PAYOUTS_KEY = (schoolId: string) => `nst_school_ref_payouts_${schoolId}`;
const LOCAL_REFERRAL_SETTINGS_KEY = (schoolId: string) => `nst_school_ref_settings_${schoolId}`;

export const getDefaultReferralSettings = (schoolId: string): import('./school-types').SchoolReferralSettings => ({
  schoolId,
  defaultCommissionPct: 10,
  commissionScope: "all_fees",
  commissionDuration: "1_year",
  defaultSiblingDiscountPct: 10,
  updatedAt: new Date().toISOString(),
});

export const getSchoolReferralSettings = async (
  schoolId: string
): Promise<import('./school-types').SchoolReferralSettings> => {
  const fallback = getSchoolCacheSync<import('./school-types').SchoolReferralSettings | null>(
    LOCAL_REFERRAL_SETTINGS_KEY(schoolId),
    null
  );

  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/referral_settings`)), 2000);
      const val = snap?.val?.();
      if (val && typeof val === "object" && typeof val.defaultCommissionPct === "number") {
        const normalized = { commissionDuration: "1_year" as const, ...val };
        setSchoolCacheSync(LOCAL_REFERRAL_SETTINGS_KEY(schoolId), normalized);
        return normalized as import('./school-types').SchoolReferralSettings;
      }
    } catch {}
  }

  if (db) {
    try {
      const snap = await withTimeout(getDoc(d(`schools/${schoolId}/settings/referral_policy`)), 2500);
      if (snap.exists()) {
        const data = { commissionDuration: "1_year" as const, ...(snap.data() as import('./school-types').SchoolReferralSettings) };
        setSchoolCacheSync(LOCAL_REFERRAL_SETTINGS_KEY(schoolId), data);
        return data;
      }
    } catch {}
  }

  return fallback ? { commissionDuration: "1_year", ...fallback } : getDefaultReferralSettings(schoolId);
};

export const saveSchoolReferralSettings = async (
  schoolId: string,
  settings: Partial<import('./school-types').SchoolReferralSettings>
): Promise<import('./school-types').SchoolReferralSettings> => {
  const current = getSchoolCacheSync<import('./school-types').SchoolReferralSettings | null>(
    LOCAL_REFERRAL_SETTINGS_KEY(schoolId),
    null
  ) || getDefaultReferralSettings(schoolId);

  const merged: import('./school-types').SchoolReferralSettings = sanitizeForFirestore({
    ...current,
    ...settings,
    schoolId,
    defaultCommissionPct: Math.max(0, Math.min(100, Number(settings.defaultCommissionPct ?? current.defaultCommissionPct ?? 10))),
    defaultSiblingDiscountPct: Math.max(0, Math.min(100, Number(settings.defaultSiblingDiscountPct ?? current.defaultSiblingDiscountPct ?? 10))),
    commissionScope: settings.commissionScope || current.commissionScope || "all_fees",
    commissionDuration: settings.commissionDuration || current.commissionDuration || "1_year",
    updatedAt: new Date().toISOString(),
  });

  setSchoolCacheSync(LOCAL_REFERRAL_SETTINGS_KEY(schoolId), merged);

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/referral_settings`), merged), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/settings/referral_policy`), merged), 2500);
    } catch {}
  }
  return merged;
};

export const getReferralPayouts = async (
  schoolId: string
): Promise<import('./school-types').TeacherReferralPayout[]> => {
  const local = getSchoolCacheSync<import('./school-types').TeacherReferralPayout[]>(
    LOCAL_REFERRAL_PAYOUTS_KEY(schoolId),
    []
  );
  const map = new Map<string, import('./school-types').TeacherReferralPayout>();
  if (Array.isArray(local)) {
    local.forEach((p) => {
      if (p?.id) map.set(p.id, p);
    });
  }

  if (rtdb) {
    try {
      const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/referral_payouts`)), 2000);
      const val = snap?.val?.();
      if (val && typeof val === "object") {
        Object.values(val).forEach((p: any) => {
          if (p?.id) map.set(p.id, p as import('./school-types').TeacherReferralPayout);
        });
      }
    } catch {}
  }

  if (db) {
    try {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/referral_payouts`)), 2500);
      snap.docs.forEach((docSnap) => {
        const p = docSnap.data() as import('./school-types').TeacherReferralPayout;
        if (p?.id) map.set(p.id, p);
      });
    } catch {}
  }

  const merged = Array.from(map.values()).sort((a, b) =>
    (b.paidDate || b.createdAt || "").localeCompare(a.paidDate || a.createdAt || "")
  );
  setSchoolCacheSync(LOCAL_REFERRAL_PAYOUTS_KEY(schoolId), merged);
  return merged;
};

export const saveReferralPayout = async (
  payout: import('./school-types').TeacherReferralPayout
): Promise<void> => {
  const sanitized = sanitizeForFirestore(payout);
  const cur = getSchoolCacheSync<import('./school-types').TeacherReferralPayout[]>(
    LOCAL_REFERRAL_PAYOUTS_KEY(payout.schoolId),
    []
  );
  const updated = [sanitized, ...(Array.isArray(cur) ? cur.filter((p) => p.id !== payout.id) : [])];
  setSchoolCacheSync(LOCAL_REFERRAL_PAYOUTS_KEY(payout.schoolId), updated);

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${payout.schoolId}/referral_payouts/${payout.id}`), sanitized), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${payout.schoolId}/referral_payouts/${payout.id}`), sanitized), 2500);
    } catch {}
  }
};

export const deleteReferralPayout = async (schoolId: string, payoutId: string): Promise<void> => {
  const cur = getSchoolCacheSync<import('./school-types').TeacherReferralPayout[]>(
    LOCAL_REFERRAL_PAYOUTS_KEY(schoolId),
    []
  );
  if (Array.isArray(cur)) {
    setSchoolCacheSync(
      LOCAL_REFERRAL_PAYOUTS_KEY(schoolId),
      cur.filter((p) => p.id !== payoutId)
    );
  }
  if (rtdb) {
    try {
      await withTimeout(remove(ref(rtdb, `schools/${schoolId}/referral_payouts/${payoutId}`)), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/referral_payouts/${payoutId}`)), 2500);
    } catch {}
  }
};

// ── DAILY CLASSROOM VIDEO LECTURES ──────────────────────────────────────────

export const extractYouTubeVideoId = (url: string): string => {
  if (!url) return "";
  const clean = url.trim();
  const match = clean.match(/(?:youtu\.be\/|youtube\.com\/(?:embed\/|v\/|watch\?v=|watch\?.+&v=|shorts\/))([\w-]{11})/);
  if (match && match[1]) return match[1];
  if (/^[\w-]{11}$/.test(clean)) return clean;
  return "";
};

export const saveClassLecture = async (lecture: DailyClassLecture): Promise<void> => {
  const sanitized = sanitizeForFirestore(lecture);
  try {
    const key = `nst_school_lectures_${lecture.schoolId}`;
    const cur = getSchoolCacheSync<DailyClassLecture[]>(key, []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur.filter(l => l.id !== lecture.id) : [])];
    setSchoolCacheSync(key, next);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("lectures-updated", { detail: { schoolId: lecture.schoolId, classId: lecture.classId, date: lecture.date } })
    );
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${lecture.schoolId}/lectures/${lecture.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${lecture.schoolId}/lectures/${lecture.id}`), sanitized), 2500); } catch {}
  }
};

export const getClassLectures = async (schoolId: string, classId?: string, date?: string): Promise<DailyClassLecture[]> => {
  const useDemo = shouldUseDemoForSchool(schoolId);
  let local = getSchoolCacheSync<DailyClassLecture[]>(`nst_school_lectures_${schoolId}`, []);
  if (!Array.isArray(local)) local = [];

  if (useDemo) {
    const demo = getDemoSchoolDataset(true);
    if (demo && demo.videoLectures && demo.videoLectures.length > 0) {
      // Merge demo lectures with local edits
      const mergedDemo = [...local, ...demo.videoLectures.filter(dl => !local.some(l => l.id === dl.id))];
      local = mergedDemo;
    }
  }

  if (db) {
    try {
      const snap = await withTimeout(getDocs(col(`schools/${schoolId}/lectures`)), 2500);
      const remote = snap.docs.map(docSnap => docSnap.data() as DailyClassLecture);
      if (remote.length > 0) {
        const merged = [...remote, ...local.filter(l => !remote.some(r => r.id === l.id))];
        local = merged;
        setSchoolCacheSync(`nst_school_lectures_${schoolId}`, merged);
      }
    } catch {}
  }

  let filtered = local;
  if (classId) {
    const cleanCid = classId.toLowerCase().replace(/[^a-z0-9]/g, "");
    const classFiltered = filtered.filter(l => {
      if (l.isUniversal === true || l.classId === "all" || l.classId === "universal") return true;
      if (l.classId === classId || l.className === classId) return true;
      const cleanLCid = (l.classId || "").toLowerCase().replace(/[^a-z0-9]/g, "");
      const cleanLName = (l.className || "").toLowerCase().replace(/[^a-z0-9]/g, "");
      return cleanLCid === cleanCid ||
             cleanLName === cleanCid ||
             cleanLCid.includes(cleanCid) ||
             cleanCid.includes(cleanLCid) ||
             cleanLName.includes(cleanCid) ||
             cleanCid.includes(cleanLName);
    });
    if (classFiltered.length > 0) {
      filtered = classFiltered;
    }
  }

  if (date) {
    const dateFiltered = filtered.filter(l => l.date === date);
    if (dateFiltered.length > 0) {
      filtered = dateFiltered;
    }
  }
  return filtered.sort((a, b) => (b.date || "").localeCompare(a.date || "") || (a.periodNumber - b.periodNumber));
};

export const deleteClassLecture = async (schoolId: string, lectureId: string): Promise<void> => {
  try {
    const key = `nst_school_lectures_${schoolId}`;
    const cur = getSchoolCacheSync<DailyClassLecture[]>(key, []);
    if (Array.isArray(cur)) {
      setSchoolCacheSync(key, cur.filter(l => l.id !== lectureId));
    }
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("lectures-updated", { detail: { schoolId, lectureId } }));
  }

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/lectures/${lectureId}`)), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(deleteDoc(d(`schools/${schoolId}/lectures/${lectureId}`)), 2500); } catch {}
  }
};

// ── NSTA MESSENGER SUITE API ──
export const getCanonicalStudentPairKey = (id1?: string, id2?: string): string => {
  const a = String(id1 || "").trim();
  const b = String(id2 || "").trim();
  if (!a || !b) return a || b || "pair";
  return a.localeCompare(b) <= 0 ? `${a}__${b}` : `${b}__${a}`;
};

export const getNstaThreadKey = (
  threadType: NstaThreadType,
  classId?: string,
  studentId?: string,
  teacherId?: string
): string => {
  if (threadType === "CLASS_GROUP") return `class_${classId || "general"}`;
  if (threadType === "SCHOOL_DESK") return `school_${studentId || "all"}`;
  if (threadType === "TEACHER_CHAT") return `teacher_${studentId || "std"}_${teacherId || "tch"}`;
  if (threadType === "STUDENT_CHAT") return `friend_${studentId || "pair"}`;
  return "general";
};

export const saveNstaMessage = async (msg: NstaMessage): Promise<void> => {
  const sanitized = sanitizeForFirestore(msg);
  const cacheKey = `nst_school_nsta_msgs_${msg.schoolId}`;

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const updated = [sanitized, ...(Array.isArray(cur) ? cur.filter(m => m.id !== msg.id) : [])];
    setSchoolCacheSync(cacheKey, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("nsta-messages-updated", { detail: { schoolId: msg.schoolId, message: msg } }));
  }

  const writes: Promise<void>[] = [];
  if (rtdb) {
    writes.push(
      withTimeout(set(ref(rtdb, `schools/${msg.schoolId}/nsta_messages/${msg.id}`), sanitized), 8000).catch(() => {})
    );
  }
  if (db) {
    writes.push(
      withTimeout(setDoc(d(`schools/${msg.schoolId}/nsta_messages/${msg.id}`), sanitized), 8000).catch(() => {})
    );
  }
  await Promise.allSettled(writes);
};

export const NSTA_MESSAGE_RETENTION_DAYS = 7;
export const NSTA_MESSAGE_RETENTION_MS = NSTA_MESSAGE_RETENTION_DAYS * 24 * 60 * 60 * 1000;

export const isNstaMessageExpired = (msg: Partial<NstaMessage> | null | undefined, nowMs = Date.now()): boolean => {
  if (!msg || !msg.createdAt) return false;
  const ts = Date.parse(msg.createdAt);
  if (Number.isNaN(ts)) return false;
  return nowMs - ts > NSTA_MESSAGE_RETENTION_MS;
};

const nstaPurgeCooldown = new Map<string, number>();

export const deleteNstaMessage = async (schoolId: string, messageId: string): Promise<void> => {
  await bulkPermanentDeleteNstaMessages(schoolId, [messageId]);
};

export const bulkPermanentDeleteNstaMessages = async (
  schoolId: string,
  messageIds: string[]
): Promise<number> => {
  if (!schoolId || !Array.isArray(messageIds) || messageIds.length === 0) return 0;
  const uniqueIds = Array.from(new Set(messageIds.filter(Boolean)));
  if (uniqueIds.length === 0) return 0;

  const idSet = new Set<string>(uniqueIds);
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const updated = Array.isArray(cur) ? cur.filter((m) => m && !idSet.has(m.id)) : [];
    setSchoolCacheSync(cacheKey, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-messages-updated", {
        detail: { schoolId, messageIds: uniqueIds, action: "BULK_DELETE_PERMANENT" },
      })
    );
  }

  // RTDB chunked multi-path deletes (null removes nodes in one request per 200 keys)
  if (rtdb) {
    const CHUNK = 200;
    for (let i = 0; i < uniqueIds.length; i += CHUNK) {
      const slice = uniqueIds.slice(i, i + CHUNK);
      const patch: Record<string, null> = {};
      slice.forEach((id) => {
        patch[id] = null;
      });
      try {
        await withTimeout(update(ref(rtdb, `schools/${schoolId}/nsta_messages`), patch), 6000);
      } catch {}
    }
  }

  // Firestore chunked writeBatch deletes (max 500 ops/batch; use 400 safely)
  if (db) {
    const CHUNK = 400;
    for (let i = 0; i < uniqueIds.length; i += CHUNK) {
      const slice = uniqueIds.slice(i, i + CHUNK);
      try {
        const batch = writeBatch(db);
        slice.forEach((id) => {
          batch.delete(d(`schools/${schoolId}/nsta_messages/${id}`));
        });
        await withTimeout(batch.commit(), 8000);
      } catch {}
    }
  }

  return uniqueIds.length;
};

export const deleteNstaMessageForMe = async (
  schoolId: string,
  messageId: string,
  userId: string
): Promise<void> => {
  await bulkDeleteNstaMessagesForMe(schoolId, [messageId], userId);
};

export const bulkDeleteNstaMessagesForMe = async (
  schoolId: string,
  messageIds: string[],
  userId: string
): Promise<number> => {
  if (!schoolId || !userId || !Array.isArray(messageIds) || messageIds.length === 0) return 0;
  const uniqueIds = Array.from(new Set(messageIds.filter(Boolean)));
  if (uniqueIds.length === 0) return 0;

  const idSet = new Set<string>(uniqueIds);
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  const modifiedMsgs: NstaMessage[] = [];

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const updated = (Array.isArray(cur) ? cur : []).map((m) => {
      if (m && idSet.has(m.id)) {
        const deletedFor = Array.isArray(m.deletedFor) ? [...m.deletedFor] : [];
        if (!deletedFor.includes(userId)) deletedFor.push(userId);
        const nextMsg = { ...m, deletedFor };
        modifiedMsgs.push(nextMsg);
        return nextMsg;
      }
      return m;
    });
    setSchoolCacheSync(cacheKey, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-messages-updated", {
        detail: { schoolId, messageIds: uniqueIds, action: "BULK_DELETE_FOR_ME", userId },
      })
    );
  }

  if (modifiedMsgs.length > 0) {
    if (rtdb) {
      const CHUNK = 200;
      for (let i = 0; i < modifiedMsgs.length; i += CHUNK) {
        const slice = modifiedMsgs.slice(i, i + CHUNK);
        const patch: Record<string, any> = {};
        slice.forEach((m) => {
          patch[`${m.id}/deletedFor`] = m.deletedFor || [userId];
        });
        try {
          await withTimeout(update(ref(rtdb, `schools/${schoolId}/nsta_messages`), patch), 6000);
        } catch {}
      }
    }
    if (db) {
      const CHUNK = 400;
      for (let i = 0; i < modifiedMsgs.length; i += CHUNK) {
        const slice = modifiedMsgs.slice(i, i + CHUNK);
        try {
          const batch = writeBatch(db);
          slice.forEach((m) => {
            batch.set(
              d(`schools/${schoolId}/nsta_messages/${m.id}`),
              { deletedFor: m.deletedFor || [userId] },
              { merge: true }
            );
          });
          await withTimeout(batch.commit(), 8000);
        } catch {}
      }
    }
  }

  return modifiedMsgs.length;
};

export const deleteNstaMessageForEveryone = async (
  schoolId: string,
  messageId: string
): Promise<void> => {
  await bulkDeleteNstaMessagesForEveryone(schoolId, [messageId]);
};

export const bulkDeleteNstaMessagesForEveryone = async (
  schoolId: string,
  messageIds: string[],
  options?: { permanentOnBulk?: boolean }
): Promise<number> => {
  if (!schoolId || !Array.isArray(messageIds) || messageIds.length === 0) return 0;
  const uniqueIds = Array.from(new Set(messageIds.filter(Boolean)));
  if (uniqueIds.length === 0) return 0;

  // For bulk deletions (> 5 messages) or explicit permanent mode, delete completely so 1000+ deleted bubbles vanish cleanly
  if (options?.permanentOnBulk !== false && uniqueIds.length > 5) {
    return bulkPermanentDeleteNstaMessages(schoolId, uniqueIds);
  }

  const idSet = new Set<string>(uniqueIds);
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  const nowIso = new Date().toISOString();
  const modifiedMsgs: NstaMessage[] = [];

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const updated = (Array.isArray(cur) ? cur : []).map((m) => {
      if (m && idSet.has(m.id)) {
        const nextMsg: NstaMessage = {
          ...m,
          text: "🚫 This message was deleted",
          deletedForEveryone: true,
          deletedForEveryoneAt: nowIso,
          attachmentUrl: undefined,
          attachmentType: undefined,
          feeSlip: undefined,
        };
        modifiedMsgs.push(nextMsg);
        return nextMsg;
      }
      return m;
    });
    setSchoolCacheSync(cacheKey, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-messages-updated", {
        detail: { schoolId, messageIds: uniqueIds, action: "BULK_DELETE_FOR_EVERYONE" },
      })
    );
  }

  if (modifiedMsgs.length > 0) {
    if (rtdb) {
      const CHUNK = 200;
      for (let i = 0; i < modifiedMsgs.length; i += CHUNK) {
        const slice = modifiedMsgs.slice(i, i + CHUNK);
        const patch: Record<string, any> = {};
        slice.forEach((m) => {
          patch[m.id] = sanitizeForFirestore(m);
        });
        try {
          await withTimeout(update(ref(rtdb, `schools/${schoolId}/nsta_messages`), patch), 6000);
        } catch {}
      }
    }
    if (db) {
      const CHUNK = 400;
      for (let i = 0; i < modifiedMsgs.length; i += CHUNK) {
        const slice = modifiedMsgs.slice(i, i + CHUNK);
        try {
          const batch = writeBatch(db);
          slice.forEach((m) => {
            batch.set(d(`schools/${schoolId}/nsta_messages/${m.id}`), sanitizeForFirestore(m));
          });
          await withTimeout(batch.commit(), 8000);
        } catch {}
      }
    }
  }

  return modifiedMsgs.length;
};

export const toggleNstaMessageReaction = async (
  schoolId: string,
  messageId: string,
  emoji: string,
  userId: string
): Promise<void> => {
  if (!schoolId || !messageId || !emoji || !userId) return;
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  let updatedMsg: NstaMessage | null = null;

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const updated = (Array.isArray(cur) ? cur : []).map((m) => {
      if (m.id === messageId) {
        const reactions: Record<string, string[]> = { ...(m.reactions || {}) };
        const userCurrentReaction = Object.entries(reactions).find(([_, users]) =>
          Array.isArray(users) && users.includes(userId)
        )?.[0];

        // Remove user from any existing reactions
        Object.keys(reactions).forEach((k) => {
          if (Array.isArray(reactions[k])) {
            reactions[k] = reactions[k].filter((uid) => uid !== userId);
            if (reactions[k].length === 0) delete reactions[k];
          }
        });

        // If clicking a different emoji, add it
        if (userCurrentReaction !== emoji) {
          if (!reactions[emoji]) reactions[emoji] = [];
          reactions[emoji].push(userId);
        }

        updatedMsg = { ...m, reactions };
        return updatedMsg;
      }
      return m;
    });
    setSchoolCacheSync(cacheKey, updated);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-messages-updated", {
        detail: { schoolId, messageId, action: "REACTION" }
      })
    );
  }

  if (updatedMsg) {
    const sanitized = sanitizeForFirestore(updatedMsg);
    if (rtdb) {
      try {
        await withTimeout(set(ref(rtdb, `schools/${schoolId}/nsta_messages/${messageId}`), sanitized), 2000);
      } catch {}
    }
    if (db) {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/nsta_messages/${messageId}`), sanitized), 2500);
      } catch {}
    }
  }
};

export const markNstaMessagesDeliveredOrRead = async (
  schoolId: string,
  messageIds: string[],
  user: { userId: string; userName: string; role?: string },
  markAs: "delivered" | "read"
): Promise<void> => {
  if (!schoolId || !Array.isArray(messageIds) || messageIds.length === 0 || !user.userId) return;
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  const nowIso = new Date().toISOString();
  const modifiedMsgs: NstaMessage[] = [];

  try {
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    if (!Array.isArray(cur) || cur.length === 0) return;

    let hasChanges = false;
    const updated = cur.map((m) => {
      if (!messageIds.includes(m.id)) return m;
      // Do not mark own messages as read by self
      if (m.senderId === user.userId) return m;

      let changed = false;
      const deliveredTo = Array.isArray(m.deliveredTo) ? [...m.deliveredTo] : [];
      const readBy = Array.isArray(m.readBy) ? [...m.readBy] : [];

      // Add to deliveredTo if not already there
      if (!deliveredTo.some((d) => d.userId === user.userId)) {
        deliveredTo.push({
          userId: user.userId,
          userName: user.userName,
          deliveredAt: nowIso,
          role: user.role
        });
        changed = true;
      }

      let newStatus = m.status || "sent";
      if (newStatus === "sent") {
        newStatus = "delivered";
        changed = true;
      }

      if (markAs === "read") {
        if (!readBy.some((r) => r.userId === user.userId)) {
          readBy.push({
            userId: user.userId,
            userName: user.userName,
            readAt: nowIso,
            role: user.role
          });
          changed = true;
        }
        newStatus = "read";
      }

      if (changed) {
        hasChanges = true;
        const up = { ...m, status: newStatus, deliveredTo, readBy };
        modifiedMsgs.push(up);
        return up;
      }
      return m;
    });

    if (hasChanges) {
      setSchoolCacheSync(cacheKey, updated);
      if (typeof window !== "undefined") {
        window.dispatchEvent(
          new CustomEvent("nsta-messages-updated", {
            detail: { schoolId, action: markAs === "read" ? "READ" : "DELIVERED" }
          })
        );
      }
    }
  } catch {}

  // Sync back modified messages
  if (modifiedMsgs.length > 0) {
    for (const msg of modifiedMsgs.slice(0, 5)) {
      const sanitized = sanitizeForFirestore(msg);
      if (rtdb) {
        try {
          void set(ref(rtdb, `schools/${schoolId}/nsta_messages/${msg.id}`), sanitized);
        } catch {}
      }
      if (db) {
        try {
          void setDoc(d(`schools/${schoolId}/nsta_messages/${msg.id}`), sanitized);
        } catch {}
      }
    }
  }
};

export const subscribeToNstaMessages = (
  schoolId: string,
  filter: { threadType: NstaThreadType; classId?: string; className?: string; studentId?: string; teacherId?: string },
  cb: (msgs: NstaMessage[]) => void
): () => void => {
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  let disposed = false;

  const loadFromCacheAndNotify = () => {
    if (disposed) return;
    const raw = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    if (Array.isArray(raw)) {
      const nowMs = Date.now();
      const expiredIds: string[] = [];
      const activeAll = raw.filter((m) => {
        if (!m) return false;
        if (isNstaMessageExpired(m, nowMs)) {
          if (m.id) expiredIds.push(m.id);
          return false;
        }
        return true;
      });
      if (expiredIds.length > 0) {
        setSchoolCacheSync(cacheKey, activeAll);
      }

      const filtered = activeAll.filter(m => {
        if (!m || !m.threadType) return false;
        if (m.threadType !== filter.threadType) return false;

        if (filter.threadType === "CLASS_GROUP") {
          if (filter.classId && m.classId && m.classId !== filter.classId && m.classId !== "all" && m.classId !== "general") {
            const matched = isStudentInClass(
              { classId: filter.classId, className: filter.className } as any,
              m.classId,
              m.className
            );
            if (!matched) return false;
          }
        }

        if (filter.threadType === "SCHOOL_DESK") {
          if (filter.studentId && m.studentId && m.studentId !== filter.studentId && m.studentId !== "all" && m.studentId !== "general") {
            return false;
          }
        }

        if (filter.threadType === "TEACHER_CHAT") {
          if (filter.studentId && m.studentId && m.studentId !== filter.studentId) return false;
          if (filter.teacherId && m.teacherId && m.teacherId !== filter.teacherId) return false;
        }

        if (filter.threadType === "STUDENT_CHAT") {
          if (filter.studentId && m.studentId && m.studentId !== filter.studentId) return false;
        }

        return true;
      });
      cb(filtered.sort((a, b) => (a.createdAt || "").localeCompare(b.createdAt || "")));
    }
  };

  loadFromCacheAndNotify();
  whenSchoolIdbReady().then(() => { if (!disposed) loadFromCacheAndNotify(); }).catch(() => {});

  const handleCustomEvent = (e: any) => {
    if (e.detail?.schoolId === schoolId) {
      loadFromCacheAndNotify();
    }
  };
  if (typeof window !== "undefined") {
    window.addEventListener("nsta-messages-updated", handleCustomEvent);
    window.addEventListener("school-idb-hydrated", loadFromCacheAndNotify);
  }

  let fsList: NstaMessage[] | null = null;

  const mergeAndEmit = () => {
    if (disposed) return;
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const mergedMap = new Map<string, NstaMessage>();
    const expiredIds: string[] = [];
    const nowMs = Date.now();

    const cutoff = nowMs - 120_000;
    if (Array.isArray(cur)) {
      for (const m of cur) {
        if (m?.id && m.createdAt && new Date(m.createdAt).getTime() >= cutoff) {
          mergedMap.set(m.id, m);
        }
      }
    }
    if (Array.isArray(fsList)) {
      for (const m of fsList) {
        if (!m?.id) continue;
        if (isNstaMessageExpired(m, nowMs)) {
          expiredIds.push(m.id);
        } else {
          mergedMap.set(m.id, m);
        }
      }
    }
    setSchoolCacheSync(cacheKey, Array.from(mergedMap.values()));
    loadFromCacheAndNotify();

    // Auto-purge expired (>7 days) messages at most once every 24 hours per school (localStorage persisted)
    if (expiredIds.length > 0) {
      const lsKey = `nst_nsta_msg_purge_${schoolId}`;
      let lastPurge = nstaPurgeCooldown.get(schoolId) || 0;
      try {
        const stored = Number(localStorage.getItem(lsKey) || 0);
        if (stored > lastPurge) lastPurge = stored;
      } catch {}
      if (nowMs - lastPurge > 24 * 60 * 60 * 1000) {
        nstaPurgeCooldown.set(schoolId, nowMs);
        try { localStorage.setItem(lsKey, String(nowMs)); } catch {}
        void bulkPermanentDeleteNstaMessages(schoolId, expiredIds);
      }
    }
  };

  // Bounded Firestore listener (latest 120 messages only — eliminates RTDB double download & unbounded reads)
  let unsubFirestore = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/nsta_messages`), orderBy("createdAt", "desc"), limit(120));
      unsubFirestore = onSnapshot(qFs, (snap) => {
        fsList = snap.docs.map(docSnap => docSnap.data() as NstaMessage);
        mergeAndEmit();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (typeof window !== "undefined") {
      window.removeEventListener("nsta-messages-updated", handleCustomEvent);
      window.removeEventListener("school-idb-hydrated", loadFromCacheAndNotify);
    }
    unsubFirestore();
  };
};

// Subscribe to ALL active school NSTA messages (used for Unified WhatsApp-style Home Chat List)
export const subscribeToAllSchoolNstaMessages = (
  schoolId: string,
  cb: (msgs: NstaMessage[]) => void
): () => void => {
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  let lastSig = "";
  let disposed = false;

  const notifyIfChanged = (sortedActive: NstaMessage[]) => {
    if (disposed) return;
    const last = sortedActive.length > 0 ? sortedActive[sortedActive.length - 1] : null;
    let statusSum = 0;
    for (let i = 0; i < sortedActive.length; i++) {
      const m = sortedActive[i];
      if (m.readBy?.length) statusSum += m.readBy.length;
      if (m.deletedFor?.length) statusSum += m.deletedFor.length * 7;
      if (m.deletedForEveryone) statusSum += 13;
    }
    const sig = `${sortedActive.length}|${last?.id || ""}|${last?.createdAt || ""}|${statusSum}`;
    if (sig === lastSig) return;
    lastSig = sig;
    cb(sortedActive);
  };

  const emitActive = () => {
    if (disposed) return;
    const raw = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    if (!Array.isArray(raw)) {
      notifyIfChanged([]);
      return;
    }
    const nowMs = Date.now();
    const activeAll = raw
      .filter((m) => m && m.threadType && !isNstaMessageExpired(m, nowMs))
      .sort((a, b) => (a.createdAt || "").localeCompare(b.createdAt || ""));
    notifyIfChanged(activeAll);
  };

  emitActive();
  whenSchoolIdbReady().then(() => { if (!disposed) emitActive(); }).catch(() => {});

  const handleCustomEvent = (e: any) => {
    if (e.detail?.schoolId === schoolId) emitActive();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("nsta-messages-updated", handleCustomEvent);
    window.addEventListener("school-idb-hydrated", emitActive);
  }

  let fsList: NstaMessage[] | null = null;
  let mergeTimer: ReturnType<typeof setTimeout> | null = null;

  const runMergeAndEmit = () => {
    mergeTimer = null;
    if (disposed) return;
    const cur = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
    const mergedMap = new Map<string, NstaMessage>();
    const expiredIds: string[] = [];
    const nowMs = Date.now();
    const cutoff = nowMs - 120_000;
    if (Array.isArray(cur)) {
      for (const m of cur) {
        if (m?.id && m.createdAt && new Date(m.createdAt).getTime() >= cutoff) {
          mergedMap.set(m.id, m);
        }
      }
    }
    if (Array.isArray(fsList)) {
      for (const m of fsList) {
        if (!m?.id) continue;
        if (isNstaMessageExpired(m, nowMs)) expiredIds.push(m.id);
        else mergedMap.set(m.id, m);
      }
    }
    const mergedArr = Array.from(mergedMap.values());
    setSchoolCacheSync(cacheKey, mergedArr);
    const activeSorted = mergedArr
      .filter((m) => m && m.threadType && !isNstaMessageExpired(m, nowMs))
      .sort((a, b) => (a.createdAt || "").localeCompare(b.createdAt || ""));
    notifyIfChanged(activeSorted);

    if (expiredIds.length > 0) {
      const lsKey = `nst_nsta_msg_purge_${schoolId}`;
      let lastPurge = nstaPurgeCooldown.get(schoolId) || 0;
      try {
        const stored = Number(localStorage.getItem(lsKey) || 0);
        if (stored > lastPurge) lastPurge = stored;
      } catch {}
      if (nowMs - lastPurge > 24 * 60 * 60 * 1000) {
        nstaPurgeCooldown.set(schoolId, nowMs);
        try { localStorage.setItem(lsKey, String(nowMs)); } catch {}
        void bulkPermanentDeleteNstaMessages(schoolId, expiredIds);
      }
    }
  };

  const scheduleMerge = () => {
    if (mergeTimer) return;
    mergeTimer = setTimeout(runMergeAndEmit, 40);
  };

  let unsubFirestore = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/nsta_messages`), orderBy("createdAt", "desc"), limit(150));
      unsubFirestore = onSnapshot(qFs, (snap) => {
        fsList = snap.docs.map((docSnap) => docSnap.data() as NstaMessage);
        scheduleMerge();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (mergeTimer) {
      clearTimeout(mergeTimer);
      mergeTimer = null;
    }
    if (typeof window !== "undefined") {
      window.removeEventListener("nsta-messages-updated", handleCustomEvent);
      window.removeEventListener("school-idb-hydrated", emitActive);
    }
    unsubFirestore();
  };
};

// ── NSTA 24-HOUR SCHOOL STATUS & EVENT VIDEO AUTO-ARCHIVE ENGINE ──
export const NSTA_STATUS_TTL_MS = 24 * 60 * 60 * 1000; // Strictly 24 hours

export const isNstaStatusExpired = (st: Partial<NstaSchoolStatus> | null | undefined, nowMs = Date.now()): boolean => {
  if (!st) return false;
  if (st.expiresAt) {
    const exp = Date.parse(st.expiresAt);
    if (!Number.isNaN(exp)) return nowMs >= exp;
  }
  if (st.createdAt) {
    const cr = Date.parse(st.createdAt);
    if (!Number.isNaN(cr)) return nowMs - cr >= NSTA_STATUS_TTL_MS;
  }
  return false;
};

const safeViewerKey = (rawId: string): string =>
  String(rawId || "anon").replace(/[.#$/[\]\s]/g, "_");

export const saveNstaStatus = async (status: NstaSchoolStatus): Promise<void> => {
  const nowIso = status.createdAt || new Date().toISOString();
  const expiresIso =
    status.expiresAt || new Date(Date.parse(nowIso) + NSTA_STATUS_TTL_MS).toISOString();
  const fullStatus: NstaSchoolStatus = {
    ...status,
    createdAt: nowIso,
    expiresAt: expiresIso,
    viewers: status.viewers || {},
  };
  const sanitized = sanitizeForFirestore(fullStatus);
  const cacheKey = `nst_school_nsta_statuses_${status.schoolId}`;

  try {
    const cur = getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
    const next = [sanitized, ...(Array.isArray(cur) ? cur.filter((s) => s.id !== status.id) : [])];
    setSchoolCacheSync(cacheKey, next);
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-statuses-updated", { detail: { schoolId: status.schoolId, status: sanitized } })
    );
  }

  const writes: Promise<void>[] = [];
  if (rtdb) {
    writes.push(
      withTimeout(set(ref(rtdb, `schools/${status.schoolId}/nsta_statuses/${status.id}`), sanitized), 2500).catch(() => {})
    );
  }
  if (db) {
    writes.push(
      withTimeout(setDoc(d(`schools/${status.schoolId}/nsta_statuses/${status.id}`), sanitized), 2500).catch(() => {})
    );
  }
  await Promise.allSettled(writes);
};

export const deleteNstaStatus = async (schoolId: string, statusId: string): Promise<void> => {
  const cacheKey = `nst_school_nsta_statuses_${schoolId}`;
  try {
    const cur = getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
    if (Array.isArray(cur)) {
      setSchoolCacheSync(cacheKey, cur.filter((s) => s.id !== statusId));
    }
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nsta-statuses-updated", { detail: { schoolId, statusId, action: "DELETE" } })
    );
  }

  const ops: Promise<void>[] = [];
  if (rtdb) {
    ops.push(withTimeout(remove(ref(rtdb, `schools/${schoolId}/nsta_statuses/${statusId}`)), 2500).catch(() => {}));
  }
  if (db) {
    ops.push(withTimeout(deleteDoc(d(`schools/${schoolId}/nsta_statuses/${statusId}`)), 2500).catch(() => {}));
  }
  await Promise.allSettled(ops);
};

export const markNstaStatusViewed = async (
  schoolId: string,
  statusId: string,
  viewer: NstaStatusViewer
): Promise<void> => {
  if (!schoolId || !statusId || !viewer?.viewerId) return;
  const vKey = safeViewerKey(viewer.viewerId);
  const cacheKey = `nst_school_nsta_statuses_${schoolId}`;
  let recordToSave: NstaStatusViewer = {
    ...viewer,
    viewedAt: viewer.viewedAt || new Date().toISOString(),
  };

  try {
    const cur = getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
    if (Array.isArray(cur)) {
      let changed = false;
      const updated = cur.map((st) => {
        if (!st || st.id !== statusId) return st;
        const viewers = { ...(st.viewers || {}) };
        if (viewers[vKey]) {
          // Preserve first viewed timestamp
          recordToSave = viewers[vKey];
          return st;
        }
        viewers[vKey] = recordToSave;
        changed = true;
        return { ...st, viewers };
      });
      if (changed) {
        setSchoolCacheSync(cacheKey, updated);
        if (typeof window !== "undefined") {
          window.dispatchEvent(
            new CustomEvent("nsta-statuses-updated", { detail: { schoolId, statusId, action: "VIEWED" } })
          );
        }
      }
    }
  } catch {}

  const sanitizedViewer = sanitizeForFirestore(recordToSave);
  if (rtdb) {
    try {
      void set(ref(rtdb, `schools/${schoolId}/nsta_statuses/${statusId}/viewers/${vKey}`), sanitizedViewer);
    } catch {}
  }
  if (db) {
    try {
      void setDoc(
        d(`schools/${schoolId}/nsta_statuses/${statusId}`),
        { viewers: { [vKey]: sanitizedViewer } },
        { merge: true }
      );
    } catch {}
  }
};

export const buildEventLectureFromStatus = (status: NstaSchoolStatus): DailyClassLecture => {
  const ytId =
    status.youtubeVideoId ||
    (status.mediaUrl ? extractYouTubeVideoId(status.mediaUrl) : "");
  const createdDate = (status.createdAt || new Date().toISOString()).slice(0, 10);
  return {
    id: status.archivedLectureId || `evt_${status.id}`,
    schoolId: status.schoolId,
    sessionId: "2026-27",
    classId: "universal",
    className: "🎉 School Events & Memories",
    date: createdDate,
    month: createdDate.slice(0, 7),
    periodNumber: 1,
    periodTime: "🎉 Event Video",
    subjectName: "School Event Video",
    topic: status.title || status.caption || "School Event Highlight",
    teacherName: status.authorName || "School Administration",
    teacherId: status.authorId,
    youtubeUrl: ytId ? (status.mediaUrl || `https://youtu.be/${ytId}`) : (status.mediaUrl || ""),
    youtubeVideoId: ytId,
    directVideoUrl: !ytId ? status.mediaUrl : undefined,
    isUniversal: true,
    isEventVideo: true,
    sourceStatusId: status.id,
    notes: status.caption || "24-Hour Status Event Video (Auto-Archived to Video Library)",
    addedAt: status.createdAt || new Date().toISOString(),
    addedBy: status.authorRole === "TEACHER" ? "TEACHER" : "ADMIN",
  };
};

const statusExpiryCooldown = new Map<string, number>();

export const archiveExpiredEventStatusesToLibrary = async (
  schoolId: string,
  statuses?: NstaSchoolStatus[]
): Promise<number> => {
  if (!schoolId) return 0;
  const cacheKey = `nst_school_nsta_statuses_${schoolId}`;
  const list = Array.isArray(statuses)
    ? statuses
    : getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
  if (!Array.isArray(list) || list.length === 0) return 0;

  const nowMs = Date.now();
  const expired = list.filter((s) => s && isNstaStatusExpired(s, nowMs));
  if (expired.length === 0) return 0;

  let archivedCount = 0;
  for (const st of expired) {
    try {
      const isEventVid =
        Boolean(st.isEventVideo) ||
        st.mediaType === "YOUTUBE_EVENT" ||
        st.mediaType === "VIDEO";
      if (isEventVid && st.mediaUrl && !st.archivedToLibrary) {
        const lec = buildEventLectureFromStatus(st);
        await saveClassLecture(lec);
        archivedCount++;
      }
      await deleteNstaStatus(schoolId, st.id);
    } catch {}
  }
  return archivedCount;
};

export const subscribeToNstaStatuses = (
  schoolId: string,
  cb: (statuses: NstaSchoolStatus[]) => void
): () => void => {
  const cacheKey = `nst_school_nsta_statuses_${schoolId}`;
  let disposed = false;

  const emitActive = () => {
    if (disposed) return;
    const raw = getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
    if (!Array.isArray(raw)) {
      cb([]);
      return;
    }
    const nowMs = Date.now();
    const expired: NstaSchoolStatus[] = [];
    const active: NstaSchoolStatus[] = [];
    for (const s of raw) {
      if (!s) continue;
      if (isNstaStatusExpired(s, nowMs)) expired.push(s);
      else active.push(s);
    }
    if (expired.length > 0) {
      setSchoolCacheSync(cacheKey, active);
      const lsKey = `nst_status_expiry_purge_${schoolId}`;
      let lastRun = statusExpiryCooldown.get(schoolId) || 0;
      try {
        const stored = Number(localStorage.getItem(lsKey) || 0);
        if (stored > lastRun) lastRun = stored;
      } catch {}
      if (nowMs - lastRun > 6 * 60 * 60 * 1000) {
        statusExpiryCooldown.set(schoolId, nowMs);
        try { localStorage.setItem(lsKey, String(nowMs)); } catch {}
        void archiveExpiredEventStatusesToLibrary(schoolId, expired);
      }
    }
    cb(active.sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || "")));
  };

  emitActive();
  whenSchoolIdbReady().then(() => { if (!disposed) emitActive(); }).catch(() => {});

  const handleCustomEvent = (e: any) => {
    if (e.detail?.schoolId === schoolId) emitActive();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("nsta-statuses-updated", handleCustomEvent);
    window.addEventListener("school-idb-hydrated", emitActive);
  }

  let fsList: NstaSchoolStatus[] | null = null;

  const mergeAndEmit = () => {
    if (disposed) return;
    const cur = getSchoolCacheSync<NstaSchoolStatus[]>(cacheKey, []);
    const mergedMap = new Map<string, NstaSchoolStatus>();
    const nowMs = Date.now();
    const recentCutoff = nowMs - 20_000;
    if (Array.isArray(cur)) {
      for (const s of cur) {
        if (s?.id && s.createdAt && Date.parse(s.createdAt) >= recentCutoff) {
          mergedMap.set(s.id, s);
        }
      }
    }
    if (Array.isArray(fsList)) {
      for (const s of fsList) {
        if (!s?.id) continue;
        const existing = mergedMap.get(s.id);
        mergedMap.set(s.id, {
          ...(existing || {}),
          ...s,
          viewers: { ...(existing?.viewers || {}), ...(s.viewers || {}) },
        });
      }
    }
    setSchoolCacheSync(cacheKey, Array.from(mergedMap.values()));
    emitActive();
  };

  let unsubFirestore = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/nsta_statuses`), orderBy("createdAt", "desc"), limit(40));
      unsubFirestore = onSnapshot(qFs, (snap) => {
        fsList = snap.docs.map((docSnap) => docSnap.data() as NstaSchoolStatus);
        mergeAndEmit();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (typeof window !== "undefined") {
      window.removeEventListener("nsta-statuses-updated", handleCustomEvent);
      window.removeEventListener("school-idb-hydrated", emitActive);
    }
    unsubFirestore();
  };
};

export interface NstaStatusUserGroup {
  userKey: string;
  authorId: string;
  authorName: string;
  authorRole: "ADMIN" | "TEACHER";
  authorPhoto?: string;
  items: NstaSchoolStatus[];
  latestStatus: NstaSchoolStatus;
  latestCreatedAt: string;
}

export const groupNstaStatusesByUser = (statuses: NstaSchoolStatus[]): NstaStatusUserGroup[] => {
  const groupsMap = new Map<string, NstaStatusUserGroup>();

  for (const st of statuses) {
    if (!st || !st.id) continue;
    const rawAuthorId = String(st.authorId || "").trim();
    const userKey = rawAuthorId
      ? `uid:${rawAuthorId}`
      : `name:${st.authorRole || "TEACHER"}:${String(st.authorName || "school").trim().toLowerCase()}`;

    const existing = groupsMap.get(userKey);
    if (!existing) {
      groupsMap.set(userKey, {
        userKey,
        authorId: rawAuthorId || userKey,
        authorName: st.authorName || (st.authorRole === "ADMIN" ? "School Admin" : "Teacher"),
        authorRole: st.authorRole === "TEACHER" ? "TEACHER" : "ADMIN",
        authorPhoto: st.authorPhoto,
        items: [st],
        latestStatus: st,
        latestCreatedAt: st.createdAt || "",
      });
    } else {
      existing.items.push(st);
      if ((st.createdAt || "").localeCompare(existing.latestCreatedAt) > 0) {
        existing.latestCreatedAt = st.createdAt || "";
        existing.latestStatus = st;
        if (st.authorName) existing.authorName = st.authorName;
        if (st.authorPhoto) existing.authorPhoto = st.authorPhoto;
      }
    }
  }

  const groups = Array.from(groupsMap.values());
  for (const g of groups) {
    // Play each user's statuses sequentially from oldest to newest
    g.items.sort((a, b) => (a.createdAt || "").localeCompare(b.createdAt || ""));
    g.latestStatus = g.items[g.items.length - 1];
  }
  groups.sort((a, b) => (b.latestCreatedAt || "").localeCompare(a.latestCreatedAt || ""));
  return groups;
};

// Check student's daily teacher query count (max 5)
export const getStudentDailyTeacherQueryCount = (schoolId: string, studentId: string, dateStr?: string): number => {
  const targetDate = dateStr || new Date().toISOString().split("T")[0];
  const cacheKey = `nst_school_nsta_msgs_${schoolId}`;
  const all = getSchoolCacheSync<NstaMessage[]>(cacheKey, []);
  if (!Array.isArray(all)) return 0;
  return all.filter(m =>
    m.threadType === "TEACHER_CHAT" &&
    m.studentId === studentId &&
    m.senderRole === "STUDENT" &&
    (m.createdAt || "").startsWith(targetDate)
  ).length;
};

// Auto route fee slip or receipt directly to student's School Desk in NSTA Messenger
export const autoSendFeeSlipToSchoolDesk = async (payload: {
  schoolId: string;
  studentId: string;
  studentName: string;
  className?: string;
  rollNo?: string;
  admissionNo?: string;
  feeItems?: any[];
  slipType: "A6_DEMAND_SLIP" | "FEE_RECEIPT";
  month: string;
  monthLabel: string;
  amount: number;
  balanceDue: number;
  monthlyAmount?: number;
  oldArrears?: number;
  earlyDiscount?: number;
  netPayableWithDiscount?: number;
  discountLabel?: string;
  discountSlabs?: import("./school-types").FeeDiscountSlab[];
  forceApplyDiscount?: boolean;
  receiptNo?: string;
  dueDate?: string;
  payLink?: string;
}): Promise<void> => {
  const isReceipt = payload.slipType === "FEE_RECEIPT";
  const todayDateNum = new Date().getDate();
  const slabs = Array.isArray(payload.discountSlabs) ? [...payload.discountSlabs].sort((a, b) => a.uptoDay - b.uptoDay) : [];

  const currentMonthFee = Number(payload.monthlyAmount || payload.amount || 0);
  const arrears = Math.max(0, Number(payload.oldArrears || Math.max(0, payload.balanceDue - currentMonthFee)));

  let earlyDiscount = 0;
  let resolvedDiscountLabel = payload.discountLabel || "";

  if (slabs.length > 0) {
    const matched = slabs.find((s) => todayDateNum <= s.uptoDay);
    if (matched && currentMonthFee > 0) {
      earlyDiscount =
        matched.discountType === "fixed"
          ? Math.min(currentMonthFee, Math.round(matched.discountValue))
          : Math.min(currentMonthFee, Math.round((currentMonthFee * matched.discountValue) / 100));
      const valTxt = matched.discountType === "fixed" ? `₹${matched.discountValue} OFF` : `${matched.discountValue}% OFF`;
      resolvedDiscountLabel = `${matched.uptoDay} तारीख तक ${valTxt}`;
    }
  } else if (payload.forceApplyDiscount || todayDateNum <= 10) {
    earlyDiscount =
      payload.earlyDiscount !== undefined
        ? Math.max(0, Number(payload.earlyDiscount))
        : currentMonthFee > 0 && todayDateNum <= 10
        ? Math.round(currentMonthFee * 0.05)
        : 0;
    if (!resolvedDiscountLabel && earlyDiscount > 0) {
      resolvedDiscountLabel = "10 तारीख तक 5% OFF";
    }
  }

  const netPayableWithDiscount =
    payload.netPayableWithDiscount !== undefined
      ? payload.netPayableWithDiscount
      : earlyDiscount > 0
      ? Math.max(0, payload.balanceDue - earlyDiscount)
      : payload.balanceDue;

  let text = "";
  if (isReceipt) {
    text = `Aapka ${payload.monthLabel} ka fee payment (₹${payload.amount.toLocaleString("en-IN")}) safalta-purvak receive ho gaya hai. Official receipt no: ${payload.receiptNo || "N/A"}. Dhanyawad!`;
  } else if (slabs.length > 0) {
    const slabSummary = slabs
      .map((s) => `${s.uptoDay} तारीख तक ${s.discountType === "fixed" ? `₹${s.discountValue}` : `${s.discountValue}%`} OFF`)
      .join(" • ");
    text = `📢 ${payload.monthLabel} फीस सूचना: कुल बकाया ₹${payload.balanceDue.toLocaleString("en-IN")} है। ⏳ अर्ली पेमेंट ऑफर: ${slabSummary}। (तय तिथि के बाद स्लिप की पूरी राशि ₹${payload.balanceDue.toLocaleString("en-IN")} देय होगी)।`;
  } else if (earlyDiscount > 0) {
    text = `📢 ${payload.monthLabel} फीस सूचना: कुल बकाया ₹${payload.balanceDue.toLocaleString("en-IN")} है। ⚡ ${resolvedDiscountLabel} (बचत: ₹${earlyDiscount.toLocaleString("en-IN")})! तय तिथि के बाद पूरा भुगतान देय होगा।`;
  } else {
    text = `Aapka ${payload.monthLabel} ka shulk baaki hai. Kul deya rashi: ₹${payload.balanceDue.toLocaleString("en-IN")}. Kripya antam tithi ${payload.dueDate || "jaldi"} se pehle jama karein.`;
  }

  const msg: NstaMessage = {
    id: `slip-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    schoolId: payload.schoolId,
    threadType: "SCHOOL_DESK",
    studentId: payload.studentId,
    studentName: payload.studentName,
    senderId: "school_admin",
    senderName: "School Accounts & Administration",
    senderRole: "ADMIN",
    text,
    feeSlip: {
      type: payload.slipType,
      month: payload.month,
      monthLabel: payload.monthLabel,
      amount: payload.amount,
      balanceDue: payload.balanceDue,
      monthlyAmount: currentMonthFee,
      oldArrears: arrears,
      earlyDiscount,
      netPayableWithDiscount,
      discountLabel: resolvedDiscountLabel || undefined,
      discountSlabs: slabs.length > 0 ? slabs : undefined,
      discountValidUntil:
        slabs.length > 0
          ? `${slabs[slabs.length - 1].uptoDay} तारीख तक`
          : payload.dueDate || "10 तारीख तक",
      isEligibleForEarlyDiscount: earlyDiscount > 0,
      studentName: payload.studentName,
      className: payload.className,
      rollNo: payload.rollNo,
      admissionNo: payload.admissionNo,
      feeItems: payload.feeItems,
      receiptNo: payload.receiptNo,
      dueDate: payload.dueDate || (slabs.length > 0 ? `${slabs[slabs.length - 1].uptoDay} तारीख तक` : "10th of Month"),
      payLink: payload.payLink,
    },
    createdAt: new Date().toISOString(),
    status: "delivered",
  };

  await saveNstaMessage(msg);
};

// ── OFFICIAL SCHOOL WELCOME MESSAGE (नया आईडी बनते ही आधिकारिक स्वागत संदेश) ──
export const dispatchOfficialSchoolWelcomeMessage = async (
  student: {
    id: string;
    name: string;
    admissionNo?: string;
    rollNo?: string;
    classId?: string;
    className?: string;
    schoolId?: string;
    schoolName?: string;
    fatherName?: string;
    mobile?: string;
    phone?: string;
    photoUrl?: string;
    photoURL?: string;
  },
  options?: {
    force?: boolean;
    schoolName?: string;
    schoolLogo?: string;
    triggerPopup?: boolean;
  }
): Promise<NstaMessage | null> => {
  if (!student || !student.id || !student.name) return null;
  const targetSchoolId = !student.schoolId || student.schoolId === "dps_gurgaon_sector45" ? DEFAULT_SCHOOL_ID : student.schoolId;
  const sentKey = `nst_welcome_sent_${targetSchoolId}_${student.id}`;

  const cleanAdmNo = student.admissionNo || `ADM-${student.id.slice(-6).toUpperCase()}`;
  const cleanRollNo = student.rollNo || "01";
  const cleanClassName =
    student.className ||
    (student.classId ? student.classId.replace(/^cls_/i, "Class ") : "Class 10");

  // Determine school name & branding
  let resolvedSchoolName = options?.schoolName || student.schoolName || "";
  let resolvedSchoolLogo = options?.schoolLogo || "";

  if (!resolvedSchoolName) {
    try {
      const schools = getLocalSchools();
      const matched = schools.find((s) => s.id === targetSchoolId);
      if (matched?.name) {
        resolvedSchoolName = matched.name;
        resolvedSchoolLogo = matched.logoUrl || "";
      }
    } catch {}
  }
  if (!resolvedSchoolName) {
    resolvedSchoolName = targetSchoolId === DEFAULT_SCHOOL_ID ? "LIFE MAKER PUBLIC SCHOOL" : "NSTA Digital School";
  }

  const welcomePayload: NstaWelcomeData = {
    studentId: student.id,
    studentName: student.name,
    admissionNo: cleanAdmNo,
    rollNo: cleanRollNo,
    classId: student.classId,
    className: cleanClassName,
    schoolName: resolvedSchoolName,
    schoolLogo: resolvedSchoolLogo,
    fatherName: student.fatherName,
    mobile: student.phone || student.mobile,
    session: "2026-27",
    verificationBadge: "VERIFIED_STUDENT_ID",
    issuedAt: new Date().toISOString(),
  };

  // Set popup flags so the student sees the celebratory Welcome Modal on login/scan
  try {
    localStorage.setItem(`nst_show_welcome_popup_${student.id}`, JSON.stringify(welcomePayload));
    localStorage.setItem("nst_pending_welcome_student", JSON.stringify(welcomePayload));
  } catch {}

  // Prevent duplicate chat messages in School Desk if already delivered
  try {
    if (!options?.force && localStorage.getItem(sentKey)) {
      return null;
    }
  } catch {}

  const welcomeText = `🌟 *आधिकारिक स्वागत संदेश | OFFICIAL WELCOME LETTER* 🌟

प्रिय विद्यार्थी *${student.name}*,
*${resolvedSchoolName}* के डिजिटल शैक्षणिक पोर्टल में आपका हार्दिक स्वागत एवं अभिनंदन है! 🎓

📋 *विद्यार्थी पहचान पत्र विवरण (Verified Student Identity)*:
• **विद्यार्थी का नाम (Student Name):** ${student.name}
• **प्रवेश संख्या (Admission No):** ${cleanAdmNo}
• **कक्षा (Class & Section):** ${cleanClassName}
• **रोल नंबर (Roll No):** ${cleanRollNo}
• **सत्र (Academic Session):** 2026-27
• **आईडी स्थिति:** ✅ सक्रिय व प्रमाणित (Digital ID Card Active)

🚀 *पोर्टल पर उपलब्ध मुख्य सुविधाएं (Digital Campus Facilities)*:
1. 📚 *डिजिटल पाठ्यक्रम एवं नोट्स* - सभी विषयों के सम्पूर्ण अध्यायवार नोट्स व व्याख्या (100% Free)।
2. 🎯 *दैनिक MCQ अभ्यास व टेस्ट* - वस्तुनिष्ठ प्रश्नोत्तरी, तत्काल स्कोर व लाइव लीडरबोर्ड।
3. ⏱️ *डिजिटल हाजिरी व लाइव अलर्ट्स* - स्कूल आगमन/प्रस्थान की रीयल-टाइम सूचना आपके अभिभावक तक।
4. 🧾 *शुल्क पर्ची व आधिकारिक रसीदें* - पारदर्शी ऑनलाइन फीस लेजर, पासबुक और POS रसीदें।
5. 💬 *NSTA मैसेंजर स्कूल डेस्क* - स्कूल के सभी सर्कुलर, नोटिस, गृहकार्य व शिक्षक मार्गदर्शन।

📌 *महत्वपूर्ण निर्देश (Guidelines)*:
• आपकी डिजिटल आईडी सक्रिय है। आप इसे स्कूल QR कोड स्कैनर द्वारा कभी भी 1-टैप में लॉगिन कर सकते हैं।
• सभी आवश्यक स्कूल सर्कुलर व अवकाश सूचना इसी स्कूल डेस्क पर प्राप्त होंगी।
• किसी भी समस्या हेतु विद्यालय कार्यालय अथवा कक्षा शिक्षक से संपर्क करें।

विद्यालय परिवार आपके उज्ज्वल भविष्य और उच्चतम शैक्षणिक सफलता की मंगलकामना करता है!

सादर,
*प्रधानाचार्य एवं विद्यालय प्रशासन (Principal & Academic Administration)*
🏛️ *${resolvedSchoolName}*
📞 हेल्पलाइन: 9525400122, 9835763641 | ✉️ support@nsta.app`;

  const welcomeMsg: NstaMessage = {
    id: `msg_welcome_${student.id}_${Date.now()}`,
    schoolId: targetSchoolId,
    threadType: "SCHOOL_DESK",
    studentId: student.id,
    studentName: student.name,
    senderId: `admin_${targetSchoolId}`,
    senderName: `${resolvedSchoolName} (Principal Desk)`,
    senderRole: "ADMIN",
    senderPhoto: resolvedSchoolLogo,
    text: welcomeText,
    attachmentType: "WELCOME",
    welcomeData: welcomePayload,
    createdAt: new Date().toISOString(),
    status: "sent",
  };

  try {
    await saveNstaMessage(welcomeMsg);
    localStorage.setItem(sentKey, "true");
  } catch {}

  // Send push notification
  try {
    const { sendSchoolPushNotification } = await import("./utils/schoolPushClient");
    void sendSchoolPushNotification({
      schoolId: targetSchoolId,
      studentIds: [student.id],
      senderId: `admin_${targetSchoolId}`,
      senderIds: ["STAFF_ADMIN", "school_admin", `admin_${targetSchoolId}`],
      senderName: resolvedSchoolName,
      title: `🎓 Welcome to ${resolvedSchoolName}!`,
      body: `प्रिय ${student.name}, आपका डिजिटल आईडी कार्ड व पोर्टल सक्रिय कर दिया गया है।`,
      type: "SCHOOL_NOTICE",
      icon: resolvedSchoolLogo,
      senderPhoto: resolvedSchoolLogo,
      url: "/?schoolPortal=1&schoolTab=messenger&subTab=school",
      urgent: true,
    });
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nst-school-welcome-received", { detail: welcomePayload })
    );
  }

  return welcomeMsg;
};

// ── STUDENT BIRTHDAY UTILITIES (स्वचालित जन्मदिन शुभकामना इंजन) ──
export const getStudentBirthdayInfo = (dob?: string): { month: number; day: number; birthYear?: number } | null => {
  if (!dob) return null;
  try {
    const clean = dob.trim();
    // Support formats: YYYY-MM-DD, DD/MM/YYYY, DD-MM-YYYY, YYYY/MM/DD
    const parts = clean.split(/[-/]/).map(Number);
    if (parts.length >= 3) {
      if (parts[0] > 1000) {
        // YYYY-MM-DD
        return { birthYear: parts[0], month: parts[1], day: parts[2] };
      }
      // DD-MM-YYYY (or DD/MM/YYYY)
      return { birthYear: parts[2], month: parts[1], day: parts[0] };
    } else if (parts.length === 2) {
      return { month: parts[1], day: parts[0] };
    }
  } catch {}
  return null;
};

export const isStudentBirthdayOnDate = (dob: string | undefined | null, targetMonth: number, targetDay: number): boolean => {
  const info = getStudentBirthdayInfo(dob || undefined);
  if (!info) return false;
  return info.month === targetMonth && info.day === targetDay;
};

export const isStudentBirthdayToday = (dob?: string): boolean => {
  if (!dob) return false;
  const today = new Date();
  return isStudentBirthdayOnDate(dob, today.getMonth() + 1, today.getDate());
};

export const dispatchOfficialSchoolBirthdayWish = async (
  student: {
    id: string;
    name: string;
    admissionNo?: string;
    rollNo?: string;
    classId?: string;
    className?: string;
    schoolId?: string;
    schoolName?: string;
    dateOfBirth?: string;
    phone?: string;
    photoUrl?: string;
  },
  options?: {
    force?: boolean;
    schoolName?: string;
    schoolLogo?: string;
    triggerPopup?: boolean;
  }
): Promise<NstaMessage | null> => {
  if (!student || !student.id || !student.name) return null;
  const targetSchoolId = !student.schoolId || student.schoolId === "dps_gurgaon_sector45" ? DEFAULT_SCHOOL_ID : student.schoolId;
  const currentYear = new Date().getFullYear();
  const sentKey = `nst_birthday_wish_sent_${targetSchoolId}_${student.id}_${currentYear}`;

  const cleanAdmNo = student.admissionNo || `ADM-${student.id.slice(-6).toUpperCase()}`;
  const cleanRollNo = student.rollNo || "01";
  const cleanClassName =
    student.className ||
    (student.classId ? student.classId.replace(/^cls_/i, "Class ") : "Class 10");
  const cleanDob = student.dateOfBirth || "Today";

  // Determine school name & branding
  let resolvedSchoolName = options?.schoolName || student.schoolName || "";
  let resolvedSchoolLogo = options?.schoolLogo || "";

  if (!resolvedSchoolName) {
    try {
      const schools = getLocalSchools();
      const matched = schools.find((s) => s.id === targetSchoolId);
      if (matched?.name) {
        resolvedSchoolName = matched.name;
        resolvedSchoolLogo = matched.logoUrl || "";
      }
    } catch {}
  }
  if (!resolvedSchoolName) {
    resolvedSchoolName =
      targetSchoolId === DEFAULT_SCHOOL_ID
        ? "LIFE MAKER PUBLIC SCHOOL"
        : "NSTA Digital School";
  }

  const birthdayPayload: NstaBirthdayData = {
    studentId: student.id,
    studentName: student.name,
    admissionNo: cleanAdmNo,
    rollNo: cleanRollNo,
    classId: student.classId,
    className: cleanClassName,
    schoolName: resolvedSchoolName,
    schoolLogo: resolvedSchoolLogo,
    dateOfBirth: cleanDob,
    wishedYear: currentYear,
    issuedAt: new Date().toISOString(),
  };

  // Set popup flags so student sees the celebratory Birthday Modal
  try {
    localStorage.setItem(
      `nst_show_birthday_popup_${student.id}`,
      JSON.stringify(birthdayPayload)
    );
    localStorage.setItem(
      "nst_pending_birthday_student",
      JSON.stringify(birthdayPayload)
    );
  } catch {}

  // Prevent duplicate chat messages in School Desk if already delivered this year
  try {
    if (!options?.force && localStorage.getItem(sentKey)) {
      return null;
    }
  } catch {}

  const birthdayText = `🎂 *जन्मदिन की हार्दिक शुभकामनाएं एवं शुभाशीर्वाद!* 🎂
✨ *OFFICIAL BIRTHDAY BLESSINGS & GREETINGS* ✨

प्रिय विद्यार्थी *${student.name}*,
*${resolvedSchoolName}* परिवार की ओर से आपके जन्मदिवस के इस मंगलमय अवसर पर आपको हार्दिक बधाई, असीम स्नेह और मंगलमय शुभकामनाएं! 🌟🎉

📋 *विद्यार्थी पहचान विवरण (Student Profile)*:
• **विद्यार्थी का नाम (Student Name):** ${student.name}
• **प्रवेश संख्या (Admission No):** ${cleanAdmNo}
• **कक्षा (Class & Section):** ${cleanClassName}
• **रोल नंबर (Roll No):** ${cleanRollNo}
• **जन्म तिथि (Date of Birth):** ${cleanDob}
• **विद्यालय (School):** ${resolvedSchoolName}

💐 *प्रधानाचार्य व विद्यालय प्रबंधन का संदेश (Principal's Blessing)*:
"विद्यार्थी जीवन स्वर्णिम भविष्य की मजबूत नींव होता है। ईश्वर से प्रार्थना है कि यह नया वर्ष आपके जीवन में उत्तम स्वास्थ्य, प्रखर बुद्धि, एकाग्रता और नित-नई शैक्षणिक उपलब्धियां लेकर आए। आप अपनी कड़ी मेहनत, अनुशासन और श्रेष्ठ आचरण से अपने माता-पिता, गुरुजनों और विद्यालय का नाम पूरे देश में रोशन करें।"

🌟 *जन्मदिवस पर आपके लिए विशेष (Birthday Highlights)*:
1. 📚 ज्ञान और अनुशासन के साथ अपने लक्ष्यों की ओर अग्रसर रहें।
2. 🎯 अपने दैनिक अध्ययन, अभ्यास और सीखने की ललक को सदैव जीवित रखें।
3. 🏆 विद्यालय का संपूर्ण डिजिटल लर्निंग कैंपस व शिक्षक मार्गदर्शन सदैव आपके साथ है।

विद्यालय परिवार आपके सुखद, स्वस्थ, यशस्वी एवं उज्ज्वल भविष्य की कामना करता है। ईश्वर आपको सदैव प्रगति के मार्ग पर प्रशस्त रखें।

सस्नेह व शुभाशीर्वाद,
*प्रधानाचार्य एवं समस्त शिक्षकगण (Principal & Faculty Members)*
🏛️ *${resolvedSchoolName}*
📞 हेल्पलाइन: 9525400122, 9835763641 | ✉️ support@nsta.app`;

  const birthdayMsg: NstaMessage = {
    id: `msg_bday_${student.id}_${currentYear}_${Date.now()}`,
    schoolId: targetSchoolId,
    threadType: "SCHOOL_DESK",
    studentId: student.id,
    studentName: student.name,
    senderId: `admin_${targetSchoolId}`,
    senderName: `${resolvedSchoolName} (Principal Desk)`,
    senderRole: "ADMIN",
    senderPhoto: resolvedSchoolLogo,
    text: birthdayText,
    attachmentType: "BIRTHDAY",
    birthdayData: birthdayPayload,
    createdAt: new Date().toISOString(),
    status: "sent",
  };

  try {
    await saveNstaMessage(birthdayMsg);
    localStorage.setItem(sentKey, "true");
  } catch {}

  // Send real-time push notification
  try {
    const { sendSchoolPushNotification } = await import("./utils/schoolPushClient");
    void sendSchoolPushNotification({
      schoolId: targetSchoolId,
      studentIds: [student.id],
      senderId: `admin_${targetSchoolId}`,
      senderIds: ["STAFF_ADMIN", "school_admin", `admin_${targetSchoolId}`],
      senderName: resolvedSchoolName,
      title: `🎂 जन्मदिन की हार्दिक शुभकामनाएं! | Happy Birthday!`,
      body: `प्रिय ${student.name}, ${resolvedSchoolName} की ओर से जन्मदिवस पर हार्दिक बधाई व शुभाशीर्वाद।`,
      type: "SCHOOL_NOTICE",
      icon: resolvedSchoolLogo,
      senderPhoto: resolvedSchoolLogo,
      url: "/?schoolPortal=1&schoolTab=messenger&subTab=school",
      urgent: true,
    });
  } catch {}

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("nst-school-birthday-received", { detail: birthdayPayload })
    );
  }

  return birthdayMsg;
};

// Automatic daily check for any student whose birthday is today in the given school
export const checkAndDispatchTodaysBirthdays = async (
  schoolId: string = DEFAULT_SCHOOL_ID
): Promise<number> => {
  try {
    const students = getLocalStudents(schoolId);
    if (!Array.isArray(students) || students.length === 0) return 0;

    let dispatchedCount = 0;
    for (const st of students) {
      if (st && st.dateOfBirth && isStudentBirthdayToday(st.dateOfBirth)) {
        const msg = await dispatchOfficialSchoolBirthdayWish(st, {
          force: false,
          triggerPopup: true,
        });
        if (msg) dispatchedCount++;
      }
    }
    return dispatchedCount;
  } catch {
    return 0;
  }
};

// ── SCHOOL EVENTS & MORNING 6:00 AM TEACHER NOTIFICATIONS ──────────────────
const LOCAL_EVENTS_PREFIX = "nst_school_events_";

const DEFAULT_LEGACY_EVENT_PREFIXES = [
  "evt_staff_meet_",
  "evt_exam_pa2_",
  "evt_ptm_result_",
];

const isLegacyDefaultSeedEvent = (evt?: Partial<SchoolEvent> | null): boolean => {
  const id = String(evt?.id || "");
  if (!id) return false;
  return (
    DEFAULT_LEGACY_EVENT_PREFIXES.some((p) => id.startsWith(p)) ||
    id.startsWith("ev-")
  );
};

export const getLocalSchoolEvents = (schoolId: string): SchoolEvent[] => {
  try {
    const raw = getSchoolCacheSync<SchoolEvent[]>(`${LOCAL_EVENTS_PREFIX}${schoolId}`, []);
    const isDemo = shouldUseDemoForSchool(schoolId);
    const list = Array.isArray(raw)
      ? isDemo
        ? raw
        : raw.filter((e) => !isLegacyDefaultSeedEvent(e))
      : [];
    if (list.length > 0) return list;
    if (isDemo) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.events && demo.events.length > 0) {
        return demo.events;
      }
    }
    return list;
  } catch {
    return [];
  }
};

export const setLocalSchoolEvents = (schoolId: string, events: SchoolEvent[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_EVENTS_PREFIX}${schoolId}`, Array.isArray(events) ? events : []);
  } catch {}
};

export const getSchoolEvents = async (schoolId: string): Promise<SchoolEvent[]> => {
  await whenSchoolIdbReady();
  const isDemo = shouldUseDemoForSchool(schoolId);
  const local = getLocalSchoolEvents(schoolId);
  const cacheKey = `${LOCAL_EVENTS_PREFIX}${schoolId}`;
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, "events", cacheKey, () => local.length > 0, 15 * 60 * 1000);
  if (!shouldFetch) {
    return local;
  }

  return dedupInflight(`events:${schoolId}`, async () => {
    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/events`)), 2500);
        fsOk = true;
        const rawList = snap.docs.map(docSnap => docSnap.data() as SchoolEvent);
        const list = isDemo ? rawList : rawList.filter((e) => !isLegacyDefaultSeedEvent(e));
        setLocalSchoolEvents(schoolId, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }

    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/events`)), 2000);
        const val = (snap as any)?.val?.();
        if (val && typeof val === "object") {
          const rawList = Object.values(val) as SchoolEvent[];
          const list = isDemo ? rawList : rawList.filter((e) => !isLegacyDefaultSeedEvent(e));
          setLocalSchoolEvents(schoolId, list);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return list;
        }
      } catch {}
    }

    markSchoolCacheFresh(cacheKey, remoteVer);
    return local;
  });
};

export const saveSchoolEvent = async (event: SchoolEvent): Promise<void> => {
  const sanitized = sanitizeForFirestore(event);
  const current = getLocalSchoolEvents(event.schoolId);
  const updated = [sanitized, ...current.filter(e => e.id !== event.id)];
  setLocalSchoolEvents(event.schoolId, updated);
  markSchoolCacheFresh(`${LOCAL_EVENTS_PREFIX}${event.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-events-updated", { detail: { schoolId: event.schoolId, event: sanitized } }));
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${event.schoolId}/events/${event.id}`), sanitized), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${event.schoolId}/events/${event.id}`), sanitized), 2500);
      void touchSchoolSyncVersion(event.schoolId, "events");
    } catch {}
  }
};

export const deleteSchoolEvent = async (schoolId: string, eventId: string): Promise<void> => {
  const current = getLocalSchoolEvents(schoolId);
  const updated = current.filter(e => e.id !== eventId);
  setLocalSchoolEvents(schoolId, updated);
  markSchoolCacheFresh(`${LOCAL_EVENTS_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-events-updated", { detail: { schoolId, eventId, action: "DELETE" } }));
  }

  if (rtdb) {
    try {
      await withTimeout(remove(ref(rtdb, `schools/${schoolId}/events/${eventId}`)), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/events/${eventId}`)), 2500);
      void touchSchoolSyncVersion(schoolId, "events");
    } catch {}
  }
};

export const subscribeToSchoolEvents = (schoolId: string, cb: (events: SchoolEvent[]) => void) => {
  let active = true;
  const deliverLocal = (e?: any) => {
    if (!active) return;
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    const local = getLocalSchoolEvents(schoolId);
    cb(local);
  };

  deliverLocal();
  whenSchoolIdbReady()
    .then(() => {
      if (!active) return;
      deliverLocal();
      return getSchoolEvents(schoolId);
    })
    .then((fresh) => {
      if (active && Array.isArray(fresh) && fresh.length > 0) cb(fresh);
    })
    .catch(() => {});

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("school-events-updated", deliverLocal);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("school-events-updated", deliverLocal);
    }
  };
};

export const dispatchTeacherEventNotification = async (
  schoolId: string,
  event: SchoolEvent,
  options?: { force?: boolean }
): Promise<{ delivered: number }> => {
  if (!event || !event.title) return { delivered: 0 };
  if (!options?.force && (event.notifiedTeachers || isLegacyDefaultSeedEvent(event))) {
    return { delivered: 0 };
  }
  const targetSchoolId = schoolId || event.schoolId;
  const sentKey = `nst_morning_event_sent_${targetSchoolId}_${event.id}_${event.date}`;

  if (!options?.force && typeof window !== "undefined") {
    try {
      if (localStorage.getItem(sentKey)) {
        return { delivered: 0 };
      }
    } catch {}
  }

  let schoolName = "School";
  try {
    const s = await getSchool(targetSchoolId);
    if (s?.name) schoolName = s.name;
  } catch {}

  const typeLabels: Record<SchoolEventType, string> = {
    MEETING: "🤝 स्टाफ मीटिंग / परामर्श",
    EXAM: "📝 परीक्षा (Exam Day)",
    RESULT_DAY: "📊 रिजल्ट डे / PTM",
    OFFICIAL_WORK: "💼 स्कूल महत्वपूर्ण कार्य (Inspection/Audit)",
    CELEBRATION: "🎉 वार्षिकोत्सव / उत्सव",
    HOLIDAY: "🏖️ स्कूल अवकाश",
    OTHER: "📌 आवश्यक सूचना"
  };
  const typeLabel = typeLabels[event.type] || "📌 आधिकारिक कार्यक्रम";

  const teachers = await getTeachers(targetSchoolId);
  let delivered = 0;

  const notificationText =
    `🔔 **[${schoolName}] — आवश्यक शिक्षक सूचना व कार्यक्रम**\n\n` +
    `📌 **कार्यक्रम**: ${event.title}\n` +
    `🏷️ **प्रकार**: ${typeLabel}\n` +
    `🗓️ **तारीख**: ${event.date}\n` +
    (event.time ? `⏰ **समय**: ${event.time}\n` : "") +
    (event.venue ? `📍 **स्थान**: ${event.venue}\n` : "") +
    (event.description ? `📝 **विवरण**: ${event.description}\n\n` : "\n") +
    `*समस्त शिक्षकगण कृपया समय पर संज्ञान लें व आवश्यक तैयारी सुनिश्चित करें।* — प्रधानाचार्य व प्रशासन`;

  for (const t of teachers) {
    try {
      const msg: NstaMessage = {
        id: `evt_msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
        schoolId: targetSchoolId,
        threadType: "SCHOOL_DESK",
        teacherId: t.id,
        teacherName: t.name,
        senderId: "admin",
        senderName: `${schoolName} Administration`,
        senderRole: "ADMIN",
        text: notificationText,
        createdAt: new Date().toISOString(),
        status: "delivered"
      };
      await saveNstaMessage(msg);
      delivered++;
    } catch {}
  }

  // Dual dispatch real-time web push alert with sound (only to teachers unless WHOLE_SCHOOL)
  try {
    const { sendSchoolPushNotification } = await import("./utils/schoolPushClient");
    const isWholeSchool = event.targetAudience === "WHOLE_SCHOOL";
    const teacherRecipientIds = teachers.map((t) => String(t?.id || "")).filter(Boolean);
    if (isWholeSchool || teacherRecipientIds.length > 0) {
      await sendSchoolPushNotification({
        schoolId: targetSchoolId,
        ...(isWholeSchool ? { schoolBroadcast: true } : { studentIds: teacherRecipientIds }),
        senderId: "STAFF_ADMIN",
        senderIds: ["STAFF_ADMIN", "school_admin"],
        title: `🔔 [${schoolName}] आज का कार्यक्रम: ${event.title}`,
        body: `तारीख: ${event.date}${event.time ? ` • समय: ${event.time}` : ""} — ${typeLabel}. सभी शिक्षक कृपया संज्ञान लें।`,
        type: "SCHOOL_NOTICE",
        urgent: true
      });
    }
  } catch {}

  // Mark notified
  try {
    if (typeof window !== "undefined") {
      localStorage.setItem(sentKey, new Date().toISOString());
    }
  } catch {}

  // Update event state
  await saveSchoolEvent({
    ...event,
    notifiedTeachers: true,
    notifiedAt: new Date().toISOString()
  });

  return { delivered };
};

export const checkAndDispatchMorningEventAlerts = async (schoolId: string): Promise<number> => {
  try {
    if (shouldUseDemoForSchool(schoolId)) return 0;
    const now = new Date();
    const currentHour = now.getHours(); // 0-23
    // Morning 6 AM or later
    if (currentHour < 6) return 0;

    const y = now.getFullYear();
    const m = String(now.getMonth() + 1).padStart(2, "0");
    const d = String(now.getDate()).padStart(2, "0");
    const todayStr = `${y}-${m}-${d}`;

    const events = await getSchoolEvents(schoolId);
    const todaysEvents = events.filter(
      (e) =>
        e &&
        e.date === todayStr &&
        e.autoMorningAlert === true &&
        !e.notifiedTeachers &&
        !isLegacyDefaultSeedEvent(e)
    );
    let count = 0;

    for (const evt of todaysEvents) {
      const sentKey = `nst_morning_event_sent_${schoolId}_${evt.id}_${todayStr}`;
      let alreadySent = false;
      try {
        if (typeof window !== "undefined" && localStorage.getItem(sentKey)) {
          alreadySent = true;
        }
      } catch {}

      if (!alreadySent) {
        const res = await dispatchTeacherEventNotification(schoolId, evt);
        if (res.delivered > 0) count++;
      }
    }
    return count;
  } catch {
    return 0;
  }
};


// ── ACCOUNTANTS (कैशियर / वित्तीय प्रबंधन) ──────────────────────────────────────────────
const LOCAL_ACCOUNTANTS_PREFIX = "nst_school_accountants_";

export const getLocalAccountants = (schoolId: string): SchoolAccountant[] => {
  try {
    const list = getSchoolCacheSync<SchoolAccountant[]>(`${LOCAL_ACCOUNTANTS_PREFIX}${schoolId}`, []);
    if (Array.isArray(list) && list.length > 0) return list;
    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.accountants && demo.accountants.length > 0) {
        return demo.accountants;
      }
    }
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalAccountants = (schoolId: string, accountants: SchoolAccountant[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_ACCOUNTANTS_PREFIX}${schoolId}`, Array.isArray(accountants) ? accountants : []);
  } catch {}
};

export const saveAccountant = async (accountant: SchoolAccountant) => {
  const sanitized = sanitizeForFirestore(accountant);
  const current = getLocalAccountants(accountant.schoolId);
  const next = [sanitized, ...current.filter((a: any) => a.id !== accountant.id)];
  setLocalAccountants(accountant.schoolId, next);
  markSchoolCacheFresh(`${LOCAL_ACCOUNTANTS_PREFIX}${accountant.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("accountants-updated", { detail: { schoolId: accountant.schoolId, accountants: next } }));
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${accountant.schoolId}/accountants/${accountant.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${accountant.schoolId}/accountants/${accountant.id}`), sanitized), 3000);
      void touchSchoolSyncVersion(accountant.schoolId, "accountants");
    } catch {}
  }
  return sanitized;
};

export const getAccountants = async (schoolId: string): Promise<SchoolAccountant[]> => {
  await whenSchoolIdbReady();
  const local = getLocalAccountants(schoolId);
  const cacheKey = `${LOCAL_ACCOUNTANTS_PREFIX}${schoolId}`;
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, "accountants", cacheKey, () => local.length > 0, 15 * 60 * 1000);
  if (!shouldFetch) return local;

  return dedupInflight(`accountants:${schoolId}`, async () => {
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/accountants`)), 2500);
        const list = snap.docs.map(docSnap => docSnap.data() as SchoolAccountant);
        setLocalAccountants(schoolId, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }
    return local;
  });
};

export const subscribeToAccountants = (schoolId: string, cb: (accountants: SchoolAccountant[]) => void) => {
  let active = true;
  const deliverLocal = (e?: any) => {
    if (!active) return;
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    cb(getLocalAccountants(schoolId));
  };
  deliverLocal();

  whenSchoolIdbReady()
    .then(() => {
      if (!active) return;
      deliverLocal();
      return getAccountants(schoolId);
    })
    .then((fresh) => {
      if (active && Array.isArray(fresh)) cb(fresh);
    })
    .catch(() => {});

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("accountants-updated", deliverLocal);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("accountants-updated", deliverLocal);
    }
  };
};

export const deleteAccountant = async (schoolId: string, accountantId: string) => {
  const current = getLocalAccountants(schoolId);
  const next = current.filter(a => a.id !== accountantId);
  setLocalAccountants(schoolId, next);
  markSchoolCacheFresh(`${LOCAL_ACCOUNTANTS_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("accountants-updated", { detail: { schoolId, accountants: next } }));
  }

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/accountants/${accountantId}`)), 2000); } catch {}
  }
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/accountants/${accountantId}`)), 2500);
      void touchSchoolSyncVersion(schoolId, "accountants");
    } catch {}
  }
};

// ── EXPENSE VOUCHERS (दैनिक विद्यालय खर्च / वाउचर) ───────────────────────────
const LOCAL_EXPENSES_PREFIX = "nst_school_expenses_";

export const getLocalExpenseVouchers = (schoolId: string): SchoolExpenseVoucher[] => {
  try {
    const list = getSchoolCacheSync<SchoolExpenseVoucher[]>(`${LOCAL_EXPENSES_PREFIX}${schoolId}`, []);
    if (Array.isArray(list) && list.length > 0) return list;
    if (shouldUseDemoForSchool(schoolId)) {
      const demo = getDemoSchoolDataset(true);
      if (demo && demo.expenseVouchers && demo.expenseVouchers.length > 0) {
        return demo.expenseVouchers;
      }
    }
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalExpenseVouchers = (schoolId: string, vouchers: SchoolExpenseVoucher[]) => {
  try {
    setSchoolCacheSync(`${LOCAL_EXPENSES_PREFIX}${schoolId}`, Array.isArray(vouchers) ? vouchers : []);
  } catch {}
};

export const saveSchoolExpenseVoucher = async (voucher: SchoolExpenseVoucher) => {
  const sanitized = sanitizeForFirestore(voucher);
  const current = getLocalExpenseVouchers(voucher.schoolId);
  const next = [sanitized, ...current.filter((v: any) => v.id !== voucher.id)];
  setLocalExpenseVouchers(voucher.schoolId, next);
  markSchoolCacheFresh(`${LOCAL_EXPENSES_PREFIX}${voucher.schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("expenses-updated", { detail: { schoolId: voucher.schoolId, vouchers: next } }));
  }

  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${voucher.schoolId}/expenses/${voucher.id}`), sanitized), 2000); } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${voucher.schoolId}/expenses/${voucher.id}`), sanitized), 3000);
      void touchSchoolSyncVersion(voucher.schoolId, "expenses");
    } catch {}
  }
  return sanitized;
};

export const getSchoolExpenseVouchers = async (schoolId: string): Promise<SchoolExpenseVoucher[]> => {
  await whenSchoolIdbReady();
  const local = getLocalExpenseVouchers(schoolId);
  const cacheKey = `${LOCAL_EXPENSES_PREFIX}${schoolId}`;
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, "expenses", cacheKey, () => local.length > 0, 10 * 60 * 1000);
  if (!shouldFetch) return local;

  return dedupInflight(`expenses:${schoolId}`, async () => {
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/expenses`)), 2500);
        const list = snap.docs.map(docSnap => docSnap.data() as SchoolExpenseVoucher);
        setLocalExpenseVouchers(schoolId, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }
    return local;
  });
};

export const subscribeToExpenseVouchers = (schoolId: string, cb: (vouchers: SchoolExpenseVoucher[]) => void) => {
  let active = true;
  const deliverLocal = (e?: any) => {
    if (!active) return;
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    cb(getLocalExpenseVouchers(schoolId));
  };
  deliverLocal();

  whenSchoolIdbReady()
    .then(() => {
      if (!active) return;
      deliverLocal();
      return getSchoolExpenseVouchers(schoolId);
    })
    .then((fresh) => {
      if (active && Array.isArray(fresh)) cb(fresh);
    })
    .catch(() => {});

  if (typeof window !== "undefined") {
    window.addEventListener("school-idb-hydrated", deliverLocal);
    window.addEventListener("expenses-updated", deliverLocal);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-idb-hydrated", deliverLocal);
      window.removeEventListener("expenses-updated", deliverLocal);
    }
  };
};

export const deleteSchoolExpenseVoucher = async (schoolId: string, voucherId: string) => {
  const current = getLocalExpenseVouchers(schoolId);
  const next = current.filter(v => v.id !== voucherId);
  setLocalExpenseVouchers(schoolId, next);
  markSchoolCacheFresh(`${LOCAL_EXPENSES_PREFIX}${schoolId}`);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("expenses-updated", { detail: { schoolId, vouchers: next } }));
  }

  if (rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/expenses/${voucherId}`)), 2000); } catch {}
  }
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/expenses/${voucherId}`)), 2500);
      void touchSchoolSyncVersion(schoolId, "expenses");
    } catch {}
  }
};

// ── STUDENT ACKNOWLEDGED LEAVES (छुट्टी व वापसी ट्रैकर) ──────────────────────────────
const LOCAL_STUDENT_LEAVES_PREFIX = "nst_student_leaves_";

export const getLocalStudentLeaves = (schoolId: string): StudentAcknowledgedLeave[] => {
  try {
    const list = getSchoolCacheSync<StudentAcknowledgedLeave[]>(`${LOCAL_STUDENT_LEAVES_PREFIX}${schoolId}`, []);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalStudentLeaves = (schoolId: string, leaves: StudentAcknowledgedLeave[]) => {
  setSchoolCacheSync(`${LOCAL_STUDENT_LEAVES_PREFIX}${schoolId}`, leaves);
};

export const saveStudentAcknowledgedLeave = async (leave: StudentAcknowledgedLeave): Promise<void> => {
  const current = getLocalStudentLeaves(leave.schoolId);
  const idx = current.findIndex(l => l.id === leave.id || (l.studentId === leave.studentId && l.status === "active"));
  let updated: StudentAcknowledgedLeave[];
  if (idx >= 0) {
    updated = [...current];
    updated[idx] = leave;
  } else {
    updated = [leave, ...current];
  }
  setLocalStudentLeaves(leave.schoolId, updated);
  markSchoolCacheFresh(`${LOCAL_STUDENT_LEAVES_PREFIX}${leave.schoolId}`);

  const clean = sanitizeForFirestore(leave);
  let fsOk = false;
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${leave.schoolId}/student_leaves/${leave.id}`), clean, { merge: true }), 2500);
      fsOk = true;
      touchSchoolSyncVersion(leave.schoolId, "student_leaves");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${leave.schoolId}/student_leaves/${leave.id}`), clean), 2000); } catch {}
  }
};

export const getStudentAcknowledgedLeaves = async (schoolId: string): Promise<StudentAcknowledgedLeave[]> => {
  await whenSchoolIdbReady();
  const cacheKey = `${LOCAL_STUDENT_LEAVES_PREFIX}${schoolId}`;
  const local = getLocalStudentLeaves(schoolId);
  const { fetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "student_leaves",
    cacheKey,
    () => local.length > 0 || isSchoolCacheFresh(cacheKey, 24 * 60 * 60 * 1000),
    15 * 60 * 1000
  );
  if (!fetch) return local;

  return dedupInflight<StudentAcknowledgedLeave[]>(`student_leaves:${schoolId}`, async () => {
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/student_leaves`)), 2500);
        const list = snap.docs.map(docSnap => docSnap.data() as StudentAcknowledgedLeave);
        setLocalStudentLeaves(schoolId, list);
        markSchoolCacheFresh(cacheKey, remoteVer);
        return list;
      } catch {}
    }
    return local;
  });
};

export const deleteStudentAcknowledgedLeave = async (schoolId: string, leaveId: string): Promise<void> => {
  const current = getLocalStudentLeaves(schoolId);
  setLocalStudentLeaves(schoolId, current.filter(l => l.id !== leaveId));
  markSchoolCacheFresh(`${LOCAL_STUDENT_LEAVES_PREFIX}${schoolId}`);

  let fsOk = false;
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/student_leaves/${leaveId}`)), 2500);
      fsOk = true;
      touchSchoolSyncVersion(schoolId, "student_leaves");
    } catch {}
  }
  if (!fsOk && rtdb) {
    try { await withTimeout(remove(ref(rtdb, `schools/${schoolId}/student_leaves/${leaveId}`)), 2000); } catch {}
  }
};

// ── ABSENTEE CALL LOGS (पेरेंट्स कॉल व रिमार्क्स) ──────────────────────────────
const LOCAL_CALL_LOGS_PREFIX = "nst_absentee_call_logs_";

export const getLocalAbsenteeCallLogs = (schoolId: string, date?: string): StudentAbsenteeCallLog[] => {
  try {
    const key = date ? `${LOCAL_CALL_LOGS_PREFIX}${schoolId}_${date}` : `${LOCAL_CALL_LOGS_PREFIX}${schoolId}`;
    const list = getSchoolCacheSync<StudentAbsenteeCallLog[]>(key, []);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const saveAbsenteeCallLog = async (log: StudentAbsenteeCallLog): Promise<void> => {
  const dateKey = `${LOCAL_CALL_LOGS_PREFIX}${log.schoolId}_${log.date}`;
  const current = getLocalAbsenteeCallLogs(log.schoolId, log.date);
  const updated = [log, ...current.filter(l => l.id !== log.id && l.studentId !== log.studentId)];
  setSchoolCacheSync(dateKey, updated);

  const clean = sanitizeForFirestore(log);
  if (rtdb) {
    try { await withTimeout(set(ref(rtdb, `schools/${log.schoolId}/absentee_call_logs/${log.date}/${log.id}`), clean), 2000); } catch {}
  }
  if (db) {
    try { await withTimeout(setDoc(d(`schools/${log.schoolId}/absentee_call_logs/${log.id}`), clean, { merge: true }), 2500); } catch {}
  }
};

// ── SCHOOL CUSTOM CURRICULUM & NOTES (Class 6-12 Notes, MCQ, PDF, Audio, Video) ──
const LOCAL_CURRICULUM_NOTES_PREFIX = "nst_school_curriculum_notes_";

export const getLocalSchoolCurriculumNotes = (schoolId: string): any[] => {
  try {
    const list = getSchoolCacheSync<any[]>(`${LOCAL_CURRICULUM_NOTES_PREFIX}${schoolId}`, []);
    return Array.isArray(list) ? list : [];
  } catch {
    return [];
  }
};

export const setLocalSchoolCurriculumNotes = (schoolId: string, notes: any[]): void => {
  setSchoolCacheSync(`${LOCAL_CURRICULUM_NOTES_PREFIX}${schoolId}`, notes);
};

export const getAllAvailableSchoolCurriculumNotes = (preferredSchoolId?: string): any[] => {
  if (!preferredSchoolId) return [];
  const deletedIds = getDeletedSchoolIds();
  if (deletedIds.has(preferredSchoolId)) return [];

  const map = new Map<string, any>();
  const list = getLocalSchoolCurriculumNotes(preferredSchoolId);
  list.forEach(n => {
    if (n && n.id && (!n.schoolId || n.schoolId === preferredSchoolId)) {
      map.set(n.id, n);
    }
  });

  return Array.from(map.values());
};

export const saveSchoolCurriculumNote = async (schoolId: string, note: any): Promise<void> => {
  const current = getLocalSchoolCurriculumNotes(schoolId);
  const existingIdx = current.findIndex(n => n.id === note.id);
  const updatedNote = {
    ...note,
    schoolId,
    updatedAt: new Date().toISOString(),
    createdAt: note.createdAt || new Date().toISOString(),
  };

  const updatedList = existingIdx >= 0
    ? current.map(n => n.id === note.id ? updatedNote : n)
    : [updatedNote, ...current];

  setLocalSchoolCurriculumNotes(schoolId, updatedList);
  markSchoolCacheFresh(`${LOCAL_CURRICULUM_NOTES_PREFIX}${schoolId}`);

  // Also sync into localSettings / nst_system_settings so global student reader views can see it immediately
  try {
    const rawSettings = localStorage.getItem('nst_system_settings');
    if (rawSettings) {
      const parsed = JSON.parse(rawSettings);
      const existingLucent: any[] = Array.isArray(parsed.lucentNotes) ? parsed.lucentNotes : [];
      const lIdx = existingLucent.findIndex((n: any) => n.id === note.id);
      const updatedLucent = lIdx >= 0
        ? existingLucent.map((n: any) => n.id === note.id ? updatedNote : n)
        : [...existingLucent, updatedNote];
      parsed.lucentNotes = updatedLucent;
      localStorage.setItem('nst_system_settings', JSON.stringify(parsed));
    }
  } catch {}

  // Dispatch events to notify active views in the student and school apps immediately
  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('nst-school-curriculum-notes-updated', {
      detail: { schoolId, note: updatedNote, allNotes: updatedList }
    }));
    window.dispatchEvent(new CustomEvent('nst_lucent_notes_updated', {
      detail: { note: updatedNote }
    }));
    window.dispatchEvent(new CustomEvent('nst_system_settings_updated', {
      detail: { lucentNote: updatedNote }
    }));
  }

  const clean = sanitizeForFirestore(updatedNote);
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/curriculum_notes/${note.id}`), clean), 2500);
      await withTimeout(set(ref(rtdb, `lucent_entries/${note.id}`), clean), 2500);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/curriculum_notes/${note.id}`), clean, { merge: true }), 3000);
      await withTimeout(setDoc(d(`lucent_entries/${note.id}`), clean, { merge: true }), 3000);
      void touchSchoolSyncVersion(schoolId, "curriculum_notes");
    } catch {}
  }
};

export const deleteSchoolCurriculumNote = async (schoolId: string, noteId: string): Promise<void> => {
  const current = getLocalSchoolCurriculumNotes(schoolId);
  const updatedList = current.filter(n => n.id !== noteId);
  setLocalSchoolCurriculumNotes(schoolId, updatedList);
  markSchoolCacheFresh(`${LOCAL_CURRICULUM_NOTES_PREFIX}${schoolId}`);

  try {
    const rawSettings = localStorage.getItem('nst_system_settings');
    if (rawSettings) {
      const parsed = JSON.parse(rawSettings);
      if (Array.isArray(parsed.lucentNotes)) {
        parsed.lucentNotes = parsed.lucentNotes.filter((n: any) => n.id !== noteId);
        localStorage.setItem('nst_system_settings', JSON.stringify(parsed));
      }
    }
  } catch {}

  if (typeof window !== 'undefined') {
    window.dispatchEvent(new CustomEvent('nst-school-curriculum-notes-updated', {
      detail: { schoolId, deletedNoteId: noteId, allNotes: updatedList }
    }));
    window.dispatchEvent(new CustomEvent('nst_lucent_notes_updated', {
      detail: { deletedNoteId: noteId }
    }));
    window.dispatchEvent(new CustomEvent('nst_system_settings_updated', {
      detail: { deletedNoteId: noteId }
    }));
  }

  if (rtdb) {
    try {
      await withTimeout(remove(ref(rtdb, `schools/${schoolId}/curriculum_notes/${noteId}`)), 2000);
      await withTimeout(remove(ref(rtdb, `lucent_entries/${noteId}`)), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(deleteDoc(d(`schools/${schoolId}/curriculum_notes/${noteId}`)), 2500);
      await withTimeout(deleteDoc(d(`lucent_entries/${noteId}`)), 2500);
      void touchSchoolSyncVersion(schoolId, "curriculum_notes");
    } catch {}
  }
};

export const subscribeToSchoolCurriculumNotes = (
  schoolId: string,
  callback: (notes: any[]) => void
): (() => void) => {
  let active = true;
  const cacheKey = `${LOCAL_CURRICULUM_NOTES_PREFIX}${schoolId}`;

  const deliverLocal = (e?: any) => {
    if (!active) return;
    if (e?.detail?.schoolId && e.detail.schoolId !== schoolId) return;
    callback(getLocalSchoolCurriculumNotes(schoolId));
  };
  deliverLocal();

  whenSchoolIdbReady()
    .then(async () => {
      if (!active) return;
      const local = getLocalSchoolCurriculumNotes(schoolId);
      callback(local);
      const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, "curriculum_notes", cacheKey, () => local.length > 0, 15 * 60 * 1000);
      if (!shouldFetch || !active) return;
      const notes = await dedupInflight(`curriculum_notes:${schoolId}`, async () => {
        if (db) {
          try {
            const snap = await withTimeout(getDocs(col(`schools/${schoolId}/curriculum_notes`)), 2500);
            const list = snap.docs.map(dSnap => ({ ...dSnap.data(), id: dSnap.id }));
            if (list.length > 0 || !rtdb) {
              setLocalSchoolCurriculumNotes(schoolId, list);
              markSchoolCacheFresh(cacheKey, remoteVer);
              return list;
            }
          } catch {}
        }
        if (rtdb) {
          try {
            const rSnap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/curriculum_notes`)), 2000);
            const val = (rSnap as any)?.val?.();
            if (val && typeof val === "object") {
              const list = Object.entries(val).map(([id, data]: [string, any]) => ({ ...(data || {}), id: data?.id || id }));
              setLocalSchoolCurriculumNotes(schoolId, list);
              markSchoolCacheFresh(cacheKey, remoteVer);
              return list;
            }
          } catch {}
        }
        return local;
      });
      if (active) callback(notes);
    })
    .catch(() => {});

  if (typeof window !== 'undefined') {
    window.addEventListener('school-idb-hydrated', deliverLocal);
    window.addEventListener('nst-school-curriculum-notes-updated', deliverLocal);
  }

  return () => {
    active = false;
    if (typeof window !== 'undefined') {
      window.removeEventListener('school-idb-hydrated', deliverLocal);
      window.removeEventListener('nst-school-curriculum-notes-updated', deliverLocal);
    }
  };
};

// ─────────────────────────────────────────────────────────────────────────────
// TEACHER RULES & PAYROLL POLICY CONFIGURATION (LIFE MAKER RULES ENGINE)
// ─────────────────────────────────────────────────────────────────────────────
const LOCAL_TEACHER_RULES_KEY = (schoolId: string) => `nst_teacher_rules_${schoolId}`;
const LOCAL_TEACHER_RULES_ACK_KEY = (schoolId: string) => `nst_teacher_rules_ack_${schoolId}`;
const LOCAL_MONTHLY_POLICY_ADJ_KEY = (schoolId: string, yearMonth: string) =>
  `nst_payroll_policy_adj_${schoolId}_${yearMonth}`;

export const getTeacherRulesConfig = async (
  schoolId: string,
  school?: import('./school-types').School | null
): Promise<import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig> => {
  await whenSchoolIdbReady();
  const { getDefaultTeacherRulesConfig } = await import('./utils/schoolTeacherRules');
  const cacheKey = LOCAL_TEACHER_RULES_KEY(schoolId);
  const fallback = getSchoolCacheSync<import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig | null>(
    cacheKey,
    null
  );

  const hasValidLocal = Boolean(fallback && Array.isArray(fallback.rules));
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(
    schoolId,
    "teacher_rules",
    cacheKey,
    () => hasValidLocal,
    30 * 60 * 1000
  );

  if (!shouldFetch && fallback && Array.isArray(fallback.rules)) {
    const def = getDefaultTeacherRulesConfig(schoolId, school);
    return { ...def, ...fallback, policy: { ...def.policy, ...(fallback.policy || {}) } };
  }

  return dedupInflight(`teacher_rules:${schoolId}`, async () => {
    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDoc(d(`schools/${schoolId}/settings/teacher_rules`)), 2500);
        fsOk = true;
        if (snap.exists()) {
          const val = snap.data() as import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig;
          const def = getDefaultTeacherRulesConfig(schoolId, school);
          const normalized = { ...def, ...val, policy: { ...def.policy, ...(val.policy || {}) } };
          setSchoolCacheSync(cacheKey, normalized);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return normalized;
        }
      } catch {}
    }

    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/teacher_rules_config`)), 2000);
        const val = snap?.val?.();
        if (val && typeof val === "object" && Array.isArray(val.rules)) {
          const def = getDefaultTeacherRulesConfig(schoolId, school);
          const normalized = { ...def, ...val, policy: { ...def.policy, ...(val.policy || {}) } };
          setSchoolCacheSync(cacheKey, normalized);
          markSchoolCacheFresh(cacheKey, remoteVer);
          return normalized;
        }
      } catch {}
    }

    if (fallback && Array.isArray(fallback.rules)) {
      const def = getDefaultTeacherRulesConfig(schoolId, school);
      markSchoolCacheFresh(cacheKey, remoteVer);
      return { ...def, ...fallback, policy: { ...def.policy, ...(fallback.policy || {}) } };
    }

    const def = getDefaultTeacherRulesConfig(schoolId, school);
    setSchoolCacheSync(cacheKey, def);
    markSchoolCacheFresh(cacheKey, remoteVer);
    return def;
  });
};

export const saveTeacherRulesConfig = async (
  schoolId: string,
  config: import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig
): Promise<import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig> => {
  const clean = sanitizeForFirestore({
    ...config,
    schoolId,
    updatedAt: new Date().toISOString(),
  });
  const cacheKey = LOCAL_TEACHER_RULES_KEY(schoolId);
  setSchoolCacheSync(cacheKey, clean);
  markSchoolCacheFresh(cacheKey);

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("teacher-rules-updated", { detail: { schoolId, config: clean } })
    );
  }

  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/teacher_rules_config`), clean), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/settings/teacher_rules`), clean, { merge: true }), 2500);
      void touchSchoolSyncVersion(schoolId, "teacher_rules");
    } catch {}
  }
  return clean;
};

export const subscribeToTeacherRulesConfig = (
  schoolId: string,
  school: import('./school-types').School | null,
  callback: (config: import('./utils/schoolTeacherRules').SchoolTeacherRulesConfig) => void
): (() => void) => {
  let active = true;
  const load = () => {
    getTeacherRulesConfig(schoolId, school)
      .then((cfg) => {
        if (active) callback(cfg);
      })
      .catch(() => {});
  };

  load();

  const handleLocalEvent = (e: any) => {
    if (!active) return;
    if (e?.detail?.schoolId === schoolId && e?.detail?.config) {
      callback(e.detail.config);
    }
  };
  const handleHydrated = () => {
    if (active) load();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("teacher-rules-updated", handleLocalEvent);
    window.addEventListener("school-idb-hydrated", handleHydrated);
  }

  return () => {
    active = false;
    if (typeof window !== "undefined") {
      window.removeEventListener("teacher-rules-updated", handleLocalEvent);
      window.removeEventListener("school-idb-hydrated", handleHydrated);
    }
  };
};

export const getTeacherRuleAcceptances = async (
  schoolId: string
): Promise<Record<string, import('./utils/schoolTeacherRules').TeacherRuleAcceptance>> => {
  await whenSchoolIdbReady();
  const cacheKey = LOCAL_TEACHER_RULES_ACK_KEY(schoolId);
  const local = getSchoolCacheSync<Record<string, import('./utils/schoolTeacherRules').TeacherRuleAcceptance>>(
    cacheKey,
    {}
  );
  const hasLocal = Boolean(local && Object.keys(local).length > 0);
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, "teacher_rules_ack", cacheKey, () => hasLocal, 15 * 60 * 1000);
  if (!shouldFetch) return local || {};

  return dedupInflight(`teacher_rules_ack:${schoolId}`, async () => {
    const merged: Record<string, import('./utils/schoolTeacherRules').TeacherRuleAcceptance> = { ...(local || {}) };
    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDocs(col(`schools/${schoolId}/teacher_rules_acceptances`)), 2500);
        fsOk = true;
        snap.docs.forEach((docSnap) => {
          const dObj = docSnap.data() as import('./utils/schoolTeacherRules').TeacherRuleAcceptance;
          if (dObj?.staffId) merged[dObj.staffId] = dObj;
        });
      } catch {}
    }
    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/teacher_rules_acceptances`)), 2000);
        const val = snap?.val?.();
        if (val && typeof val === "object") {
          Object.assign(merged, val);
        }
      } catch {}
    }
    setSchoolCacheSync(cacheKey, merged);
    markSchoolCacheFresh(cacheKey, remoteVer);
    return merged;
  });
};

export const saveTeacherRuleAcceptance = async (
  schoolId: string,
  acceptance: import('./utils/schoolTeacherRules').TeacherRuleAcceptance
): Promise<Record<string, import('./utils/schoolTeacherRules').TeacherRuleAcceptance>> => {
  const cacheKey = LOCAL_TEACHER_RULES_ACK_KEY(schoolId);
  const current = getSchoolCacheSync<Record<string, import('./utils/schoolTeacherRules').TeacherRuleAcceptance>>(
    cacheKey,
    {}
  );
  const clean = sanitizeForFirestore({
    ...acceptance,
    schoolId,
    acceptedAt: acceptance.acceptedAt || new Date().toISOString(),
  });
  const next = { ...(current || {}), [clean.staffId]: clean };
  setSchoolCacheSync(cacheKey, next);
  markSchoolCacheFresh(cacheKey);

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("teacher-rules-ack-updated", { detail: { schoolId, acceptances: next } })
    );
  }
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/teacher_rules_acceptances/${clean.staffId}`), clean), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/teacher_rules_acceptances/${clean.staffId}`), clean, { merge: true }), 2500);
      void touchSchoolSyncVersion(schoolId, "teacher_rules_ack");
    } catch {}
  }
  return next;
};

export const getMonthlyPolicyAdjustments = async (
  schoolId: string,
  yearMonth: string
): Promise<Record<string, import('./utils/schoolTeacherRules').StaffMonthlyPolicyAdjustments>> => {
  await whenSchoolIdbReady();
  const cacheKey = LOCAL_MONTHLY_POLICY_ADJ_KEY(schoolId, yearMonth);
  const local = getSchoolCacheSync<Record<string, import('./utils/schoolTeacherRules').StaffMonthlyPolicyAdjustments>>(
    cacheKey,
    {}
  );
  const hasLocal = Boolean(local && Object.keys(local).length > 0);
  const domainKey = `payroll_adj_${yearMonth}`;
  const { fetch: shouldFetch, remoteVer } = await shouldFetchDomainFromCloud(schoolId, domainKey, cacheKey, () => hasLocal, 15 * 60 * 1000);
  if (!shouldFetch) return local || {};

  return dedupInflight(`payroll_adj:${schoolId}:${yearMonth}`, async () => {
    const merged = { ...(local || {}) };
    let fsOk = false;
    if (db) {
      try {
        const snap = await withTimeout(getDoc(d(`schools/${schoolId}/payroll_policy_adj/${yearMonth}`)), 2500);
        fsOk = true;
        if (snap.exists()) {
          const data = snap.data() as Record<string, any>;
          if (data && typeof data === "object") Object.assign(merged, data);
        }
      } catch {}
    }
    if (!fsOk && rtdb) {
      try {
        const snap = await withTimeout(get(ref(rtdb, `schools/${schoolId}/payroll_policy_adj/${yearMonth}`)), 2000);
        const val = snap?.val?.();
        if (val && typeof val === "object") Object.assign(merged, val);
      } catch {}
    }
    setSchoolCacheSync(cacheKey, merged);
    markSchoolCacheFresh(cacheKey, remoteVer);
    return merged;
  });
};

export const saveStaffMonthlyPolicyAdjustment = async (
  schoolId: string,
  yearMonth: string,
  staffId: string,
  adjustment: import('./utils/schoolTeacherRules').StaffMonthlyPolicyAdjustments
): Promise<Record<string, import('./utils/schoolTeacherRules').StaffMonthlyPolicyAdjustments>> => {
  const cacheKey = LOCAL_MONTHLY_POLICY_ADJ_KEY(schoolId, yearMonth);
  const current = getSchoolCacheSync<Record<string, import('./utils/schoolTeacherRules').StaffMonthlyPolicyAdjustments>>(
    cacheKey,
    {}
  );
  const clean = sanitizeForFirestore({
    lateDays: Math.max(0, Number(adjustment.lateDays) || 0),
    dressViolationDays: Math.max(0, Number(adjustment.dressViolationDays) || 0),
    lateEmergencyExcused: Boolean(adjustment.lateEmergencyExcused),
    bonusWaived: Boolean(adjustment.bonusWaived),
    updatedAt: new Date().toISOString(),
  });
  const next = { ...(current || {}), [staffId]: clean };
  setSchoolCacheSync(cacheKey, next);
  markSchoolCacheFresh(cacheKey);

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("payroll-policy-adjustments-updated", { detail: { schoolId, yearMonth, next } })
    );
  }
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/payroll_policy_adj/${yearMonth}/${staffId}`), clean), 2000);
    } catch {}
  }
  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/payroll_policy_adj/${yearMonth}`), { [staffId]: clean }, { merge: true }), 2500);
      void touchSchoolSyncVersion(schoolId, `payroll_adj_${yearMonth}`);
    } catch {}
  }
  return next;
};

// Backward-compatible exports used by offlineSyncService replay queue
export const saveAttendanceDirectCloud = saveAttendance;
export const replayOfflineStudentAttendancePunch = (payload: any) => markStudentQrAttendance(payload);
export const replayOfflineStaffAttendancePunch = (payload: any) => markStaffAttendanceAtomic(payload);

// ── FEE TAGADA OFFLINE CALLER & PROMISE-DATE FOLLOW-UP SYNC ─────────────────
const FEE_FOLLOWUPS_CACHE_KEY = (schoolId: string) => `nst_school_fee_followups_${schoolId}`;
const FEE_FOLLOWUPS_DIRTY_KEY = (schoolId: string) => `nst_school_fee_followups_dirty_${schoolId}`;

const getDirtyFeeFollowUpIds = (schoolId: string): string[] => {
  try {
    const raw = localStorage.getItem(FEE_FOLLOWUPS_DIRTY_KEY(schoolId));
    if (!raw) return [];
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((x) => typeof x === "string") : [];
  } catch {
    return [];
  }
};

const setDirtyFeeFollowUpIds = (schoolId: string, ids: string[]) => {
  try {
    const uniq = Array.from(new Set(ids.filter(Boolean)));
    if (uniq.length === 0) {
      localStorage.removeItem(FEE_FOLLOWUPS_DIRTY_KEY(schoolId));
    } else {
      localStorage.setItem(FEE_FOLLOWUPS_DIRTY_KEY(schoolId), JSON.stringify(uniq));
    }
  } catch {}
};

export const getLocalFeeCallFollowUps = (schoolId: string): FeeCallFollowUpRecord[] => {
  if (!schoolId) return [];
  const list = getSchoolCacheSync<FeeCallFollowUpRecord[]>(FEE_FOLLOWUPS_CACHE_KEY(schoolId), []);
  return Array.isArray(list) ? list : [];
};

export const getPendingFeeFollowUpSyncCount = (schoolId: string): number => {
  if (!schoolId) return 0;
  return getDirtyFeeFollowUpIds(schoolId).length;
};

const writeFeeFollowUpToCloud = async (clean: FeeCallFollowUpRecord): Promise<boolean> => {
  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    return false;
  }
  let ok = false;
  if (db) {
    try {
      await withTimeout(
        setDoc(d(`schools/${clean.schoolId}/fee_call_followups/${clean.studentId}`), clean, { merge: true }),
        3500
      );
      ok = true;
    } catch {}
  }
  if (rtdb) {
    try {
      await withTimeout(
        set(ref(rtdb, `schools/${clean.schoolId}/fee_call_followups/${clean.studentId}`), clean),
        2500
      );
      ok = true;
    } catch {}
  }
  return ok;
};

export const saveFeeCallFollowUp = async (
  record: FeeCallFollowUpRecord
): Promise<{ synced: boolean }> => {
  if (!record?.schoolId || !record?.studentId) return { synced: false };
  const clean: FeeCallFollowUpRecord = sanitizeForFirestore({
    ...record,
    id: record.studentId,
    updatedAt: record.updatedAt || new Date().toISOString(),
  });

  // 1. Always save locally first so offline calls & schedules are 100% preserved
  const cacheKey = FEE_FOLLOWUPS_CACHE_KEY(clean.schoolId);
  const current = getLocalFeeCallFollowUps(clean.schoolId);
  const next = [clean, ...current.filter((item) => item?.studentId !== clean.studentId)];
  setSchoolCacheSync(cacheKey, next);

  const dirtyBefore = getDirtyFeeFollowUpIds(clean.schoolId);
  setDirtyFeeFollowUpIds(clean.schoolId, [...dirtyBefore, clean.studentId]);

  if (typeof window !== "undefined") {
    window.dispatchEvent(
      new CustomEvent("fee-call-followups-updated", { detail: { schoolId: clean.schoolId, record: clean } })
    );
  }

  // 2. Attempt cloud write; if offline, remains queued in dirty list for auto-replay
  const synced = await writeFeeFollowUpToCloud(clean);
  if (synced) {
    const remainingDirty = getDirtyFeeFollowUpIds(clean.schoolId).filter((id) => id !== clean.studentId);
    setDirtyFeeFollowUpIds(clean.schoolId, remainingDirty);
    if (typeof window !== "undefined") {
      window.dispatchEvent(
        new CustomEvent("fee-call-followups-updated", { detail: { schoolId: clean.schoolId } })
      );
    }
  }
  return { synced };
};

export const syncPendingFeeCallFollowUps = async (schoolId: string): Promise<number> => {
  if (!schoolId) return 0;
  if (typeof navigator !== "undefined" && navigator.onLine === false) return 0;
  const dirtyIds = getDirtyFeeFollowUpIds(schoolId);
  if (dirtyIds.length === 0) return 0;

  const localMap = new Map(getLocalFeeCallFollowUps(schoolId).map((r) => [r.studentId, r]));
  const stillDirty: string[] = [];
  let syncedCount = 0;

  for (const stuId of dirtyIds) {
    const rec = localMap.get(stuId);
    if (!rec) continue;
    const ok = await writeFeeFollowUpToCloud(rec);
    if (ok) syncedCount++;
    else stillDirty.push(stuId);
  }

  setDirtyFeeFollowUpIds(schoolId, stillDirty);
  if (syncedCount > 0 && typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("fee-call-followups-updated", { detail: { schoolId } }));
  }
  return syncedCount;
};

export const saveFeeCallFollowUpBatch = async (
  records: FeeCallFollowUpRecord[]
): Promise<{ syncedCount: number; total: number }> => {
  const valid = records.filter((r) => Boolean(r?.schoolId && r?.studentId));
  if (valid.length === 0) return { syncedCount: 0, total: 0 };

  let syncedCount = 0;
  // Group by schoolId for atomic local cache update
  const bySchool = new Map<string, FeeCallFollowUpRecord[]>();
  for (const r of valid) {
    const clean = sanitizeForFirestore({
      ...r,
      id: r.studentId,
      updatedAt: r.updatedAt || new Date().toISOString(),
    });
    const arr = bySchool.get(clean.schoolId) || [];
    arr.push(clean);
    bySchool.set(clean.schoolId, arr);
  }

  for (const [schId, items] of bySchool.entries()) {
    const cacheKey = FEE_FOLLOWUPS_CACHE_KEY(schId);
    const current = getLocalFeeCallFollowUps(schId);
    const itemMap = new Map(current.map((c) => [c.studentId, c]));
    for (const clean of items) {
      itemMap.set(clean.studentId, clean);
    }
    setSchoolCacheSync(cacheKey, Array.from(itemMap.values()));

    const dirtyBefore = getDirtyFeeFollowUpIds(schId);
    const dirtySet = new Set([...dirtyBefore, ...items.map((it) => it.studentId)]);
    setDirtyFeeFollowUpIds(schId, Array.from(dirtySet));

    if (typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("fee-call-followups-updated", { detail: { schoolId: schId } }));
    }

    for (const clean of items) {
      const ok = await writeFeeFollowUpToCloud(clean);
      if (ok) {
        syncedCount++;
        dirtySet.delete(clean.studentId);
      }
    }
    setDirtyFeeFollowUpIds(schId, Array.from(dirtySet));
    if (syncedCount > 0 && typeof window !== "undefined") {
      window.dispatchEvent(new CustomEvent("fee-call-followups-updated", { detail: { schoolId: schId } }));
    }
  }

  return { syncedCount, total: valid.length };
};

export const autoSettleFeeCallFollowUp = async (
  schoolId: string,
  studentId: string,
  opts?: {
    receiptNo?: string;
    amountPaid?: number;
    remainingDue?: number;
    actorName?: string;
    studentName?: string;
    fatherName?: string;
    classId?: string;
    className?: string;
    rollNo?: string;
    phone?: string;
  }
): Promise<void> => {
  if (!schoolId || !studentId) return;
  const remainingDue = Math.max(0, Number(opts?.remainingDue ?? 0));
  const local = getLocalFeeCallFollowUps(schoolId);
  const existing = local.find((r) => r.studentId === studentId);
  const nowIso = new Date().toISOString();

  if (remainingDue <= 0) {
    if (!existing) {
      // Only create a compact settled record if this student actually paid via receipt
      if (!opts?.receiptNo && !(opts?.amountPaid && opts.amountPaid > 0)) return;
      const fresh: FeeCallFollowUpRecord = {
        id: studentId,
        schoolId,
        studentId,
        studentName: opts?.studentName || "Student",
        fatherName: opts?.fatherName || "",
        classId: opts?.classId || "",
        className: opts?.className || "",
        rollNo: opts?.rollNo || "",
        phone: opts?.phone || "",
        settled: true,
        settledAt: nowIso,
        settledReceiptNo: opts?.receiptNo,
        settledAmount: opts?.amountPaid,
        settledBy: opts?.actorName,
        totalCallsCount: 0,
        callHistory: [],
        updatedAt: nowIso,
      };
      await saveFeeCallFollowUp(fresh);
      return;
    }

    const updated: FeeCallFollowUpRecord = {
      ...existing,
      studentName: opts?.studentName || existing.studentName,
      fatherName: opts?.fatherName ?? existing.fatherName,
      classId: opts?.classId || existing.classId,
      className: opts?.className || existing.className,
      rollNo: opts?.rollNo ?? existing.rollNo,
      phone: opts?.phone || existing.phone,
      settled: true,
      settledAt: nowIso,
      settledReceiptNo: opts?.receiptNo || existing.settledReceiptNo,
      settledAmount: opts?.amountPaid ?? existing.settledAmount,
      settledBy: opts?.actorName || existing.settledBy,
      nextCallDate: undefined,
      updatedAt: nowIso,
    };
    await saveFeeCallFollowUp(updated);
  } else if (existing && existing.settled) {
    // Re-open if a partial payment or reversal left balance due
    const reopened: FeeCallFollowUpRecord = {
      ...existing,
      settled: false,
      settledAt: undefined,
      updatedAt: nowIso,
    };
    await saveFeeCallFollowUp(reopened);
  }
};

export const subscribeToFeeCallFollowUps = (
  schoolId: string,
  cb: (records: FeeCallFollowUpRecord[]) => void
): (() => void) => {
  if (!schoolId) {
    cb([]);
    return () => {};
  }
  const cacheKey = FEE_FOLLOWUPS_CACHE_KEY(schoolId);
  let disposed = false;

  const emitLocal = () => {
    if (disposed) return;
    const list = getLocalFeeCallFollowUps(schoolId);
    cb([...list].sort((a, b) => (b.updatedAt || "").localeCompare(a.updatedAt || "")));
  };

  emitLocal();
  whenSchoolIdbReady().then(() => { if (!disposed) emitLocal(); }).catch(() => {});
  void syncPendingFeeCallFollowUps(schoolId);

  const onCustomUpdate = (e: any) => {
    if (!e?.detail?.schoolId || e.detail.schoolId === schoolId) emitLocal();
  };
  const onOnline = () => {
    void syncPendingFeeCallFollowUps(schoolId);
  };

  if (typeof window !== "undefined") {
    window.addEventListener("fee-call-followups-updated", onCustomUpdate);
    window.addEventListener("school-idb-hydrated", emitLocal);
    window.addEventListener("online", onOnline);
  }

  let unsubFs = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/fee_call_followups`), orderBy("updatedAt", "desc"), limit(500));
      unsubFs = onSnapshot(qFs, (snap) => {
        if (disposed) return;
        const remoteList = snap.docs.map((docSnap) => docSnap.data() as FeeCallFollowUpRecord);
        const dirtySet = new Set(getDirtyFeeFollowUpIds(schoolId));
        const localCur = getLocalFeeCallFollowUps(schoolId);
        const mergedMap = new Map<string, FeeCallFollowUpRecord>();

        for (const r of remoteList) {
          if (r?.studentId) mergedMap.set(r.studentId, r);
        }
        // Preserve dirty offline updates or newer local updates
        for (const loc of localCur) {
          if (!loc?.studentId) continue;
          const rem = mergedMap.get(loc.studentId);
          if (dirtySet.has(loc.studentId) || !rem || (loc.updatedAt || "").localeCompare(rem.updatedAt || "") > 0) {
            mergedMap.set(loc.studentId, loc);
          }
        }
        setSchoolCacheSync(cacheKey, Array.from(mergedMap.values()));
        emitLocal();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (typeof window !== "undefined") {
      window.removeEventListener("fee-call-followups-updated", onCustomUpdate);
      window.removeEventListener("school-idb-hydrated", emitLocal);
      window.removeEventListener("online", onOnline);
    }
    unsubFs();
  };
};

// ── MATCHED SCHOOL SIM CALL LOGS (INCOMING + OUTGOING DIALER SYNC) ────────────
const SIM_CALL_LOGS_CACHE_KEY = (schoolId: string) => `nst_sim_call_logs_v1_${schoolId}`;

export const getLocalSchoolSimCallLogs = (schoolId: string): SimCallLogRecord[] => {
  if (!schoolId) return [];
  const list = getSchoolCacheSync<SimCallLogRecord[]>(SIM_CALL_LOGS_CACHE_KEY(schoolId), []);
  return Array.isArray(list) ? list : [];
};

export const saveMatchedSimCallLogsBatch = async (
  schoolId: string,
  records: SimCallLogRecord[]
): Promise<number> => {
  if (!schoolId || !Array.isArray(records) || records.length === 0) return 0;
  const cleanRecords = records
    .filter((r) => Boolean(r?.id && r?.phone && r?.callDateMs))
    .map((r) =>
      sanitizeForFirestore({
        ...r,
        schoolId,
        syncedAt: r.syncedAt || new Date().toISOString(),
      }) as SimCallLogRecord
    );
  if (cleanRecords.length === 0) return 0;

  const existing = getLocalSchoolSimCallLogs(schoolId);
  const byId = new Map<string, SimCallLogRecord>();
  for (const item of existing) {
    if (item?.id) byId.set(item.id, item);
  }
  let addedOrUpdated = 0;
  for (const item of cleanRecords) {
    const prev = byId.get(item.id);
    if (!prev || prev.durationSec !== item.durationSec || prev.callType !== item.callType) {
      addedOrUpdated++;
    }
    byId.set(item.id, item);
  }
  const merged = Array.from(byId.values())
    .sort((a, b) => Number(b.callDateMs || 0) - Number(a.callDateMs || 0))
    .slice(0, 150);
  setSchoolCacheSync(SIM_CALL_LOGS_CACHE_KEY(schoolId), merged);

  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("school-sim-call-logs-updated", { detail: { schoolId } }));
  }

  if (typeof navigator !== "undefined" && navigator.onLine === false) {
    return addedOrUpdated;
  }

  for (const rec of cleanRecords.slice(0, 25)) {
    if (db) {
      try {
        await withTimeout(setDoc(d(`schools/${schoolId}/sim_call_logs/${rec.id}`), rec, { merge: true }), 3000);
      } catch {}
    }
    if (rtdb) {
      try {
        await withTimeout(set(ref(rtdb, `schools/${schoolId}/sim_call_logs/${rec.id}`), rec), 2500);
      } catch {}
    }
  }
  return addedOrUpdated;
};

export const subscribeSchoolSimCallLogs = (
  schoolId: string,
  onData: (logs: SimCallLogRecord[]) => void
): (() => void) => {
  if (!schoolId) {
    onData([]);
    return () => {};
  }
  let disposed = false;
  const emitLocal = () => {
    if (disposed) return;
    const sorted = [...getLocalSchoolSimCallLogs(schoolId)].sort(
      (a, b) => Number(b.callDateMs || 0) - Number(a.callDateMs || 0)
    );
    onData(sorted);
  };
  emitLocal();

  const onCustomUpdate = (e: Event) => {
    const detail = (e as CustomEvent)?.detail;
    if (!detail?.schoolId || detail.schoolId === schoolId) emitLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("school-sim-call-logs-updated", onCustomUpdate);
    window.addEventListener("school-idb-hydrated", emitLocal);
  }

  let unsubFs = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/sim_call_logs`), orderBy("callDateMs", "desc"), limit(120));
      unsubFs = onSnapshot(qFs, (snap) => {
        if (disposed) return;
        const remoteList = snap.docs.map((docSnap) => docSnap.data() as SimCallLogRecord);
        const localCur = getLocalSchoolSimCallLogs(schoolId);
        const mergedMap = new Map<string, SimCallLogRecord>();
        for (const r of remoteList) {
          if (r?.id) mergedMap.set(r.id, r);
        }
        for (const loc of localCur) {
          if (loc?.id && !mergedMap.has(loc.id)) mergedMap.set(loc.id, loc);
        }
        const merged = Array.from(mergedMap.values())
          .sort((a, b) => Number(b.callDateMs || 0) - Number(a.callDateMs || 0))
          .slice(0, 150);
        setSchoolCacheSync(SIM_CALL_LOGS_CACHE_KEY(schoolId), merged);
        emitLocal();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (typeof window !== "undefined") {
      window.removeEventListener("school-sim-call-logs-updated", onCustomUpdate);
      window.removeEventListener("school-idb-hydrated", emitLocal);
    }
    unsubFs();
  };
};

// ── UPI SCREENSHOT PAYMENT PROOF & 1-CLICK APPROVAL SYSTEM ──────────────────
const UPI_PROOFS_CACHE_KEY = (schoolId: string) => `nst_upi_proofs_${schoolId}`;

export const getLocalUpiProofs = (schoolId: string): UpiPaymentProofRecord[] => {
  if (!schoolId) return [];
  try {
    const raw = getSchoolCacheSync<UpiPaymentProofRecord[]>(UPI_PROOFS_CACHE_KEY(schoolId), []);
    if (Array.isArray(raw)) return raw;
  } catch {}
  return [];
};

export const setLocalUpiProofs = (schoolId: string, proofs: UpiPaymentProofRecord[]) => {
  if (!schoolId) return;
  try {
    setSchoolCacheSync(UPI_PROOFS_CACHE_KEY(schoolId), Array.isArray(proofs) ? proofs : []);
  } catch {}
};

export const normalizeUpiUtr = (val: string): string =>
  String(val || "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "");

export const saveUpiPaymentProof = async (
  proof: UpiPaymentProofRecord
): Promise<{ ok: boolean; error?: string; record?: UpiPaymentProofRecord }> => {
  const schoolId = proof.schoolId;
  if (!schoolId) return { ok: false, error: "School ID missing." };
  const cleanUtr = normalizeUpiUtr(proof.utrNumber);
  if (cleanUtr.length < 6) {
    return { ok: false, error: "Kripya kam se kam 6 anko ka sahi UTR / Transaction ID darj karein." };
  }
  const existingList = getLocalUpiProofs(schoolId);
  const duplicate = existingList.find(
    (p) =>
      p.id !== proof.id &&
      normalizeUpiUtr(p.utrNumber) === cleanUtr &&
      (p.status === "PENDING" || p.status === "APPROVED")
  );
  if (duplicate) {
    return {
      ok: false,
      error: `Yeh UTR (${cleanUtr}) pehle se ${duplicate.studentName} ke liye darj hai (Duplicate UTR).`,
    };
  }

  let finalScreenshotUrl = proof.screenshotUrl || "";
  if (finalScreenshotUrl.startsWith("data:image/")) {
    try {
      finalScreenshotUrl = await ensureCloudImageUrl(finalScreenshotUrl, `upi_proof_${schoolId}_${proof.id}`);
    } catch {
      // Keep compressed dataURL fallback if cloud image upload is unavailable
    }
  }

  const cleanRec: UpiPaymentProofRecord = sanitizeForFirestore({
    ...proof,
    utrNumber: cleanUtr,
    screenshotUrl: finalScreenshotUrl,
    status: proof.status || "PENDING",
    submittedAt: proof.submittedAt || new Date().toISOString(),
    createdAt: proof.createdAt || new Date().toISOString(),
  });

  const nextList = [cleanRec, ...existingList.filter((x) => x.id !== cleanRec.id)].slice(0, 300);
  setLocalUpiProofs(schoolId, nextList);
  markSchoolCacheFresh(UPI_PROOFS_CACHE_KEY(schoolId));
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("upi-proofs-updated", { detail: { schoolId } }));
  }

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/upi_proofs/${cleanRec.id}`), cleanRec, { merge: true }), 3000);
    } catch {}
  }
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/upi_proofs/${cleanRec.id}`), cleanRec), 2500);
    } catch {}
  }
  return { ok: true, record: cleanRec };
};

export const subscribeSchoolUpiProofs = (
  schoolId: string,
  onData: (proofs: UpiPaymentProofRecord[]) => void
): (() => void) => {
  if (!schoolId) {
    onData([]);
    return () => {};
  }
  let disposed = false;
  const emitLocal = () => {
    if (disposed) return;
    const sorted = [...getLocalUpiProofs(schoolId)].sort((a, b) =>
      String(b.submittedAt || "").localeCompare(String(a.submittedAt || ""))
    );
    onData(sorted);
  };
  emitLocal();

  const onEvt = (e: Event) => {
    const detail = (e as CustomEvent)?.detail;
    if (!detail?.schoolId || detail.schoolId === schoolId) emitLocal();
  };
  if (typeof window !== "undefined") {
    window.addEventListener("upi-proofs-updated", onEvt);
    window.addEventListener("school-idb-hydrated", emitLocal);
  }

  let unsubFs = () => {};
  if (db) {
    try {
      const qFs = query(col(`schools/${schoolId}/upi_proofs`), orderBy("submittedAt", "desc"), limit(200));
      unsubFs = onSnapshot(qFs, (snap) => {
        if (disposed) return;
        const remoteList = snap.docs.map((docSnap) => docSnap.data() as UpiPaymentProofRecord);
        const localCur = getLocalUpiProofs(schoolId);
        const mergedMap = new Map<string, UpiPaymentProofRecord>();
        for (const r of remoteList) {
          if (r?.id) mergedMap.set(r.id, r);
        }
        for (const loc of localCur) {
          if (loc?.id && !mergedMap.has(loc.id)) mergedMap.set(loc.id, loc);
        }
        const merged = Array.from(mergedMap.values())
          .sort((a, b) => String(b.submittedAt || "").localeCompare(String(a.submittedAt || "")))
          .slice(0, 300);
        setLocalUpiProofs(schoolId, merged);
        emitLocal();
      });
    } catch {}
  }

  return () => {
    disposed = true;
    if (typeof window !== "undefined") {
      window.removeEventListener("upi-proofs-updated", onEvt);
      window.removeEventListener("school-idb-hydrated", emitLocal);
    }
    unsubFs();
  };
};

export const approveUpiPaymentProof = async (params: {
  schoolId: string;
  proof: UpiPaymentProofRecord;
  approverName: string;
  approverRole: "accountant" | "manager";
}): Promise<{ receiptNo: string; fee: MonthlyFee; proof: UpiPaymentProofRecord }> => {
  const { schoolId, proof, approverName, approverRole } = params;
  const nowIso = new Date().toISOString();
  const receiptNo = `UPI-${Date.now().toString().slice(-6)}`;

  const existingFees = getLocalFees(schoolId);
  const existing = existingFees.find(
    (f) => f.studentId === proof.studentId && f.month === proof.month
  );
  const billed = Number(existing?.monthlyAmount ?? existing?.amount ?? proof.amount);
  const prevPaid = existing?.paid
    ? Number(existing?.paidAmount ?? billed)
    : Number(existing?.paidAmount ?? 0);
  const payAmt = Math.max(0, Number(proof.amount) || 0);
  const newPaidTotal = existing?.paid ? prevPaid : prevPaid + payAmt;
  const newBalance = Math.max(0, billed - newPaidTotal);

  const feeRecord: MonthlyFee = {
    ...(existing || {}),
    schoolId,
    sessionId: proof.sessionId || existing?.sessionId || "",
    studentId: proof.studentId,
    studentName: proof.studentName,
    rollNo: proof.rollNo || existing?.rollNo || "",
    classId: proof.classId,
    className: proof.className || existing?.className,
    month: proof.month,
    amount: billed,
    monthlyAmount: billed,
    paid: newBalance <= 0,
    status: newBalance <= 0 ? "Paid" : "Partial",
    paidDate: nowIso,
    paidBy: approverName,
    collectedBy: `${approverRole === "accountant" ? "Accountant" : "Admin"} (${approverName})`,
    collectedByRole: approverRole,
    collectedByName: approverName,
    receiptNo,
    paymentMode: "online_upi",
    paidAmount: newPaidTotal,
    lastPaidAmount: payAmt,
    lastReceiptPaidAmount: payAmt,
    lastPaidDate: nowIso,
    balanceDue: newBalance,
    updatedAt: nowIso,
    payModeInfo: {
      payMode: "UPI QR (Verified)",
      date: nowIso.slice(0, 10),
      bank: "School UPI",
      number: proof.utrNumber,
      onlineAmount: payAmt,
      offlineAmount: 0,
    },
    note: proof.note
      ? `UPI UTR: ${proof.utrNumber} · ${proof.note}`
      : `UPI UTR: ${proof.utrNumber}`,
  };

  await saveFee(feeRecord);

  const updatedProof: UpiPaymentProofRecord = sanitizeForFirestore({
    ...proof,
    status: "APPROVED",
    reviewedAt: nowIso,
    reviewedBy: approverName,
    receiptNo,
  });

  const nextProofs = [
    updatedProof,
    ...getLocalUpiProofs(schoolId).filter((x) => x.id !== updatedProof.id),
  ];
  setLocalUpiProofs(schoolId, nextProofs);
  markSchoolCacheFresh(UPI_PROOFS_CACHE_KEY(schoolId));
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("upi-proofs-updated", { detail: { schoolId } }));
  }

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/upi_proofs/${updatedProof.id}`), updatedProof, { merge: true }), 3000);
    } catch {}
  }
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/upi_proofs/${updatedProof.id}`), updatedProof), 2500);
    } catch {}
  }

  autoSettleFeeCallFollowUp(schoolId, proof.studentId, {
    receiptNo,
    amountPaid: payAmt,
    remainingDue: newBalance,
    actorName: approverName,
    studentName: proof.studentName,
    fatherName: proof.fatherName,
    classId: proof.classId,
    className: proof.className,
    rollNo: proof.rollNo,
    phone: proof.phone,
  }).catch(() => {});

  autoSendFeeSlipToSchoolDesk({
    schoolId,
    studentId: proof.studentId,
    studentName: proof.studentName,
    slipType: "FEE_RECEIPT",
    month: proof.month,
    monthLabel: proof.monthLabel || proof.month,
    amount: payAmt,
    balanceDue: newBalance,
    receiptNo,
    dueDate: nowIso.slice(0, 10),
  }).catch(() => {});

  return { receiptNo, fee: feeRecord, proof: updatedProof };
};

export const rejectUpiPaymentProof = async (params: {
  schoolId: string;
  proofId: string;
  reason: string;
  reviewerName: string;
}): Promise<UpiPaymentProofRecord | null> => {
  const { schoolId, proofId, reason, reviewerName } = params;
  const list = getLocalUpiProofs(schoolId);
  const existing = list.find((p) => p.id === proofId);
  if (!existing) return null;

  const updatedProof: UpiPaymentProofRecord = sanitizeForFirestore({
    ...existing,
    status: "REJECTED",
    rejectionReason: String(reason || "Payment verify nahi hua").trim(),
    reviewedAt: new Date().toISOString(),
    reviewedBy: reviewerName,
  });

  setLocalUpiProofs(
    schoolId,
    list.map((p) => (p.id === proofId ? updatedProof : p))
  );
  markSchoolCacheFresh(UPI_PROOFS_CACHE_KEY(schoolId));
  if (typeof window !== "undefined") {
    window.dispatchEvent(new CustomEvent("upi-proofs-updated", { detail: { schoolId } }));
  }

  if (db) {
    try {
      await withTimeout(setDoc(d(`schools/${schoolId}/upi_proofs/${proofId}`), updatedProof, { merge: true }), 3000);
    } catch {}
  }
  if (rtdb) {
    try {
      await withTimeout(set(ref(rtdb, `schools/${schoolId}/upi_proofs/${proofId}`), updatedProof), 2500);
    } catch {}
  }

  return updatedProof;
};
