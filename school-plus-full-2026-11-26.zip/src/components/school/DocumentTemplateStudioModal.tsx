// @ts-nocheck
import React, { useState, useMemo, useEffect } from "react";
import {
  Palette,
  Plus,
  CheckCircle2,
  RotateCcw,
  Trash2,
  Sparkles,
  X,
  ChevronLeft,
  Save,
  Layers,
  ShieldCheck,
  LayoutTemplate,
  Search,
} from "lucide-react";
import { toast } from "sonner";
import type { School } from "../../school-types";
import {
  type DocumentTemplateType,
  type DocumentTemplateConfig,
  type TemplatePalette,
  type TemplateLayoutVariant,
  type TemplateCategory,
  DOC_TYPE_META,
  LAYOUT_VARIANT_META,
  getTemplatesForType,
  resolveActiveDocumentTemplate,
  setActiveTemplateForSchool,
  saveTemplateColorOverride,
  resetTemplateColors,
  saveCustomTemplate,
  deleteCustomTemplate,
  loadSchoolDocumentTemplatesState,
} from "../../utils/schoolDocumentTemplates";
import { DocumentStudioRealPreview } from "./DocumentStudioRealPreview";

interface Props {
  school: Partial<School> & { id?: string; name?: string };
  initialDocType?: DocumentTemplateType;
  asPage?: boolean;
  onClose?: () => void;
  onBack?: () => void;
  onSchoolUpdated?: (patch: Partial<School>) => void;
  onTemplateApplied?: (docType: DocumentTemplateType, tpl: DocumentTemplateConfig) => void;
}

const COLOR_FIELDS: { key: keyof TemplatePalette; label: string; hint: string }[] = [
  { key: "primaryColor", label: "Header / Main Color", hint: "मुख्य हेडर व टेबल बार" },
  { key: "accentColor", label: "Accent / Highlight", hint: "सब-हेडर व हाइलाइट पट्टी" },
  { key: "headerTextColor", label: "Header Text Color", hint: "हेडर के ऊपर लिखावट का रंग" },
  { key: "borderColor", label: "Border Color", hint: "कार्ड व शीट बॉर्डर" },
  { key: "badgeBg", label: "Badge / Pill BG", hint: "बैज व टैग बैकग्राउंड" },
  { key: "badgeText", label: "Badge Text Color", hint: "बैज अक्षरों का रंग" },
  { key: "surfaceTint", label: "Soft Surface Tint", hint: "बॉक्स व पट्टी का हल्का रंग" },
];

const CATEGORIES: ("ALL" | TemplateCategory)[] = [
  "ALL",
  "Royal & Heritage",
  "Modern & Tech",
  "Board & Official",
  "Minimal & Print",
  "Creative & Sports",
  "Diploma & Honor",
];

export const DocumentTemplateStudioModal: React.FC<Props> = ({
  school,
  initialDocType = "id_card",
  asPage = false,
  onClose,
  onBack,
  onSchoolUpdated,
  onTemplateApplied,
}) => {
  const schoolId = school?.id;
  const [docType, setDocType] = useState<DocumentTemplateType>(initialDocType);
  const [refreshTick, setRefreshTick] = useState(0);
  const [showCreateForm, setShowCreateForm] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState<"ALL" | TemplateCategory>("ALL");

  useEffect(() => {
    setDocType(initialDocType);
  }, [initialDocType]);

  const templates = useMemo(
    () => getTemplatesForType(schoolId, school, docType),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [schoolId, school, docType, refreshTick]
  );

  const filteredTemplates = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();
    return templates.filter((tpl) => {
      if (activeCategory !== "ALL" && !tpl.isDefault && !tpl.isCustom) {
        const cat = tpl.category || (tpl.layoutVariant ? LAYOUT_VARIANT_META[tpl.layoutVariant]?.category : undefined);
        if (cat !== activeCategory) return false;
      }
      if (!q) return true;
      const lvLabel = tpl.layoutVariant ? LAYOUT_VARIANT_META[tpl.layoutVariant]?.label || "" : "";
      return (
        tpl.name.toLowerCase().includes(q) ||
        (tpl.hindiTag || "").toLowerCase().includes(q) ||
        (tpl.category || "").toLowerCase().includes(q) ||
        lvLabel.toLowerCase().includes(q)
      );
    });
  }, [templates, activeCategory, searchQuery]);

  const activeTemplate = useMemo(
    () => resolveActiveDocumentTemplate(schoolId, school, docType),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [schoolId, school, docType, refreshTick]
  );

  const [selectedTplId, setSelectedTplId] = useState<string>(activeTemplate.id);

  useEffect(() => {
    const resolved = resolveActiveDocumentTemplate(schoolId, school, docType);
    setSelectedTplId(resolved.id);
    setShowCreateForm(false);
  }, [docType, schoolId]);

  const selectedTemplate = useMemo(
    () => templates.find((t) => t.id === selectedTplId) || activeTemplate,
    [templates, selectedTplId, activeTemplate]
  );

  const [draftColors, setDraftColors] = useState<TemplatePalette>(selectedTemplate.colors);
  useEffect(() => {
    setDraftColors({ ...selectedTemplate.colors });
  }, [selectedTemplate.id, selectedTemplate.colors]);

  // Custom Template Creation Form State
  const [newName, setNewName] = useState("");
  const [newLayoutVariant, setNewLayoutVariant] = useState<TemplateLayoutVariant>("classic_ribbon");
  const [newBorderStyle, setNewBorderStyle] = useState<"solid" | "double" | "dashed">("double");
  const [newLogoPos, setNewLogoPos] = useState<"left" | "center" | "right">("left");
  const [newShowWatermark, setNewShowWatermark] = useState(true);
  const [newWatermarkText, setNewWatermarkText] = useState(
    (school?.name || "OFFICIAL SCHOOL COPY").slice(0, 22).toUpperCase()
  );
  const [newFooterNote, setNewFooterNote] = useState(DOC_TYPE_META[docType].defaultFooter);
  const [newLeftSign, setNewLeftSign] = useState(DOC_TYPE_META[docType].defaultLeftSign);
  const [newRightSign, setNewRightSign] = useState(DOC_TYPE_META[docType].defaultRightSign);
  const [newColors, setNewColors] = useState<TemplatePalette>({ ...selectedTemplate.colors });

  useEffect(() => {
    setNewFooterNote(DOC_TYPE_META[docType].defaultFooter);
    setNewLeftSign(DOC_TYPE_META[docType].defaultLeftSign);
    setNewRightSign(DOC_TYPE_META[docType].defaultRightSign);
  }, [docType]);

  const syncAfterChange = (appliedTpl?: DocumentTemplateConfig) => {
    setRefreshTick((t) => t + 1);
    const nextState = loadSchoolDocumentTemplatesState(schoolId, school);
    if (onSchoolUpdated) {
      onSchoolUpdated({ documentTemplates: nextState } as any);
    }
    if (appliedTpl && onTemplateApplied) {
      onTemplateApplied(docType, appliedTpl);
    }
  };

  const handleApplyTemplate = async (tpl: DocumentTemplateConfig) => {
    await setActiveTemplateForSchool(schoolId, school, docType, tpl.id);
    setSelectedTplId(tpl.id);
    syncAfterChange(tpl);
    toast.success(`✅ "${tpl.name}" ${DOC_TYPE_META[docType].label} par apply ho gaya!`);
  };

  const handleColorLiveSave = async (field: keyof TemplatePalette, value: string) => {
    const nextColors = { ...draftColors, [field]: value };
    setDraftColors(nextColors);
    await saveTemplateColorOverride(schoolId, school, docType, selectedTemplate.id, { [field]: value });
    if (selectedTemplate.id === "default") {
      toast.info("Tip: App Original Default को बिना बदले रखना बेहतर है; कस्टम रंग के लिए 01–60 में से कोई भी Design चुनें।");
    }
    syncAfterChange();
  };

  const handleResetColors = async () => {
    await resetTemplateColors(schoolId, school, docType, selectedTemplate.id);
    syncAfterChange();
    toast.success("🎨 Template ke original colors wapas reset ho gaye!");
  };

  const handleCreateCustomTemplate = async (e: React.FormEvent) => {
    e.preventDefault();
    const cleanName = newName.trim().toUpperCase();
    if (!cleanName) {
      toast.error("Kripya naye template ka naam likhein!");
      return;
    }
    const created: DocumentTemplateConfig = {
      id: `custom_${docType}_${Date.now()}`,
      name: cleanName,
      hindiTag: `${LAYOUT_VARIANT_META[newLayoutVariant].label} · Custom`,
      category: LAYOUT_VARIANT_META[newLayoutVariant].category,
      docType,
      layoutVariant: newLayoutVariant,
      isCustom: true,
      isDefault: false,
      borderStyle: newBorderStyle,
      logoPosition: newLogoPos,
      showWatermark: newShowWatermark,
      watermarkText: (newWatermarkText || "OFFICIAL").trim().toUpperCase(),
      footerNote: newFooterNote.trim() || DOC_TYPE_META[docType].defaultFooter,
      leftSignatoryLabel: newLeftSign.trim() || DOC_TYPE_META[docType].defaultLeftSign,
      rightSignatoryLabel: newRightSign.trim() || DOC_TYPE_META[docType].defaultRightSign,
      colors: { ...newColors },
    };
    await saveCustomTemplate(schoolId, school, created, true);
    setSelectedTplId(created.id);
    setShowCreateForm(false);
    setNewName("");
    syncAfterChange(created);
    toast.success(`🎉 Custom Template "${created.name}" banakar apply kar diya gaya!`);
  };

  const handleDeleteCustom = async (tpl: DocumentTemplateConfig) => {
    await deleteCustomTemplate(schoolId, school, docType, tpl.id);
    setSelectedTplId("default");
    syncAfterChange();
    toast.success(`🗑️ Custom template "${tpl.name}" delete ho gaya.`);
  };

  const previewColors = showCreateForm ? newColors : draftColors;
  const previewVariant: TemplateLayoutVariant | "default" = showCreateForm
    ? newLayoutVariant
    : selectedTemplate.id === "default"
    ? "default"
    : selectedTemplate.layoutVariant || "classic_ribbon";
  const previewBorderStyle = showCreateForm ? newBorderStyle : selectedTemplate.borderStyle;
  const previewLogoPos = showCreateForm ? newLogoPos : selectedTemplate.logoPosition;
  const previewShowWatermark = showCreateForm ? newShowWatermark : selectedTemplate.showWatermark;
  const previewWatermarkText = showCreateForm
    ? newWatermarkText || "OFFICIAL"
    : selectedTemplate.watermarkText || (school?.name || "SCHOOL").slice(0, 12).toUpperCase();
  const previewFooter = showCreateForm
    ? newFooterNote
    : selectedTemplate.footerNote || DOC_TYPE_META[docType].defaultFooter;
  const previewLeftSign = showCreateForm
    ? newLeftSign
    : selectedTemplate.leftSignatoryLabel || DOC_TYPE_META[docType].defaultLeftSign;
  const previewRightSign = showCreateForm
    ? newRightSign
    : selectedTemplate.rightSignatoryLabel || DOC_TYPE_META[docType].defaultRightSign;


  const content = (
    <div className="bg-white dark:bg-slate-900 rounded-2xl border border-slate-200 dark:border-slate-800 shadow-2xl flex flex-col overflow-hidden max-h-[94vh] w-full">
      {/* Header */}
      <div className="px-4 sm:px-6 py-3.5 bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 text-white flex items-center justify-between gap-3 shrink-0">
        <div className="flex items-center gap-2.5 min-w-0">
          {asPage && onBack && (
            <button
              type="button"
              onClick={onBack}
              className="p-1.5 rounded-lg bg-white/10 hover:bg-white/20 text-white transition cursor-pointer shrink-0"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          )}
          <div className="w-9 h-9 rounded-xl bg-amber-400/20 border border-amber-400/40 flex items-center justify-center text-amber-300 shrink-0">
            <LayoutTemplate className="w-5 h-5" />
          </div>
          <div className="min-w-0">
            <h2 className="text-sm sm:text-base font-black tracking-tight truncate">
              Document Templates Studio (60 Structural Layouts × 5 Document Types)
            </h2>
            <p className="text-[11px] text-indigo-200 truncate">
              10 क्लासिक + 50 नए स्ट्रक्चरल लेआउट (कुल 60 अलग-अलग डिज़ाइन) — ID Card, Admit Card, Marksheet, Fee Slip व Certificate के लिए
            </p>
          </div>
        </div>
        {!asPage && onClose && (
          <button
            type="button"
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-white/10 hover:bg-white/20 text-white flex items-center justify-center transition cursor-pointer shrink-0"
          >
            <X className="w-4 h-4" />
          </button>
        )}
      </div>

      {/* 5 DocType Tabs (including Certificate) */}
      <div className="px-4 sm:px-6 py-2.5 bg-slate-50 dark:bg-slate-950 border-b border-slate-200 dark:border-slate-800 flex items-center justify-between gap-2 flex-wrap shrink-0">
        <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {(Object.keys(DOC_TYPE_META) as DocumentTemplateType[]).map((dt) => {
            const meta = DOC_TYPE_META[dt];
            const isTab = docType === dt;
            return (
              <button
                key={dt}
                type="button"
                onClick={() => setDocType(dt)}
                className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition cursor-pointer shrink-0 border ${
                  isTab
                    ? "bg-indigo-600 text-white border-indigo-500 shadow-sm"
                    : "bg-white dark:bg-slate-800 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                }`}
              >
                <span>{meta.emoji}</span>
                <span>{meta.label}</span>
                <span className="text-[10px] opacity-80">({meta.hindiLabel})</span>
              </button>
            );
          })}
        </div>

        <button
          type="button"
          onClick={() => {
            setNewColors({ ...selectedTemplate.colors });
            setNewLayoutVariant(selectedTemplate.layoutVariant || "classic_ribbon");
            setShowCreateForm((v) => !v);
          }}
          className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1.5 shadow-sm transition cursor-pointer shrink-0"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>{showCreateForm ? "60 Layouts Gallery Dekhein" : "Naya Custom Template Banayein"}</span>
        </button>
      </div>

      {/* Main Split Workspace */}
      <div className="flex-1 overflow-y-auto p-4 sm:p-5 grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* LEFT: 60-Template Gallery OR Custom Creator */}
        <div className="lg:col-span-6 space-y-3">
          {showCreateForm ? (
            <form
              onSubmit={handleCreateCustomTemplate}
              className="bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700 rounded-2xl p-4 space-y-4"
            >
              <div className="flex items-center justify-between border-b border-slate-200 dark:border-slate-700 pb-2.5">
                <div>
                  <h3 className="text-sm font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-emerald-500" />
                    Naya Custom {DOC_TYPE_META[docType].label} Template Banayein
                  </h3>
                  <p className="text-[11px] text-slate-500">
                    60 अलग-अलग स्ट्रक्चरल लेआउट (10 पुराने + 50 नए) में से कोई भी चुनें, और अपना बॉर्डर, लोगो व रंग सेट करें।
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setShowCreateForm(false)}
                  className="text-xs font-bold text-slate-500 hover:text-slate-800 dark:hover:text-white cursor-pointer"
                >
                  Cancel
                </button>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Template Name (बड़े अक्षरों में) *
                  </label>
                  <input
                    type="text"
                    required
                    value={newName}
                    onChange={(e) => setNewName(e.target.value.toUpperCase())}
                    placeholder="E.G. LMPS ROYAL CERTIFICATE 2027"
                    className="w-full px-3 py-2 text-xs font-black uppercase rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Layout Structure / Design Style (60 अलग-अलग स्ट्रक्चरल लेआउट चुनें: 10 Classic + 50 New)
                  </label>
                  <select
                    value={newLayoutVariant}
                    onChange={(e) => setNewLayoutVariant(e.target.value as TemplateLayoutVariant)}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  >
                    {(Object.keys(LAYOUT_VARIANT_META) as TemplateLayoutVariant[]).map((lv) => (
                      <option key={lv} value={lv}>
                        {LAYOUT_VARIANT_META[lv].code}: {LAYOUT_VARIANT_META[lv].label} — {LAYOUT_VARIANT_META[lv].hindiDesc}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Border Style (बॉर्डर डिज़ाइन)
                  </label>
                  <select
                    value={newBorderStyle}
                    onChange={(e) => setNewBorderStyle(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  >
                    <option value="solid">Solid Clean Border</option>
                    <option value="double">Royal Double Border</option>
                    <option value="dashed">Classic Dashed Frame</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    School Logo Position
                  </label>
                  <select
                    value={newLogoPos}
                    onChange={(e) => setNewLogoPos(e.target.value as any)}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  >
                    <option value="left">Left Side (Standard)</option>
                    <option value="center">Centered Crest</option>
                    <option value="right">Right Aligned</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Left Signatory Title
                  </label>
                  <input
                    type="text"
                    value={newLeftSign}
                    onChange={(e) => setNewLeftSign(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Right Signatory Title
                  </label>
                  <input
                    type="text"
                    value={newRightSign}
                    onChange={(e) => setNewRightSign(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-bold rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-bold text-slate-600 dark:text-slate-300 mb-1">
                    Custom Footer Note (नीचे की लाइन)
                  </label>
                  <input
                    type="text"
                    value={newFooterNote}
                    onChange={(e) => setNewFooterNote(e.target.value)}
                    className="w-full px-3 py-2 text-xs font-medium rounded-xl border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                  />
                </div>

                <div className="sm:col-span-2 flex flex-wrap items-center gap-3 p-2.5 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700">
                  <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
                    <input
                      type="checkbox"
                      checked={newShowWatermark}
                      onChange={(e) => setNewShowWatermark(e.target.checked)}
                      className="w-4 h-4 rounded text-indigo-600"
                    />
                    <span>Show Watermark (हल्का वॉटरमार्क दिखाएं)</span>
                  </label>
                  {newShowWatermark && (
                    <input
                      type="text"
                      value={newWatermarkText}
                      onChange={(e) => setNewWatermarkText(e.target.value.toUpperCase())}
                      placeholder="WATERMARK TEXT"
                      className="flex-1 min-w-[160px] px-2.5 py-1 text-xs font-black uppercase rounded-lg border border-slate-300 dark:border-slate-600 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                    />
                  )}
                </div>
              </div>

              {/* Color Pickers for Custom Template */}
              <div className="space-y-2">
                <p className="text-[11px] font-black uppercase tracking-wider text-slate-500">Custom Colors चुनें:</p>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                  {COLOR_FIELDS.map((cf) => (
                    <label
                      key={cf.key}
                      className="flex items-center gap-2 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 cursor-pointer"
                    >
                      <input
                        type="color"
                        value={newColors[cf.key]}
                        onChange={(e) => setNewColors((p) => ({ ...p, [cf.key]: e.target.value }))}
                        className="w-7 h-7 rounded cursor-pointer border-0 p-0 bg-transparent shrink-0"
                      />
                      <div className="min-w-0">
                        <div className="text-[10.5px] font-black text-slate-800 dark:text-white truncate">{cf.label}</div>
                        <div className="text-[9px] font-mono text-slate-400">{newColors[cf.key]}</div>
                      </div>
                    </label>
                  ))}
                </div>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-black flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save &amp; Apply Custom Template</span>
                </button>
              </div>
            </form>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between flex-wrap gap-2">
                <p className="text-xs font-black text-slate-700 dark:text-slate-200 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-indigo-500" />
                  <span>
                    {DOC_TYPE_META[docType].label} Templates ({templates.length}: Default + 60 Unique Structural Layouts)
                  </span>
                </p>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 truncate max-w-[240px]">
                  Active: {activeTemplate.name}
                </span>
              </div>

              {/* Search & Category Filters */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="डिज़ाइन खोजें (e.g. Royal, Arch, Sidebar, Tricolor, Gold, CBSE)..."
                    className="w-full pl-8 pr-3 py-1.5 text-xs rounded-xl border border-slate-200 dark:border-slate-700 bg-slate-50 dark:bg-slate-800 text-slate-900 dark:text-white"
                  />
                </div>
                <div className="flex items-center gap-1.5 overflow-x-auto no-scrollbar pb-0.5">
                  {CATEGORIES.map((cat) => (
                    <button
                      key={cat}
                      type="button"
                      onClick={() => setActiveCategory(cat)}
                      className={`px-2.5 py-1 rounded-lg text-[10px] font-black shrink-0 border transition cursor-pointer ${
                        activeCategory === cat
                          ? "bg-slate-900 text-amber-300 border-slate-900 dark:bg-indigo-600 dark:text-white"
                          : "bg-white dark:bg-slate-800 text-slate-600 dark:text-slate-300 border-slate-200 dark:border-slate-700 hover:bg-slate-100"
                      }`}
                    >
                      {cat === "ALL" ? `All (${templates.length})` : cat}
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 max-h-[470px] overflow-y-auto pr-1">
                {filteredTemplates.map((tpl) => {
                  const isActive = activeTemplate.id === tpl.id;
                  const isSelected = selectedTemplate.id === tpl.id;
                  const lvMeta = tpl.layoutVariant ? LAYOUT_VARIANT_META[tpl.layoutVariant] : null;
                  return (
                    <div
                      key={tpl.id}
                      onClick={() => setSelectedTplId(tpl.id)}
                      className={`p-3 rounded-2xl border-2 transition cursor-pointer flex flex-col justify-between gap-2 ${
                        isSelected
                          ? "border-indigo-500 bg-indigo-50/70 dark:bg-indigo-950/30 shadow-sm"
                          : "border-slate-200 dark:border-slate-700/80 bg-white dark:bg-slate-800/60 hover:border-slate-300"
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="min-w-0 flex-1">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <span className="text-xs font-black text-slate-900 dark:text-white truncate">
                              {tpl.name}
                            </span>
                            {tpl.isDefault && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-slate-900 text-amber-300">
                                ORIGINAL DEFAULT
                              </span>
                            )}
                            {tpl.isCustom && (
                              <span className="px-1.5 py-0.2 rounded text-[9px] font-black bg-emerald-600 text-white">
                                CUSTOM
                              </span>
                            )}
                            {lvMeta && (
                              <span className="px-1.5 py-0.2 rounded text-[8.5px] font-black bg-indigo-100 text-indigo-800 dark:bg-indigo-900/60 dark:text-indigo-200">
                                {lvMeta.code}
                              </span>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 mt-0.5 truncate">
                            {tpl.hindiTag}
                          </p>
                          {tpl.category && !tpl.isDefault && (
                            <span className="inline-block mt-1 text-[8.5px] font-bold text-slate-400">
                              {tpl.category} • {lvMeta?.label || "Classic"}
                            </span>
                          )}
                        </div>

                        {tpl.isCustom && (
                          <button
                            type="button"
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDeleteCustom(tpl);
                            }}
                            className="p-1 text-rose-500 hover:bg-rose-50 rounded-lg cursor-pointer shrink-0"
                            title="Delete Custom Template"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>

                      {/* Mini Color Swatches + Apply Button */}
                      <div className="flex items-center justify-between gap-2 pt-1.5 border-t border-slate-100 dark:border-slate-700/60">
                        <div className="flex items-center gap-1">
                          {[tpl.colors.primaryColor, tpl.colors.accentColor, tpl.colors.borderColor, tpl.colors.badgeBg].map((c, idx) => (
                            <span
                              key={idx}
                              className="w-4 h-4 rounded-full border border-slate-300 dark:border-slate-600 shadow-2xs"
                              style={{ backgroundColor: c }}
                            />
                          ))}
                        </div>

                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleApplyTemplate(tpl);
                          }}
                          className={`px-2.5 py-1 rounded-lg text-[10.5px] font-black flex items-center gap-1 transition cursor-pointer ${
                            isActive
                              ? "bg-emerald-600 text-white"
                              : "bg-slate-900 hover:bg-indigo-600 text-white"
                          }`}
                        >
                          {isActive ? (
                            <>
                              <CheckCircle2 className="w-3 h-3" />
                              <span>Applied</span>
                            </>
                          ) : (
                            <span>Apply Karein</span>
                          )}
                        </button>
                      </div>
                    </div>
                  );
                })}
                {filteredTemplates.length === 0 && (
                  <div className="col-span-2 py-8 text-center text-xs text-slate-400">
                    Koi design match nahi hua — Search clear karke dekhein.
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* RIGHT: Real Document Live Preview + Color Customizer for Selected Template */}
        <div className="lg:col-span-6 space-y-4">
          <div className="p-3.5 rounded-2xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between text-[11px] font-black text-slate-600 dark:text-slate-300 gap-2">
              <span className="truncate">Real Document Live Preview ({DOC_TYPE_META[docType].label})</span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shrink-0">
                {previewVariant === "default" ? "APP DEFAULT" : LAYOUT_VARIANT_META[previewVariant].code.toUpperCase()}
              </span>
            </div>

            <DocumentStudioRealPreview
              docType={docType}
              school={school as any}
              variant={previewVariant}
              colors={previewColors}
              borderStyle={previewBorderStyle}
              logoPosition={previewLogoPos}
              showWatermark={Boolean(previewShowWatermark)}
              watermarkText={previewWatermarkText}
              footerNote={previewFooter}
              leftSignatoryLabel={previewLeftSign}
              rightSignatoryLabel={previewRightSign}
            />

            <div className="text-[10px] text-slate-500 dark:text-slate-400 font-medium px-1">
              {previewVariant === "default"
                ? "ऐप का मूल डिफ़ॉल्ट डिज़ाइन (बिना किसी बदलाव के सुरक्षित)"
                : `Style: ${LAYOUT_VARIANT_META[previewVariant].label} — ${LAYOUT_VARIANT_META[previewVariant].hindiDesc}`}
            </div>
          </div>

          {!showCreateForm && (
            <div className="p-3.5 rounded-2xl bg-slate-50 dark:bg-slate-800/70 border border-slate-200 dark:border-slate-700 space-y-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h4 className="text-xs font-black text-slate-900 dark:text-white flex items-center gap-1.5">
                    <Palette className="w-3.5 h-3.5 text-indigo-500" />
                    <span className="truncate">Colors Badlein ({selectedTemplate.name})</span>
                  </h4>
                  <p className="text-[10px] text-slate-500">इस डिज़ाइन के सभी रंग अपनी पसंद के अनुसार बदलें।</p>
                </div>
                <button
                  type="button"
                  onClick={handleResetColors}
                  className="px-2 py-1 rounded-lg bg-white dark:bg-slate-900 border border-slate-300 dark:border-slate-600 text-[10px] font-bold text-slate-700 dark:text-slate-200 hover:bg-slate-100 flex items-center gap-1 cursor-pointer shrink-0"
                  title="Original template colors wapas layein"
                >
                  <RotateCcw className="w-3 h-3" /> Reset
                </button>
              </div>

              {selectedTemplate.id === "default" ? (
                <div className="p-2.5 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-300 dark:border-amber-700 text-[11px] text-amber-900 dark:text-amber-200 flex items-start gap-2">
                  <ShieldCheck className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
                  <span>
                    <strong>App Original Default</strong> सुरक्षित रखा गया है। बाईं ओर <strong>10 पुराने + 50 नए स्ट्रक्चरल लेआउट (कुल 60 अलग डिज़ाइन)</strong> दिए गए हैं — कोई भी चुनें और रंग भी बदलें!
                  </span>
                </div>
              ) : (
                <>
                  <div className="grid grid-cols-2 gap-2">
                    {COLOR_FIELDS.map((cf) => (
                      <label
                        key={cf.key}
                        className="flex items-center gap-2 p-2 rounded-xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-700 cursor-pointer hover:border-indigo-400 transition"
                      >
                        <input
                          type="color"
                          value={draftColors[cf.key]}
                          onChange={(e) => handleColorLiveSave(cf.key, e.target.value)}
                          className="w-7 h-7 rounded cursor-pointer border-0 p-0 bg-transparent shrink-0"
                        />
                        <div className="min-w-0">
                          <div className="text-[10.5px] font-black text-slate-800 dark:text-white truncate">{cf.label}</div>
                          <div className="text-[9px] font-mono text-slate-400">{draftColors[cf.key]}</div>
                        </div>
                      </label>
                    ))}
                  </div>

                  {activeTemplate.id !== selectedTemplate.id && (
                    <button
                      type="button"
                      onClick={() => handleApplyTemplate(selectedTemplate)}
                      className="w-full py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-black flex items-center justify-center gap-1.5 shadow cursor-pointer"
                    >
                      <CheckCircle2 className="w-4 h-4" />
                      <span>Is Design Ko Apply Karein</span>
                    </button>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );

  if (asPage) {
    return <div className="max-w-7xl mx-auto py-2">{content}</div>;
  }

  return (
    <div className="fixed inset-0 z-[9999] flex items-center justify-center p-2 sm:p-4 bg-slate-950/80 backdrop-blur-xs">
      <div className="w-full max-w-7xl">{content}</div>
    </div>
  );
};
