import { jsPDF } from "jspdf";
import html2canvas from "html2canvas";
import { renderHtmlToCanvasSafe } from "../../utils/safePdfCapture";
import {
  mapFeeSlipRoutingToSignatoryMode,
  mapFeeReceiptRoutingToSignatoryMode,
  type MonthlyFee,
  type SchoolStudent,
  type SchoolSignatureRoutingConfig,
} from "../../school-types";
import {
  generateDpsReceiptHtml,
  generatePosSlipHtml,
  DPS_RECEIPT_CSS,
  POS_SLIP_CSS,
  printDpsReceiptDirect,
  printPosSlipDirect,
  getSavedSchoolLogo,
  formatAcademicSession,
  formatShortFeeMonth,
  formatConciseArrearsMonths,
  computeStudentFeeHistorySummary,
  type DpsReceiptData,
  type FeeReceiptItem,
} from "./feeReceiptUtils";
import { safeOpenExternalUrl, getDynamicAcademicSessionLabel } from "../../utils/safeBrowserActions";
import { getSchoolFeeDiscountSlabs, computeSlabDiscountAmount } from "../../utils/feeDiscountSlabs";
import { formatCoveredMonthsList, formatMonthNameOnly, formatCompactDayMonth } from "../../utils/familyFeeEngine";

interface FeeDocumentOptions {
  fee: MonthlyFee;
  student?: Partial<SchoolStudent> | null;
  schoolName?: string;
  className?: string;
  feeHistory?: MonthlyFee[];
  isDueDemand?: boolean;
  mode?: "4in1" | "full" | "pos" | "a6";
  receiptDataOverride?: DpsReceiptData;
  schoolDetails?: {
    schoolId?: string;
    schoolName?: string;
    address?: string;
    phone?: string;
    email?: string;
    affiliation?: string;
    code?: string;
    logoUrl?: string;
    upiId?: string;
    principalName?: string;
    principalSignatureUrl?: string;
    directorName?: string;
    directorSignatureUrl?: string;
    managerName?: string;
    managerSignatureUrl?: string;
    accountantName?: string;
    accountantSignatureUrl?: string;
    signatureRouting?: SchoolSignatureRoutingConfig;
  };
}

/**
 * Builds standard DpsReceiptData structure from any MonthlyFee record
 */
export function buildDpsReceiptData({
  fee,
  student,
  schoolName,
  className,
  feeHistory,
  schoolDetails,
}: FeeDocumentOptions): DpsReceiptData {
  const arrears = Number(fee.arrearsAmount || 0);
  const rawTotalAmount = Number(fee.amount ?? 0);
  const baseMonthlyAmount = Number(
    fee.monthlyAmount !== undefined
      ? fee.monthlyAmount
      : Math.max(0, rawTotalAmount - arrears)
  );

  // Format month name cleanly (e.g. "NOV 2026")
  const installment = fee.month
    ? (formatShortFeeMonth(fee.month).toUpperCase() || "CURRENT MONTH")
    : "CURRENT MONTH";

  // Format Receipt Date and Exact Payment Time
  let receiptDate = "";
  let receiptTime = "";
  if (fee.paidDate) {
    const d = new Date(fee.paidDate);
    receiptDate = `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
    receiptTime = d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
  } else {
    const d = new Date();
    receiptDate = `${String(d.getDate()).padStart(2, "0")}/${String(d.getMonth() + 1).padStart(2, "0")}/${d.getFullYear()}`;
    receiptTime = d.toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: true });
  }

  // Build items ledger
  let items: FeeReceiptItem[] = [];
  if (fee.items && fee.items.length > 0) {
    items = fee.items;
  } else if (baseMonthlyAmount >= 50000) {
    items.push(
      { id: "1", slNo: 1, description: "Admission Fee", due: 65000, con: 0, paid: 65000 },
      { id: "2", slNo: 2, description: "Tuition Fee", due: 19140, con: 0, paid: 19140 },
      { id: "3", slNo: 3, description: "Caution Money", due: 60000, con: 0, paid: 60000 },
      { id: "4", slNo: 4, description: "Annual Charges", due: 23320, con: 0, paid: 23320 },
      { id: "5", slNo: 5, description: "Bus Fee", due: 10360, con: 0, paid: 10360 }
    );
  } else {
    items.push({
      id: "1",
      slNo: 1,
      description: "Tuition Fee",
      due: baseMonthlyAmount,
      con: 0,
      paid: fee.paid ? baseMonthlyAmount : Number(fee.paidAmount || 0),
    });
    if (arrears > 0) {
      const conciseArrears = formatConciseArrearsMonths(fee.arrearsMonths);
      items.push({
        id: "2",
        slNo: 2,
        description: `Back Due / Previous Arrears${conciseArrears ? ` (${conciseArrears})` : ""}`,
        due: arrears,
        con: 0,
        paid: fee.paid ? arrears : 0,
      });
    }
  }

  const isDueDemandSlip = !fee.paid && (Number(fee.paidAmount || 0) === 0);
  const isAdmissionReceipt = fee.feeType === "admission" || fee.receiptCategory === "admission";
  const resolvedSchoolId = schoolDetails?.schoolId || fee.schoolId || "";
  const histSummary = computeStudentFeeHistorySummary({
    studentId: fee.studentId,
    schoolId: resolvedSchoolId,
    currentMonth: fee.month,
    currentFee: fee,
    feeHistory,
  });

  return {
    schoolName: schoolDetails?.schoolName || schoolName || "School",
    schoolId: resolvedSchoolId,
    schoolAddress: schoolDetails?.address || "Institutional Academic Campus, Educational Zone",
    schoolLogoUrl: getSavedSchoolLogo(schoolDetails?.logoUrl, resolvedSchoolId),
    schoolPhone: schoolDetails?.phone,
    schoolEmail: schoolDetails?.email,
    schoolAffiliation: schoolDetails?.affiliation,
    upiId: schoolDetails?.upiId || "",
    receiptTitle: isDueDemandSlip
      ? "FEE DEMAND SLIP • बकाया शुल्क तकादा पर्ची"
      : isAdmissionReceipt
      ? "OFFICIAL ADMISSION FEE RECEIPT / प्रवेश शुल्क रसीद"
      : "OFFICIAL MONTHLY FEE RECEIPT / मासिक शुल्क रसीद",

    receiptNo: fee.receiptNo || String(Math.floor(10000 + Math.random() * 90000)),
    admissionNo: (student as any)?.admissionNo || fee.rollNo || String(Math.floor(100000 + Math.random() * 900000)),
    studentName: fee.studentName || student?.name || "STUDENT",
    fatherName: student?.fatherName || "",
    studentId: fee.studentId || "",
    rollNo: student?.rollNo || fee.rollNo || "",
    phone: student?.phone || (fee as any).phone || "",
    studentPhotoUrl: (student as any)?.photoUrl || (student as any)?.photo || "",
    installment: isAdmissionReceipt ? "ADMISSION" : installment,
    receiptDate: isDueDemandSlip ? receiptDate : (receiptTime ? `${receiptDate} (${receiptTime})` : receiptDate),
    session: formatAcademicSession((fee as any)?.sessionId || getDynamicAcademicSessionLabel()),
    className: className || fee.classId || "Class",
    counterNo: isDueDemandSlip ? "DUE-DEMAND" : isAdmissionReceipt ? "ADM-RECEIPT" : "FEE-RECEIPT",

    items,
    balanceDue: fee.balanceDue,
    lastPaidAmount: fee.lastPaidAmount !== undefined ? fee.lastPaidAmount : histSummary.lastPaidAmount,
    lastPaidDate: fee.lastPaidDate || histSummary.lastPaidDate,
    lastDueAmount: fee.lastDueAmount !== undefined ? fee.lastDueAmount : histSummary.lastDueAmount,
    lastDueDate: fee.lastDueDate || histSummary.lastDueDate,
    lastBakayaAmount: fee.lastBakayaAmount,
    advanceCoveredMonths: fee.advanceCoveredMonths,
    advancePaidAt: fee.advancePaidAt,
    nextFeeSlipMonth: fee.nextFeeSlipMonth,
    familyGroupId: fee.familyGroupId,
    familyReceiptNo: fee.familyReceiptNo,
    familyMembersSummary: fee.familyMembersSummary,
    fifoSummary: fee.note,

    payModeInfo: fee.payModeInfo || {
      payMode: fee.paid ? "Cash" : "Payment Pending / Due Slip",
      date: receiptDate,
      bank: fee.paid ? "School Counter" : "PENDING",
      number: "-",
    },

    note: fee.note || (isDueDemandSlip ? "Pay by 10th of month" : "Thank you"),
    showDigitalSignature: Boolean(
      schoolDetails?.principalSignatureUrl ||
      schoolDetails?.accountantSignatureUrl ||
      schoolDetails?.managerSignatureUrl ||
      schoolDetails?.directorSignatureUrl ||
      fee.collectorSignatureUrl
    ),
    principalSignatureUrl: schoolDetails?.principalSignatureUrl,
    principalName: schoolDetails?.principalName || "Principal",
    principalTitle: "Principal",
    directorSignatureUrl: schoolDetails?.directorSignatureUrl,
    directorName: schoolDetails?.directorName || "Director",
    managerSignatureUrl: schoolDetails?.managerSignatureUrl,
    managerName: schoolDetails?.managerName || "Manager",
    accountantSignatureUrl: schoolDetails?.accountantSignatureUrl,
    accountantName: schoolDetails?.accountantName || "Accountant",
    collectedByRole: fee.collectedByRole || "accountant",
    collectedByName: fee.collectedByName,
    collectorSignatureUrl: fee.collectorSignatureUrl,
    signatoryMode: isDueDemandSlip
      ? mapFeeSlipRoutingToSignatoryMode(schoolDetails?.signatureRouting)
      : mapFeeReceiptRoutingToSignatoryMode(schoolDetails?.signatureRouting),
    cashierTitle:
      fee.collectedByRole === "manager"
        ? (fee.collectedByName || schoolDetails?.managerName || "Manager")
        : (fee.collectedByName || schoolDetails?.accountantName || "Accountant"),
    signatoryTitle: schoolDetails?.managerName || "Manager",
  };
}

/**
 * Downloads official DPS-Format Monthly Fee Receipt as high-resolution PDF
 */
export async function downloadFeeDocument(options: FeeDocumentOptions & { mode?: "4in1" | "full" | "pos" | "a6" }): Promise<void> {
  const receiptData = options.receiptDataOverride || buildDpsReceiptData(options);
  const safeName = (receiptData.studentName || "student").replace(/[^a-z0-9-_]+/gi, "_");
  const receiptNumber = receiptData.receiptNo;
  const mode = options.mode || (options.isDueDemand ? "a6" : "pos");
  const isA6 = mode === "a6" || Boolean(options.isDueDemand && mode !== "pos" && mode !== "4in1" && mode !== "full");
  const isPos = mode === "pos";

  let htmlContent = "";
  const cssText = isPos ? POS_SLIP_CSS : DPS_RECEIPT_CSS;
  if (isA6) {
    const { generateSingleA6SlipHtml } = await import("./feeReceiptUtils");
    htmlContent = generateSingleA6SlipHtml(receiptData);
  } else if (mode === "4in1") {
    const { generate4in1A4PageHtml } = await import("./feeReceiptUtils");
    htmlContent = generate4in1A4PageHtml([
      { data: receiptData, copyTitle: "STUDENT COPY" },
      { data: receiptData, copyTitle: "SCHOOL / OFFICE COPY" },
      { data: receiptData, copyTitle: "ACCOUNTS COPY" },
      { data: receiptData, copyTitle: "PARENT / GUARDIAN COPY" },
    ]);
  } else if (isPos) {
    htmlContent = generatePosSlipHtml(receiptData, { rollWidthMm: 80 });
  } else {
    htmlContent = generateDpsReceiptHtml(receiptData, { layout: "full" });
  }

  try {
    const widthPx = isA6 ? 397 : mode === "4in1" ? 794 : isPos ? 340 : 720;
    const canvas = await renderHtmlToCanvasSafe(htmlContent, cssText, {
      widthPx,
      scale: 2,
      backgroundColor: "#ffffff",
    });

    const imgData = canvas.toDataURL("image/jpeg", 0.96);
    const pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: isA6 ? "a6" : "a4",
    });

    const pdfWidth = pdf.internal.pageSize.getWidth();
    const pdfHeight = pdf.internal.pageSize.getHeight();

    if (isA6 || mode === "4in1") {
      const imgAspect = canvas.width / Math.max(1, canvas.height);
      let drawW = pdfWidth;
      let drawH = drawW / imgAspect;
      if (drawH > pdfHeight) {
        drawH = pdfHeight;
        drawW = drawH * imgAspect;
      }
      const offsetX = Math.max(0, (pdfWidth - drawW) / 2);
      const offsetY = Math.max(0, (pdfHeight - drawH) / 2);
      pdf.addImage(imgData, "JPEG", offsetX, offsetY, drawW, drawH);
    } else if (isPos) {
      const printWidth = 84;
      const printHeight = Math.min(pdfHeight - 20, (canvas.height * printWidth) / canvas.width);
      const marginX = (pdfWidth - printWidth) / 2;
      pdf.addImage(imgData, "JPEG", marginX, 12, printWidth, printHeight);
    } else {
      const marginX = 14;
      let printWidth = pdfWidth - marginX * 2;
      let printHeight = (canvas.height * printWidth) / canvas.width;
      if (printHeight > pdfHeight - 20) {
        printHeight = pdfHeight - 20;
        printWidth = (canvas.width * printHeight) / canvas.height;
      }
      const resolvedX = Math.max(8, (pdfWidth - printWidth) / 2);
      const marginY = Math.max(10, (pdfHeight - printHeight) / 2);
      pdf.addImage(imgData, "JPEG", resolvedX, marginY, printWidth, printHeight);
    }
    const docPrefix = isA6 ? "Fee_Demand_Slip" : isPos ? "Fee_POS_Receipt" : "Fee_Receipt";
    pdf.save(`${docPrefix}_${safeName}_${receiptNumber}.pdf`);
  } catch (err) {
    console.warn("Direct PDF generation fallback to print dialog:", err);
    if (isA6) {
      const { printA6SlipDirect } = await import("./feeReceiptUtils");
      printA6SlipDirect(receiptData);
    } else if (mode === "pos") {
      printPosSlipDirect(receiptData, 80);
    } else {
      printDpsReceiptDirect(receiptData, mode);
    }
  }
}

/**
 * Direct print helper
 */
export function printFeeDocument(options: FeeDocumentOptions): void {
  const receiptData = buildDpsReceiptData(options);
  printDpsReceiptDirect(receiptData);
}

/**
 * Generates an official PDF Blob from FeeDocumentOptions
 */
/**
 * Generates an official PDF Blob from FeeDocumentOptions
 */
export async function generateFeeDocumentPdfBlob(
  options: FeeDocumentOptions & { mode?: "4in1" | "full" | "pos" | "a6" }
): Promise<{ blob: Blob; filename: string; receiptData: DpsReceiptData }> {
  const receiptData = options.receiptDataOverride || buildDpsReceiptData(options);
  const safeName = (receiptData.studentName || "student").replace(/[^a-z0-9-_]+/gi, "_");
  const receiptNumber = receiptData.receiptNo;
  const mode = options.mode || (options.isDueDemand ? "a6" : "pos");
  const isA6 = mode === "a6" || Boolean(options.isDueDemand && mode !== "pos" && mode !== "4in1" && mode !== "full");
  const isPos = mode === "pos";
  const filename = isA6
    ? `Fee_Demand_Slip_${safeName}_${receiptNumber}.pdf`
    : isPos
    ? `POS_Fee_Receipt_${safeName}_${receiptNumber}.pdf`
    : `${receiptData.receiptTitle?.toLowerCase().includes("due") ? "Fee_Due_Demand_Slip" : "Official_Fee_Receipt"}_${safeName}_${receiptNumber}.pdf`;

  let htmlContent = "";
  const cssText = isPos ? POS_SLIP_CSS : DPS_RECEIPT_CSS;
  if (isA6) {
    const { generateSingleA6SlipHtml } = await import("./feeReceiptUtils");
    htmlContent = generateSingleA6SlipHtml(receiptData);
  } else if (mode === "4in1") {
    const { generate4in1A4PageHtml } = await import("./feeReceiptUtils");
    htmlContent = generate4in1A4PageHtml([
      { data: receiptData, copyTitle: "STUDENT COPY" },
      { data: receiptData, copyTitle: "SCHOOL / OFFICE COPY" },
      { data: receiptData, copyTitle: "ACCOUNTS COPY" },
      { data: receiptData, copyTitle: "PARENT / GUARDIAN COPY" },
    ]);
  } else if (isPos) {
    htmlContent = generatePosSlipHtml(receiptData, { rollWidthMm: 80 });
  } else {
    htmlContent = generateDpsReceiptHtml(receiptData, { layout: "full" });
  }

  const widthPx = isA6 ? 397 : mode === "4in1" ? 794 : isPos ? 340 : 720;
  const canvas = await renderHtmlToCanvasSafe(htmlContent, cssText, {
    widthPx,
    scale: 2,
    backgroundColor: "#ffffff",
  });

  const imgData = canvas.toDataURL("image/jpeg", 0.96);

  // If A6 mode, produce an authentic A6 PDF with exact aspect ratio
  if (isA6) {
    const a6Pdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: "a6",
    });
    const pdfWidth = a6Pdf.internal.pageSize.getWidth();
    const pdfHeight = a6Pdf.internal.pageSize.getHeight();
    const imgAspect = canvas.width / Math.max(1, canvas.height);
    let drawW = pdfWidth;
    let drawH = drawW / imgAspect;
    if (drawH > pdfHeight) {
      drawH = pdfHeight;
      drawW = drawH * imgAspect;
    }
    const offsetX = Math.max(0, (pdfWidth - drawW) / 2);
    const offsetY = Math.max(0, (pdfHeight - drawH) / 2);
    a6Pdf.addImage(imgData, "JPEG", offsetX, offsetY, drawW, drawH);
    const blob = a6Pdf.output("blob");
    return { blob, filename, receiptData };
  }

  // If POS mode, produce an authentic 80mm roll PDF
  if (isPos) {
    const rollWidthMm = 80;
    const rollHeightMm = Math.max(110, (canvas.height * rollWidthMm) / canvas.width + 8);
    const posPdf = new jsPDF({
      orientation: "portrait",
      unit: "mm",
      format: [rollWidthMm, rollHeightMm],
    });
    posPdf.addImage(imgData, "JPEG", 0, 3, rollWidthMm, (canvas.height * rollWidthMm) / canvas.width);
    const blob = posPdf.output("blob");
    return { blob, filename, receiptData };
  }

  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
  });

  const pdfWidth = pdf.internal.pageSize.getWidth();
  const pdfHeight = pdf.internal.pageSize.getHeight();

  if (mode === "4in1") {
    const imgAspect = canvas.width / Math.max(1, canvas.height);
    let drawW = pdfWidth;
    let drawH = drawW / imgAspect;
    if (drawH > pdfHeight) {
      drawH = pdfHeight;
      drawW = drawH * imgAspect;
    }
    const offsetX = Math.max(0, (pdfWidth - drawW) / 2);
    const offsetY = Math.max(0, (pdfHeight - drawH) / 2);
    pdf.addImage(imgData, "JPEG", offsetX, offsetY, drawW, drawH);
  } else {
    const marginX = 14;
    let printWidth = pdfWidth - marginX * 2;
    let printHeight = (canvas.height * printWidth) / canvas.width;
    if (printHeight > pdfHeight - 20) {
      printHeight = pdfHeight - 20;
      printWidth = (canvas.width * printHeight) / canvas.height;
    }
    const resolvedX = Math.max(8, (pdfWidth - printWidth) / 2);
    const marginY = Math.max(10, (pdfHeight - printHeight) / 2);
    pdf.addImage(imgData, "JPEG", resolvedX, marginY, printWidth, printHeight);
  }

  const blob = pdf.output("blob");
  return { blob, filename, receiptData };
}

/**
 * Builds the structured WhatsApp receipt / demand due message and extracts recipient metadata.
 */
export function buildWhatsAppReceiptMessage(
  options: FeeDocumentOptions & { mode?: "4in1" | "full" | "pos"; targetPhone?: string; isDueDemand?: boolean }
): {
  message: string;
  targetPhone: string;
  rawPhone: string;
  receiptData: DpsReceiptData;
  isDue: boolean;
  totalBill: number;
  paidAmount: number;
  balanceDue: number;
} {
  const receiptData = buildDpsReceiptData(options);
  const rawPhone = options.targetPhone || options.student?.phone || (options.fee as any).phone || "";
  const digits = rawPhone.replace(/\D/g, "");
  const targetPhone = digits.length === 10 ? `91${digits}` : digits;

  const totalBill = options.fee.amount || Number(options.fee.monthlyAmount || 0);
  const paidAmount = Number(options.fee.paidAmount !== undefined ? options.fee.paidAmount : (options.fee.paid ? totalBill : 0));
  const balanceDue = Number(options.fee.balanceDue !== undefined ? options.fee.balanceDue : Math.max(0, totalBill - paidAmount));

  const isDue = options.isDueDemand || (!options.fee.paid && paidAmount === 0);
  const isPos = options.mode === "pos";
  const schoolName = receiptData.schoolName || options.schoolName || "School";

  // Build itemized breakdown text for clear WhatsApp reading
  const itemLines = (receiptData.items || []).map((it, idx) => {
    const paidVal = Number(it.paid) || 0;
    const dueVal = Number(it.due) || 0;
    const amountStr = paidVal > 0 ? `₹${paidVal.toLocaleString("en-IN")}` : `₹${dueVal.toLocaleString("en-IN")}`;
    return `  ${idx + 1}. ${it.description}: ${amountStr}`;
  }).join("\n");

  const familyBlock =
    Array.isArray(receiptData.familyMembersSummary) && receiptData.familyMembersSummary.length > 1
      ? `👨‍👩‍👧‍👦 *Sibling Family (${receiptData.familyMembersSummary.length} Children):*\n` +
        receiptData.familyMembersSummary
          .map((fm, idx) => {
            const rem = Number(fm.balanceAfter || 0);
            const advTxt = Array.isArray(fm.advanceMonths) && fm.advanceMonths.length > 0
              ? ` | Adv: ${formatCoveredMonthsList(fm.advanceMonths)}`
              : "";
            const stTxt = rem > 0 ? `आंशिक बकाया ₹${rem.toLocaleString("en-IN")}` : `✓ Full Paid${advTxt}`;
            return `  ${idx + 1}. *${fm.studentName}* (${fm.className}) — Paid ₹${Number(fm.paidNow || 0).toLocaleString("en-IN")} (${stTxt})`;
          })
          .join("\n") +
        `\n--------------------------------\n`
      : "";

  const advCovered = Array.isArray(receiptData.advanceCoveredMonths) && receiptData.advanceCoveredMonths.length > 0
    ? formatCoveredMonthsList(receiptData.advanceCoveredMonths)
    : "";
  const advDateTxt = receiptData.advancePaidAt
    ? formatCompactDayMonth(receiptData.advancePaidAt)
    : (receiptData.lastPaidDate ? formatCompactDayMonth(receiptData.lastPaidDate) : receiptData.receiptDate.split("(")[0].trim());
  const nextSlipTxt = receiptData.nextFeeSlipMonth ? formatMonthNameOnly(receiptData.nextFeeSlipMonth) : "";
  const lastBakayaVal = Number(receiptData.lastBakayaAmount !== undefined ? receiptData.lastBakayaAmount : receiptData.lastDueAmount || 0);
  const advanceMiniBlock =
    (lastBakayaVal > 0 ? `📌 *Last Bakaya:* ₹${lastBakayaVal.toLocaleString("en-IN")}\n` : "") +
    (advCovered ? `🎉 *Advance Paid:* ${advCovered} Paid at ${advDateTxt}\n` : "") +
    (nextSlipTxt ? `📅 *Next Fee Slip:* ${nextSlipTxt}\n` : "");

  let message = "";

  // 1. DEDICATED POS THERMAL RECEIPT WHATSAPP FORMAT
  if (isPos) {
    if (isDue) {
      message = `🏫 *${schoolName.toUpperCase()}*\n` +
        (receiptData.schoolAddress ? `📍 ${receiptData.schoolAddress}\n` : "") +
        (receiptData.schoolPhone ? `📞 Helpline: ${receiptData.schoolPhone}\n` : "") +
        `================================\n` +
        `⚠️ *POS FEE DEMAND SLIP (बकाया पर्ची)*\n` +
        `================================\n` +
        `🧾 *Slip No:* ${receiptData.receiptNo}\n` +
        `📅 *Date:* ${receiptData.receiptDate}\n` +
        `👤 *Student:* *${receiptData.studentName}*\n` +
        `🆔 *Adm No:* ${receiptData.admissionNo || "—"}\n` +
        `📚 *Class:* ${receiptData.className}${receiptData.rollNo ? ` (Roll: ${receiptData.rollNo})` : ""}\n` +
        (receiptData.fatherName ? `👨 *Father:* ${receiptData.fatherName}\n` : "") +
        `--------------------------------\n` +
        `*FEE PARTICULARS / विवरण:*\n` +
        `${itemLines}\n` +
        `--------------------------------\n` +
        `💰 *TOTAL DUE (कुल देय बकाया):* *₹${Math.max(balanceDue, totalBill).toLocaleString("en-IN")}*\n` +
        `================================\n` +
        `🙏 *कृपया निर्धारित तिथि तक शुल्क स्कूल काउंटर पर जमा करें।*\n` +
        `📄 *POS 80mm Thermal Slip PDF attached.*`;
    } else {
      message = `🏫 *${schoolName.toUpperCase()}*\n` +
        (receiptData.schoolAddress ? `📍 ${receiptData.schoolAddress}\n` : "") +
        (receiptData.schoolPhone ? `📞 Helpline: ${receiptData.schoolPhone}\n` : "") +
        `================================\n` +
        `🧾 *OFFICIAL POS THERMAL RECEIPT (रसीद)*\n` +
        `================================\n` +
        `🧾 *Receipt No:* ${receiptData.receiptNo}\n` +
        `📅 *Date & Time:* ${receiptData.receiptDate}\n` +
        `👤 *Student:* *${receiptData.studentName}*\n` +
        `🆔 *Adm No:* ${receiptData.admissionNo || "—"}\n` +
        `📚 *Class:* ${receiptData.className}${receiptData.rollNo ? ` (Roll: ${receiptData.rollNo})` : ""}\n` +
        (receiptData.fatherName ? `👨 *Father:* ${receiptData.fatherName}\n` : "") +
        `💳 *Pay Mode:* ${receiptData.payModeInfo.payMode || "Cash"}\n` +
        `🧾 *Collected By:* ${receiptData.collectedByRole === "manager" ? `Manager (${receiptData.collectedByName || receiptData.managerName || "Manager"})` : `Accountant (${receiptData.collectedByName || receiptData.accountantName || "Accountant"})`}\n` +
        `--------------------------------\n` +
        familyBlock +
        `*FEE HEADS / मद विवरण:*\n` +
        `${itemLines}\n` +
        `--------------------------------\n` +
        `💰 *Gross Total:* ₹${totalBill.toLocaleString("en-IN")}\n` +
        ((Number(options.fee.earlyDiscount || 0) > 0 || Number(options.fee.concession || 0) > 0)
          ? (options.student?.isFreeEducation
              ? `🎓 *100% Sibling Free / नि:शुल्क शिक्षा:* -₹${Number(options.fee.earlyDiscount || options.fee.concession).toLocaleString("en-IN")}\n`
              : (options.student?.siblingDiscountPct || options.student?.siblingDiscountAmount)
              ? `🎁 *Sibling Concession (भाई-बहन छूट):* -₹${Number(options.fee.earlyDiscount || options.fee.concession).toLocaleString("en-IN")}\n`
              : `🎁 *5% Early Bird Concession:* -₹${Number(options.fee.earlyDiscount || options.fee.concession).toLocaleString("en-IN")}\n`) : "") +
        `✅ *NET PAID (जमा राशि):* *₹${paidAmount.toLocaleString("en-IN")}*\n` +
        `⚠️ *Balance Due (शेष):* ₹${balanceDue.toLocaleString("en-IN")}${balanceDue <= 0 ? " (FULL PAID ✓)" : " (आंशिक बकाया → अगले माह जुड़ेगा)"}\n` +
        advanceMiniBlock +
        `================================\n` +
        `✍️ *Authority:* ${receiptData.signatoryTitle || "Principal / Cashier"} (VERIFIED)\n` +
        `*Computer Generated Official POS Slip*\n` +
        `📄 *POS 80mm Thermal Receipt PDF attached.*`;
    }
  } else {
    // 2. STANDARD / DPS RECEIPT FORMAT
    if (isDue) {
      const lastPaidAmt = Number(receiptData.lastPaidAmount || 0);
      const lastPaidDt = receiptData.lastPaidDate || "";
      const lastDueAmt = Number(receiptData.lastDueAmount || 0);
      const lastDueDt = receiptData.lastDueDate || "";
      const netPayableTotal = Math.max(balanceDue, totalBill);
      const curMonthRate = Number(options.fee.monthlyAmount) || 0;
      const slabs = getSchoolFeeDiscountSlabs(options.schoolDetails?.schoolId);
      const slabOfferLines = slabs
        .map((s) => {
          const dAmt = computeSlabDiscountAmount(s, curMonthRate);
          if (dAmt <= 0) return "";
          const afterAmt = Math.max(0, netPayableTotal - dAmt);
          const valTxt = s.discountType === "fixed" ? `₹${s.discountValue} OFF` : `${s.discountValue}% OFF`;
          return `⚡ *${s.uptoDay} तारीख तक (${valTxt}):* ₹${afterAmt.toLocaleString("en-IN")} देय (-₹${dAmt.toLocaleString("en-IN")})\n`;
        })
        .join("");

      message = `🏫 *${schoolName.toUpperCase()}*\n` +
        `⚠️ *FEE DEMAND SLIP / बकाया शुल्क तकादा पर्ची*\n` +
        `----------------------------------------\n` +
        `👤 *Student Name:* ${receiptData.studentName}\n` +
        (receiptData.fatherName ? `👨 *Father Name:* ${receiptData.fatherName}\n` : "") +
        `🆔 *Adm No / Roll:* ${receiptData.admissionNo || "—"}${receiptData.rollNo ? ` (Roll: ${receiptData.rollNo})` : ""}\n` +
        `📚 *Class:* ${receiptData.className}\n` +
        `🧾 *Slip No:* ${receiptData.receiptNo} • *Date:* ${receiptData.receiptDate}\n` +
        `----------------------------------------\n` +
        familyBlock +
        `*FEE PARTICULARS:*\n${itemLines}\n` +
        `----------------------------------------\n` +
        `✅ *Last Pay (पिछला जमा):* ₹${lastPaidAmt.toLocaleString("en-IN")}${lastPaidAmt > 0 && lastPaidDt ? ` (${lastPaidDt})` : " (कोई पिछला जमा नहीं)"}\n` +
        `📌 *Last Bakaya (पिछला बकाया):* ₹${Math.max(lastBakayaVal, lastDueAmt).toLocaleString("en-IN")}${lastDueAmt > 0 && lastDueDt ? ` (${lastDueDt})` : " (Clear)"}\n` +
        `💰 *Gross Total Due (स्लिप पर कुल देय):* ₹${netPayableTotal.toLocaleString("en-IN")}\n` +
        (nextSlipTxt ? `📅 *Next Slip Month:* ${nextSlipTxt}\n` : "") +
        (slabOfferLines
          ? `${slabOfferLines}⚠️ _तय तिथि के बाद जमा करने पर पूरा भुगतान ₹${netPayableTotal.toLocaleString("en-IN")} देय होगा।_\n`
          : "") +
        `----------------------------------------\n` +
        `🙏 *कृपया निर्धारित तिथि तक शुल्क स्कूल काउंटर या UPI QR द्वारा जमा करें।*`;
    } else {
      const earlyDiscountAmt = Number(options.fee.earlyDiscount || options.fee.concession || 0);
      const discountLabel = options.student?.isFreeEducation
        ? `🎓 *100% Sibling Free / नि:शुल्क शिक्षा:*`
        : (options.student?.siblingDiscountPct || options.student?.siblingDiscountAmount)
        ? `🎁 *Sibling Concession (भाई-बहन छूट):*`
        : `🎁 *Early Payment Concession:*`;

      message = `🏫 *${schoolName.toUpperCase()}*\n` +
        `🧾 *OFFICIAL FEE PAYMENT RECEIPT / फीस रसीद*\n` +
        `----------------------------------------\n` +
        `👤 *Student Name:* ${receiptData.studentName}\n` +
        `🆔 *Adm No / Roll:* ${receiptData.admissionNo || "—"}\n` +
        `📚 *Class:* ${receiptData.className}\n` +
        `🧾 *Receipt No:* ${receiptData.receiptNo}\n` +
        `📅 *Date & Time:* ${receiptData.receiptDate}\n` +
        `💳 *Payment Mode:* ${receiptData.payModeInfo.payMode || "Cash"}\n` +
        `----------------------------------------\n` +
        familyBlock +
        `*FEE PARTICULARS:*\n${itemLines}\n` +
        `----------------------------------------\n` +
        `💰 *Gross Bill (कुल शुल्क):* ₹${totalBill.toLocaleString("en-IN")}\n` +
        (earlyDiscountAmt > 0 ? `${discountLabel} -₹${earlyDiscountAmt.toLocaleString("en-IN")}\n` : "") +
        `✅ *Amount Paid (जमा राशि):* *₹${paidAmount.toLocaleString("en-IN")}*\n` +
        `⚠️ *Remaining Balance (शेष बकाया):* ₹${balanceDue.toLocaleString("en-IN")}${balanceDue <= 0 ? " (FULL PAID ✓)" : ""}\n` +
        advanceMiniBlock +
        `----------------------------------------\n` +
        (balanceDue > 0
          ? `📌 *आंशिक बकाया ₹${balanceDue.toLocaleString("en-IN")} अगले महीने के बिल में जुड़ेगा।*\n`
          : advCovered
          ? `🎉 *${advCovered} तक का शुल्क पूर्णतः जमा हो चुका है! अगली स्लिप ${nextSlipTxt || "अगले माह"} में आएगी।*\n`
          : `🎉 *सत्र का यह शुल्क पूर्णतः जमा (Full Paid) हो चुका है।*\n`) +
        `📄 *Official DPS Format PDF Receipt downloaded to your device.*`;
    }
  }

  return {
    message,
    targetPhone,
    rawPhone,
    receiptData,
    isDue,
    totalBill,
    paidAmount,
    balanceDue,
  };
}

/**
 * Shares or sends the official fee receipt / demand due slip directly to WhatsApp.
 */
export async function shareFeeReceiptOnWhatsApp(
  options: FeeDocumentOptions & { mode?: "4in1" | "full" | "pos"; targetPhone?: string; isDueDemand?: boolean }
): Promise<void> {
  const { message, targetPhone } = buildWhatsAppReceiptMessage(options);

  // Launch WhatsApp directly with prefilled message to target parent
  const waUrl = targetPhone
    ? `https://wa.me/${targetPhone}?text=${encodeURIComponent(message)}`
    : `https://wa.me/?text=${encodeURIComponent(message)}`;

  try {
    safeOpenExternalUrl(waUrl);
  } catch (err) {
    console.warn("Direct WhatsApp open failed:", err);
  }
}


